//! SIMD across independent transforms, with register transposes at the edges.
//!
//! A bounded stack tile keeps public scratch contracts unchanged. Calls with
//! fewer than a vector of transforms and the final remainder use the original
//! single-transform plan. No caller buffer is used as intermediate storage.

use crate::api::{Direction, Fft, FftDirection, FftNum, Length};
use crate::engine::Shape;
use crate::fft::{fail_inplace, fail_outofplace};
use crate::isa::Isa;
use num_complex::Complex;
use std::sync::Arc;

struct Plan<T> {
    twiddles: Vec<T>,
}

type Entry<T> = unsafe fn(&Plan<T>, *const T, *mut T, usize);

struct Batch<T: FftNum> {
    fallback: Arc<dyn Fft<T>>,
    plan: Plan<T>,
    lanes: usize,
    entry: Entry<T>,
}

impl<T: FftNum> Length for Batch<T> {
    fn len(&self) -> usize {
        self.fallback.len()
    }
}
impl<T: FftNum> Direction for Batch<T> {
    fn fft_direction(&self) -> FftDirection {
        self.fallback.fft_direction()
    }
}
impl<T: FftNum> Batch<T> {
    /// Complete buffers for count transforms; input equals output or is
    /// disjoint. The entry processes only full groups, preserving the input.
    unsafe fn groups(
        &self,
        input: *const Complex<T>,
        output: *mut Complex<T>,
        count: usize,
    ) -> usize {
        let groups = count / self.lanes;
        // SAFETY: constructor verifies precision and ISA; the public wrappers
        // validate complete buffers before the first store.
        unsafe { (self.entry)(&self.plan, input.cast(), output.cast(), groups) };
        groups * self.lanes * self.len()
    }
}
impl<T: FftNum> Fft<T> for Batch<T> {
    fn process(&self, buffer: &mut [Complex<T>]) {
        if buffer.len() / self.len() < self.lanes {
            self.fallback.process(buffer);
        } else {
            crate::scratch::with_scratch(self.get_inplace_scratch_len(), |scratch| {
                self.process_with_scratch(buffer, scratch);
            });
        }
    }

    fn process_with_scratch(&self, buffer: &mut [Complex<T>], scratch: &mut [Complex<T>]) {
        let n = self.len();
        let need = self.get_inplace_scratch_len();
        if buffer.len() < n || !buffer.len().is_multiple_of(n) || scratch.len() < need {
            fail_inplace(n, buffer.len(), need, scratch.len());
        }
        if buffer.len() / n < self.lanes {
            return self.fallback.process_with_scratch(buffer, scratch);
        }
        // SAFETY: complete aliased buffers validated above.
        let done = unsafe { self.groups(buffer.as_ptr(), buffer.as_mut_ptr(), buffer.len() / n) };
        if done < buffer.len() {
            self.fallback
                .process_with_scratch(&mut buffer[done..], scratch);
        }
    }
    fn process_outofplace_with_scratch(
        &self,
        input: &mut [Complex<T>],
        output: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) {
        let n = self.len();
        let need = self.get_outofplace_scratch_len();
        if input.len() != output.len()
            || input.len() < n
            || !input.len().is_multiple_of(n)
            || scratch.len() < need
        {
            fail_outofplace(n, input.len(), output.len(), need, scratch.len());
        }
        if input.len() / n < self.lanes {
            return self
                .fallback
                .process_outofplace_with_scratch(input, output, scratch);
        }
        // SAFETY: complete disjoint buffers validated above.
        let done = unsafe { self.groups(input.as_ptr(), output.as_mut_ptr(), input.len() / n) };
        if done < input.len() {
            self.fallback.process_outofplace_with_scratch(
                &mut input[done..],
                &mut output[done..],
                scratch,
            );
        }
    }
    fn process_immutable_with_scratch(
        &self,
        input: &[Complex<T>],
        output: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) {
        let n = self.len();
        let need = self.get_immutable_scratch_len();
        if input.len() != output.len()
            || input.len() < n
            || !input.len().is_multiple_of(n)
            || scratch.len() < need
        {
            fail_outofplace(n, input.len(), output.len(), need, scratch.len());
        }
        if input.len() / n < self.lanes {
            return self
                .fallback
                .process_immutable_with_scratch(input, output, scratch);
        }
        // SAFETY: complete disjoint buffers validated above; entry never writes input.
        let done = unsafe { self.groups(input.as_ptr(), output.as_mut_ptr(), input.len() / n) };
        if done < input.len() {
            self.fallback.process_immutable_with_scratch(
                &input[done..],
                &mut output[done..],
                scratch,
            );
        }
    }
    fn get_inplace_scratch_len(&self) -> usize {
        self.fallback.get_inplace_scratch_len()
    }
    fn get_outofplace_scratch_len(&self) -> usize {
        self.fallback.get_outofplace_scratch_len()
    }
    fn get_immutable_scratch_len(&self) -> usize {
        self.fallback.get_immutable_scratch_len()
    }
}

#[cfg(all(target_arch = "x86_64", feature = "avx2"))]
mod interleaved;

#[cfg(all(target_arch = "x86_64", feature = "avx2"))]
const fn permutation<const N: usize>() -> [usize; N] {
    let mut result = [0; N];
    let mut dest = 0;
    while dest < N {
        let mut digits = dest;
        let mut source = 0;
        let mut scale = N;
        while scale > 1 {
            let r = if scale >= 8 { 8 } else { scale };
            scale /= r;
            source += (digits % r) * scale;
            digits /= r;
        }
        result[source] = dest;
        dest += 1;
    }
    result
}

pub(crate) fn wrap<T: FftNum>(
    fallback: Arc<dyn Fft<T>>,
    isa: Isa,
) -> (Arc<dyn Fft<T>>, Option<Shape>) {
    #[cfg(all(target_arch = "x86_64", feature = "avx2"))]
    let selected = interleaved::select::<T>(fallback.len(), fallback.fft_direction(), isa);
    #[cfg(not(all(target_arch = "x86_64", feature = "avx2")))]
    let selected: Option<(Entry<T>, Shape)> = {
        let _ = isa;
        None
    };
    let Some((entry, shape)) = selected else {
        return (fallback, None);
    };
    let n = fallback.len();
    let mut twiddles = Vec::new();
    let mut ns = 1;
    let mut m = n;
    while m > 1 {
        let r = m.min(8);
        for j in 0..ns {
            for k in 0..r {
                let (a, b) = crate::twiddle::omega(j * k, r * ns);
                twiddles.push(T::from_f64(a).unwrap());
                twiddles.push(T::from_f64(b).unwrap());
            }
        }
        ns *= r;
        m /= r;
    }
    (
        Arc::new(Batch {
            fallback,
            plan: Plan { twiddles },
            lanes: shape.lanes,
            entry,
        }),
        Some(shape),
    )
}
