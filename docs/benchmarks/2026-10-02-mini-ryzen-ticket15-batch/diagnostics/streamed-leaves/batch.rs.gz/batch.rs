//! SIMD across independent transforms, with register transposes at the edges.
//!
//! A bounded stack tile keeps public scratch contracts unchanged. Calls with
//! fewer than a vector of transforms and the final remainder use the original
//! single-transform plan. No caller buffer is used as intermediate storage.

use crate::api::{Direction, Fft, FftDirection, FftNum, Length};
use crate::engine::Shape;
use crate::fft::{fail_inplace, fail_outofplace};
use crate::isa::Isa;
use num_complex::Complex;
use std::sync::Arc;

struct Plan<T> {
    twiddles: Vec<T>,
    leaf_twiddles: Vec<T>,
}

type Entry<T> = unsafe fn(&Plan<T>, *const T, *mut T, usize, bool);

struct Batch<T: FftNum> {
    fallback: Arc<dyn Fft<T>>,
    plan: Plan<T>,
    lanes: usize,
    entry: Entry<T>,
    stream_threshold: usize,
}

impl<T: FftNum> Length for Batch<T> {
    fn len(&self) -> usize {
        self.fallback.len()
    }
}
impl<T: FftNum> Direction for Batch<T> {
    fn fft_direction(&self) -> FftDirection {
        self.fallback.fft_direction()
    }
}
impl<T: FftNum> Batch<T> {
    /// Complete buffers for count transforms; input equals output or is
    /// disjoint. The entry processes only full groups, preserving the input.
    unsafe fn groups(
        &self,
        input: *const Complex<T>,
        output: *mut Complex<T>,
        count: usize,
    ) -> usize {
        let bytes = count * self.len() * size_of::<Complex<T>>();
        let streaming = input != output.cast_const()
            && (output as usize).is_multiple_of(64)
            && bytes >= self.stream_threshold;
        // The across-transform experiment only wins for f32 N=8. Streaming
        // batches keep the existing leaves at larger register-resident sizes.
        if !(streaming || self.len() == 8 && size_of::<T>() == 4) {
            return 0;
        }
        let groups = count / self.lanes;
        // SAFETY: constructor verifies precision and ISA; the public wrappers
        // validate complete buffers before the first store.
        unsafe { (self.entry)(&self.plan, input.cast(), output.cast(), groups, streaming) };
        groups * self.lanes * self.len()
    }
}
impl<T: FftNum> Fft<T> for Batch<T> {
    fn process(&self, buffer: &mut [Complex<T>]) {
        if buffer.len() / self.len() < self.lanes {
            self.fallback.process(buffer);
        } else {
            crate::scratch::with_scratch(self.get_inplace_scratch_len(), |scratch| {
                self.process_with_scratch(buffer, scratch);
            });
        }
    }

    fn process_with_scratch(&self, buffer: &mut [Complex<T>], scratch: &mut [Complex<T>]) {
        let n = self.len();
        let need = self.get_inplace_scratch_len();
        if buffer.len() < n || !buffer.len().is_multiple_of(n) || scratch.len() < need {
            fail_inplace(n, buffer.len(), need, scratch.len());
        }
        if buffer.len() / n < self.lanes {
            return self.fallback.process_with_scratch(buffer, scratch);
        }
        // SAFETY: complete aliased buffers validated above.
        let done = unsafe { self.groups(buffer.as_ptr(), buffer.as_mut_ptr(), buffer.len() / n) };
        if done < buffer.len() {
            self.fallback
                .process_with_scratch(&mut buffer[done..], scratch);
        }
    }
    fn process_outofplace_with_scratch(
        &self,
        input: &mut [Complex<T>],
        output: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) {
        let n = self.len();
        let need = self.get_outofplace_scratch_len();
        if input.len() != output.len()
            || input.len() < n
            || !input.len().is_multiple_of(n)
            || scratch.len() < need
        {
            fail_outofplace(n, input.len(), output.len(), need, scratch.len());
        }
        if input.len() / n < self.lanes {
            return self
                .fallback
                .process_outofplace_with_scratch(input, output, scratch);
        }
        // SAFETY: complete disjoint buffers validated above.
        let done = unsafe { self.groups(input.as_ptr(), output.as_mut_ptr(), input.len() / n) };
        if done < input.len() {
            self.fallback.process_outofplace_with_scratch(
                &mut input[done..],
                &mut output[done..],
                scratch,
            );
        }
    }
    fn process_immutable_with_scratch(
        &self,
        input: &[Complex<T>],
        output: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) {
        let n = self.len();
        let need = self.get_immutable_scratch_len();
        if input.len() != output.len()
            || input.len() < n
            || !input.len().is_multiple_of(n)
            || scratch.len() < need
        {
            fail_outofplace(n, input.len(), output.len(), need, scratch.len());
        }
        if input.len() / n < self.lanes {
            return self
                .fallback
                .process_immutable_with_scratch(input, output, scratch);
        }
        // SAFETY: complete disjoint buffers validated above; entry never writes input.
        let done = unsafe { self.groups(input.as_ptr(), output.as_mut_ptr(), input.len() / n) };
        if done < input.len() {
            self.fallback.process_immutable_with_scratch(
                &input[done..],
                &mut output[done..],
                scratch,
            );
        }
    }
    fn get_inplace_scratch_len(&self) -> usize {
        self.fallback.get_inplace_scratch_len()
    }
    fn get_outofplace_scratch_len(&self) -> usize {
        self.fallback.get_outofplace_scratch_len()
    }
    fn get_immutable_scratch_len(&self) -> usize {
        self.fallback.get_immutable_scratch_len()
    }
}

#[cfg(all(target_arch = "x86_64", feature = "avx2"))]
mod interleaved;

#[cfg(all(target_arch = "x86_64", feature = "avx2"))]
const fn permutation<const N: usize>() -> [usize; N] {
    let mut result = [0; N];
    let mut dest = 0;
    while dest < N {
        let mut digits = dest;
        let mut source = 0;
        let mut scale = N;
        while scale > 1 {
            let r = if scale >= 8 { 8 } else { scale };
            scale /= r;
            source += (digits % r) * scale;
            digits /= r;
        }
        result[source] = dest;
        dest += 1;
    }
    result
}

pub(crate) fn wrap<T: FftNum>(
    fallback: Arc<dyn Fft<T>>,
    isa: Isa,
) -> (Arc<dyn Fft<T>>, Option<Shape>) {
    #[cfg(all(target_arch = "x86_64", feature = "avx2"))]
    let selected = interleaved::select::<T>(fallback.len(), fallback.fft_direction(), isa);
    #[cfg(not(all(target_arch = "x86_64", feature = "avx2")))]
    let selected: Option<(Entry<T>, Shape)> = {
        let _ = isa;
        None
    };
    let Some((entry, shape)) = selected else {
        return (fallback, None);
    };
    (
        Arc::new(Batch {
            plan: make_plan(fallback.len(), fallback.fft_direction()),
            fallback,
            lanes: shape.lanes,
            entry,
            stream_threshold: crate::isa::cache::last_level_bytes().saturating_mul(3) / 8,
        }),
        Some(shape),
    )
}

fn interleaved_table<T: FftNum>(n: usize, dir: FftDirection) -> Vec<T> {
    #[cfg(all(target_arch = "x86_64", feature = "avx2"))]
    if n <= 256 {
        return crate::isa::x86::interleaved::table(n, 4, |k, n| {
            let (c, s) = crate::twiddle::omega(k, n);
            (
                T::from_f64(c).unwrap(),
                T::from_f64(if dir == FftDirection::Inverse { -s } else { s }).unwrap(),
            )
        });
    }
    let _ = (n, dir);
    Vec::new()
}

fn make_plan<T: FftNum>(n: usize, dir: FftDirection) -> Plan<T> {
    let mut twiddles = Vec::new();
    let mut ns = 1;
    let mut m = n;
    while m > 1 {
        let r = m.min(8);
        for j in 0..ns {
            for k in 0..r {
                let (a, b) = crate::twiddle::omega(j * k, r * ns);
                twiddles.push(T::from_f64(a).unwrap());
                twiddles.push(T::from_f64(b).unwrap());
            }
        }
        ns *= r;
        m /= r;
    }
    Plan {
        twiddles,
        leaf_twiddles: interleaved_table(n, dir),
    }
}

#[cfg(all(test, target_arch = "x86_64", feature = "avx2"))]
mod tests {
    use super::*;
    use crate::{FftPlanner, PlannerOptions};
    use fastfft_testkit::{
        error_vs_f64,
        metrics::{ToDd, fast_path_bound_eps},
        random_c64,
    };

    #[repr(C, align(64))]
    struct Storage<T> {
        data: [Complex<T>; 8224],
    }

    fn forced_streaming<T: FftNum + ToDd>() {
        let guard = Complex::new(T::from_f64(123.0).unwrap(), T::from_f64(-456.0).unwrap());
        for cap in [Isa::Avx2, Isa::Avx512Ymm, Isa::Avx512] {
            let mut planner =
                FftPlanner::<T>::with_options(PlannerOptions::default().with_isa_cap(cap));
            let isa = planner.isa();
            for n in [8, 16, 32, 64, 128, 256, 512, 1024] {
                for dir in [FftDirection::Forward, FftDirection::Inverse] {
                    let Some((entry, shape)) = interleaved::select::<T>(n, dir, isa) else {
                        continue;
                    };
                    let fft = Batch {
                        fallback: planner.plan_fft(n, dir),
                        plan: make_plan(n, dir),
                        lanes: shape.lanes,
                        entry,
                        stream_threshold: 0,
                    };
                    for count in [1, 3, 5, 8] {
                        let len = n * count;
                        let original: Vec<_> = random_c64(len, 78)
                            .iter()
                            .map(|c| {
                                Complex::new(T::from_f64(c.re).unwrap(), T::from_f64(c.im).unwrap())
                            })
                            .collect();
                        let mut want: Vec<_> = original
                            .iter()
                            .map(|c| Complex::new(c.re.to_f64().unwrap(), c.im.to_f64().unwrap()))
                            .collect();
                        let ref_fft = rustfft::FftPlanner::<f64>::new().plan_fft(
                            n,
                            if dir == FftDirection::Forward {
                                rustfft::FftDirection::Forward
                            } else {
                                rustfft::FftDirection::Inverse
                            },
                        );
                        ref_fft.process(&mut want);
                        for offset in [0, 1] {
                            for immutable in [false, true] {
                                let mut source = Box::new(Storage {
                                    data: [guard; 8224],
                                });
                                let mut target = Box::new(Storage {
                                    data: [guard; 8224],
                                });
                                let start = 64 / size_of::<Complex<T>>() + offset;
                                source.data[start..start + len].copy_from_slice(&original);
                                let need = if immutable {
                                    fft.get_immutable_scratch_len()
                                } else {
                                    fft.get_outofplace_scratch_len()
                                };
                                let mut scratch = vec![guard; need + 2];
                                if immutable {
                                    fft.process_immutable_with_scratch(
                                        &source.data[start..start + len],
                                        &mut target.data[start..start + len],
                                        &mut scratch[1..need + 1],
                                    );
                                } else {
                                    fft.process_outofplace_with_scratch(
                                        &mut source.data[start..start + len],
                                        &mut target.data[start..start + len],
                                        &mut scratch[1..need + 1],
                                    );
                                }
                                let e = error_vs_f64(&target.data[start..start + len], &want)
                                    .in_eps(T::epsilon().to_f64().unwrap());
                                assert!(
                                    e.rel_l2 <= fast_path_bound_eps(n)
                                        && e.max_rel <= fast_path_bound_eps(n),
                                    "{isa} n={n} count={count} dir={dir} offset={offset} immutable={immutable}: {e:?}"
                                );
                                assert_eq!(target.data[start - 1], guard);
                                assert_eq!(target.data[start + len], guard);
                                assert_eq!(source.data[start - 1], guard);
                                assert_eq!(source.data[start + len], guard);
                                assert_eq!(scratch[0], guard);
                                assert_eq!(scratch[need + 1], guard);
                                if immutable {
                                    assert_eq!(&source.data[start..start + len], &original);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    #[test]
    fn streaming_batches_f32_preserve_public_contracts() {
        forced_streaming::<f32>();
    }
    #[test]
    fn streaming_batches_f64_preserve_public_contracts() {
        forced_streaming::<f64>();
    }
}
