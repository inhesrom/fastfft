//! Four independent FFTs in interleaved complex rows. Shared Small kernels
//! keep rotations fused and avoid splitting each pair into two registers.
use super::*;
use crate::isa::Precision;
#[cfg(feature = "avx512")]
use crate::isa::x86::interleaved::R64z;
use crate::isa::x86::interleaved::{Quad, R32, R64, Row, radix4, radix8};

#[inline(always)]
unsafe fn pass<R: Row, const N: usize, const B: usize, const NS: usize, const INV: bool>(
    rows: &mut [R; N],
    tw: *const R::S,
) where
    R::S: Into<f64> + Default,
{
    // SAFETY: matching ISA, initialized rows, N divisible by B*NS, and
    // a table with B*NS complex factors. Each butterfly is loaded before stores.
    unsafe {
        let zero = R::signs(0.0, 0.0);
        for j in 0..NS {
            let mut cos = [zero; B];
            let mut sin = [zero; B];
            for k in 1..B {
                let c = (*tw.add(2 * (j * B + k))).into();
                let s = (*tw.add(2 * (j * B + k) + 1)).into() * if INV { -1.0 } else { 1.0 };
                cos[k] = R::signs(c, c);
                sin[k] = R::signs(-s, s);
            }
            for base in (0..N).step_by(B * NS) {
                let mut a = [zero; B];
                for k in 0..B {
                    a[k] = rows[base + j + k * NS];
                    if NS > 1 && j > 0 && k > 0 {
                        a[k] = a[k].swap().mul_add(sin[k], a[k].mul(cos[k]));
                    }
                }
                match B {
                    2 => {
                        let x = a[0];
                        let y = a[1];
                        a[0] = x.add(y);
                        a[1] = x.sub(y);
                    }
                    4 => {
                        let p = (&mut a as *mut [R; B]).cast::<[R; 4]>();
                        *p = radix4::<R, INV, false>(*p);
                    }
                    8 => {
                        let p = (&mut a as *mut [R; B]).cast::<[R; 8]>();
                        *p = radix8::<R, INV, false>(*p);
                    }
                    _ => unreachable!(),
                }
                for k in 0..B {
                    rows[base + j + k * NS] = a[k];
                }
            }
        }
    }
}

#[inline(always)]
unsafe fn run<R: Quad, const N: usize, const INV: bool>(
    plan: &Plan<R::S>,
    mut input: *const R::S,
    mut output: *mut R::S,
    groups: usize,
    streaming: bool,
) where
    R::S: Into<f64> + Default,
{
    // SAFETY: matching features and scalar precision, four full transforms
    // per group. All input is loaded before output; pointers may be identical.
    unsafe {
        if streaming && N <= 256 {
            leaf_stream::<R, N, INV>(plan, input, output, groups * 4);
            return;
        }
        let zero = R::signs(0.0, 0.0);
        let permutation = const { permutation::<N>() };
        let mut rows = [zero; N];
        for _ in 0..groups {
            for j in (0..N).step_by(4) {
                let a = R::transpose([
                    R::load(input.add(2 * j)),
                    R::load(input.add(2 * (N + j))),
                    R::load(input.add(2 * (2 * N + j))),
                    R::load(input.add(2 * (3 * N + j))),
                ]);
                for k in 0..4 {
                    rows[permutation[j + k]] = a[k];
                }
            }
            let tw = plan.twiddles.as_ptr();
            pass::<R, N, 8, 1, INV>(&mut rows, tw);
            if N == 16 {
                pass::<R, N, 2, 8, INV>(&mut rows, tw.add(16));
            } else if N == 32 {
                pass::<R, N, 4, 8, INV>(&mut rows, tw.add(16));
            } else if N >= 64 {
                pass::<R, N, 8, 8, INV>(&mut rows, tw.add(16));
                if N == 128 {
                    pass::<R, N, 2, 64, INV>(&mut rows, tw.add(144));
                } else if N == 256 {
                    pass::<R, N, 4, 64, INV>(&mut rows, tw.add(144));
                } else if N >= 512 {
                    pass::<R, N, 8, 64, INV>(&mut rows, tw.add(144));
                    if N == 1024 {
                        pass::<R, N, 2, 512, INV>(&mut rows, tw.add(1168));
                    }
                }
            }
            for j in (0..N).step_by(4) {
                let a = R::transpose([rows[j], rows[j + 1], rows[j + 2], rows[j + 3]]);
                for (t, r) in a.into_iter().enumerate() {
                    let p = output.add(2 * (t * N + j));
                    if streaming {
                        r.stream_store(p);
                    } else {
                        r.store(p);
                    }
                }
            }
            input = input.add(8 * N);
            output = output.add(8 * N);
        }
        if streaming {
            R::stream_fence();
        }
    }
}

#[inline(always)]
unsafe fn leaf_stream<R: Quad, const N: usize, const INV: bool>(
    plan: &Plan<R::S>,
    mut input: *const R::S,
    mut output: *mut R::S,
    count: usize,
) where
    R::S: Default,
{
    // SAFETY: N<=256, matching leaf table and ISA, complete disjoint buffers.
    // Output is 64-byte aligned, and every row occupies a whole vector.
    unsafe {
        let mut tmp = [[R::S::default(); 2]; N];
        let p = tmp.as_mut_ptr().cast::<R::S>();
        for _ in 0..count {
            R::leaf::<N, INV, false>(input, p, plan.leaf_twiddles.as_ptr());
            for j in (0..2 * N).step_by(R::W) {
                R::load(p.add(j)).stream_store(output.add(j));
            }
            input = input.add(2 * N);
            output = output.add(2 * N);
        }
        R::stream_fence();
    }
}

macro_rules! entry {
    ($name:ident,$s:ty,$r:ty,$features:literal) => {
        #[target_feature(enable=$features)]
        unsafe fn $name<const N: usize, const INV: bool>(
            plan: &Plan<$s>,
            input: *const $s,
            output: *mut $s,
            groups: usize,
            streaming: bool,
        ) {
            // SAFETY: forwarded buffers; this boundary enables R's features.
            unsafe { run::<$r, N, INV>(plan, input, output, groups, streaming) }
        }
    };
}
entry!(a32, f32, R32, "avx2,fma");
entry!(a64, f64, R64, "avx2,fma");
#[cfg(feature = "avx512")]
entry!(
    y32,
    f32,
    R32,
    "avx512f,avx512vl,avx512dq,avx512bw,avx512cd,avx2,fma"
);
#[cfg(feature = "avx512")]
entry!(
    y64,
    f64,
    R64,
    "avx512f,avx512vl,avx512dq,avx512bw,avx512cd,avx2,fma"
);
#[cfg(feature = "avx512")]
entry!(
    z64,
    f64,
    R64z,
    "avx512f,avx512vl,avx512dq,avx512bw,avx512cd,avx2,fma"
);

fn entry<T: FftNum, const N: usize, const INV: bool>(isa: Isa) -> Entry<T> {
    // SAFETY: FftNum is sealed and each arm checks the exact scalar type.
    unsafe {
        match (T::precision(), isa) {
            (Precision::F32, Isa::Avx2) => {
                core::mem::transmute::<Entry<f32>, Entry<T>>(a32::<N, INV>)
            }
            (Precision::F64, Isa::Avx2) => {
                core::mem::transmute::<Entry<f64>, Entry<T>>(a64::<N, INV>)
            }
            #[cfg(feature = "avx512")]
            (Precision::F32, Isa::Avx512Ymm) => {
                core::mem::transmute::<Entry<f32>, Entry<T>>(y32::<N, INV>)
            }
            #[cfg(feature = "avx512")]
            (Precision::F64, Isa::Avx512Ymm) => {
                core::mem::transmute::<Entry<f64>, Entry<T>>(y64::<N, INV>)
            }
            #[cfg(feature = "avx512")]
            (Precision::F64, Isa::Avx512) => {
                core::mem::transmute::<Entry<f64>, Entry<T>>(z64::<N, INV>)
            }
            _ => unreachable!(),
        }
    }
}

pub(super) fn select<T: FftNum>(
    n: usize,
    dir: FftDirection,
    isa: Isa,
) -> Option<(Entry<T>, Shape)> {
    if !(8..=1024).contains(&n) || !n.is_power_of_two() || isa < Isa::Avx2 {
        return None;
    }
    let isa = if T::precision() == Precision::F32 && isa == Isa::Avx512 {
        Isa::Avx512Ymm
    } else {
        isa
    };
    macro_rules! size {
        ($n:literal) => {
            if dir == FftDirection::Inverse {
                entry::<T, $n, true>(isa)
            } else {
                entry::<T, $n, false>(isa)
            }
        };
    }
    let entry = match n {
        8 => size!(8),
        16 => size!(16),
        32 => size!(32),
        64 => size!(64),
        128 => size!(128),
        256 => size!(256),
        512 => size!(512),
        1024 => size!(1024),
        _ => unreachable!(),
    };
    Some((entry, Shape { isa, lanes: 4 }))
}
