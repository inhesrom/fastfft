//! `FftPlanner`: chooses engine, tier, vector width and radices.

use crate::api::{Fft, FftDirection, FftNum};
use crate::engine::bluestein::BluesteinPlan;
use crate::engine::stockham::StockhamPlan;
use crate::engine::{Shape, fixed, fourstep, shapes, small};
use crate::fft::{FftImpl, Kernel};
use crate::isa::{Isa, Precision, effective_isa};
use std::collections::HashMap;
use std::sync::Arc;
use std::time::Duration;

/// How much effort planning spends.
#[non_exhaustive]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub enum PlanMode {
    /// Pick the plan with the lowest predicted cost (fast, deterministic).
    #[default]
    Estimate,
    /// Time the best predicted candidates for up to `time_limit` and keep
    /// the fastest.
    Measure {
        /// Total time budget for measuring candidates of one plan.
        time_limit: Duration,
    },
}

/// Planner configuration.
#[non_exhaustive]
#[derive(Clone, Copy, Debug, Default, PartialEq, Eq)]
pub struct PlannerOptions {
    /// Planning effort.
    pub mode: PlanMode,
    /// Highest instruction-set tier to use. Can only lower the detected tier
    /// (as can the `FASTFFT_ISA_CAP` environment variable).
    pub isa_cap: Option<Isa>,
}

impl PlannerOptions {
    /// Options with the given instruction-set cap.
    pub fn with_isa_cap(mut self, isa: Isa) -> Self {
        self.isa_cap = Some(isa);
        self
    }

    /// Options with the given plan mode.
    pub fn with_mode(mut self, mode: PlanMode) -> Self {
        self.mode = mode;
        self
    }
}

/// Plans FFTs and caches them by length and direction, like RustFFT's
/// `FftPlanner`.
pub struct FftPlanner<T: FftNum> {
    options: PlannerOptions,
    isa: Isa,
    cache: HashMap<(usize, FftDirection), CachedPlan<T>>,
}

struct CachedPlan<T: FftNum> {
    fft: Arc<dyn Fft<T>>,
    description: String,
}

impl<T: FftNum> CachedPlan<T> {
    fn existing(fft: FftImpl<T>) -> Self {
        Self {
            description: fft.description().to_string(),
            fft: Arc::new(fft),
        }
    }
}

impl<T: FftNum> std::fmt::Debug for FftPlanner<T> {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        f.debug_struct("FftPlanner")
            .field("options", &self.options)
            .field("isa", &self.isa)
            .field("cached", &self.cache.len())
            .finish()
    }
}

impl<T: FftNum> Default for FftPlanner<T> {
    fn default() -> Self {
        Self::new()
    }
}

/// Largest prime handled by codelets; larger prime factors use Bluestein.
const MAX_CODELET_PRIME: usize = 13;
/// Radices with generated codelets usable in Stockham passes.
const PASS_RADICES: &[usize] = &[2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16];

pub(crate) fn factorize(mut n: usize) -> Vec<usize> {
    let mut f = Vec::new();
    let mut p = 2;
    while p * p <= n {
        while n.is_multiple_of(p) {
            f.push(p);
            n /= p;
        }
        p += 1;
    }
    if n > 1 {
        f.push(n);
    }
    f
}

pub(crate) fn is_smooth(n: usize) -> bool {
    factorize(n).iter().all(|&p| p <= MAX_CODELET_PRIME)
}

/// Relative cost per element of one pass of radix `r` (FP ops per element
/// from the generated codelets plus a memory term).
fn pass_cost(r: usize, twiddled: bool) -> f64 {
    let ops = crate::codelets::op_count(r, twiddled) as f64 / r as f64;
    // split layout: loads/stores of 2 reals per element per pass, weighted
    ops * 0.5 + 3.0
}

/// Splits `m` into codelet radices (each <= `max_pow2` for powers of two),
/// minimizing passes first and estimated arithmetic second.
pub(crate) fn choose_radices(m: usize, max_pow2: usize) -> Option<Vec<usize>> {
    if m == 1 {
        return Some(Vec::new());
    }
    // Dynamic programming over divisors: best[(d)] = (passes, cost, radices)
    type Best = Option<(usize, f64, Vec<usize>)>;
    let mut memo: HashMap<usize, Best> = HashMap::new();
    fn go(m: usize, max_pow2: usize, first: bool, memo: &mut HashMap<usize, Best>) -> Best {
        if m == 1 {
            return Some((0, 0.0, Vec::new()));
        }
        if !first && let Some(v) = memo.get(&m) {
            return v.clone();
        }
        let mut best: Best = None;
        for &r in PASS_RADICES {
            if !m.is_multiple_of(r) || (r.is_power_of_two() && r > max_pow2) {
                continue;
            }
            if let Some((p, c, rs)) = go(m / r, max_pow2, false, memo) {
                let cand = (p + 1, c + pass_cost(r, !first), {
                    let mut v = vec![r];
                    v.extend(rs);
                    v
                });
                let better = match &best {
                    None => true,
                    Some(b) => cand.0 < b.0 || (cand.0 == b.0 && cand.1 < b.1),
                };
                if better {
                    best = Some(cand);
                }
            }
        }
        if !first {
            memo.insert(m, best.clone());
        }
        best
    }
    go(m, max_pow2, true, &mut memo).map(|b| b.2)
}

/// Private engine identity; narrow Small shapes never enter Stockham enumeration.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub(crate) enum CandidateKernel {
    Stockham,
    FourStep,
    GenericSmall,
    InterleavedSmall,
    RectangularSmall,
}

impl CandidateKernel {
    pub(crate) fn name(self) -> &'static str {
        match self {
            Self::Stockham => "stockham",
            Self::FourStep => "fourstep",
            Self::GenericSmall => "generic",
            Self::InterleavedSmall => "interleaved",
            Self::RectangularSmall => "rectangular",
        }
    }
    pub(crate) fn is_small(self) -> bool {
        matches!(
            self,
            Self::GenericSmall | Self::InterleavedSmall | Self::RectangularSmall
        )
    }
    /// Fixed-size leaves kept inside Measure's candidate window.
    pub(crate) fn is_leaf(self) -> bool {
        self == Self::InterleavedSmall
    }
}

/// A candidate configuration with its predicted cost.
#[derive(Clone, Debug)]
pub(crate) struct Candidate {
    pub kernel: CandidateKernel,
    pub shape: Shape,
    pub radices: Vec<usize>,
    pub cost: f64,
}

/// Predicted cost (arbitrary units ~ cycles per element) of a shape.
fn predict(n: usize, shape: Shape, radices: &[usize]) -> f64 {
    let l = shape.lanes;
    // Per-element throughput is the same for 128/256/512-bit on the
    // targets we tune for; instruction count scales with 1/width.
    let width_factor = match l {
        1 => 4.0,
        2 => 1.6,
        4 => 1.15,
        _ => 1.0,
    };
    let mut c = 0.0;
    for (i, &r) in radices.iter().enumerate() {
        c += pass_cost(r, i > 0);
    }
    // Phase B: transposes (log2 L stages) + a twiddled DFT-L across registers
    // (L = 16 in split layout needs 32 data registers and spills).
    if l > 1 {
        let lg = l.trailing_zeros() as f64;
        c += pass_cost(l, true) + 1.5 * lg + if l >= 16 { 6.0 } else { 0.0 };
    }
    // Partial Phase B blocks waste lanes; tiny transforms pay fixed overhead.
    let m = n / l;
    let blocks = m.div_ceil(l).max(1);
    let waste = (blocks * l) as f64 / m.max(1) as f64;
    c * width_factor * waste + 40.0 / n as f64
}

pub(crate) fn stockham_candidates(n: usize, isa: Isa, f64_: bool) -> Vec<Candidate> {
    let mut v = Vec::new();
    for shape in shapes(isa, f64_) {
        let l = shape.lanes;
        if !n.is_multiple_of(l) || (l > 1 && n < 2 * l) {
            continue;
        }
        // 16 split data registers fit only with 32 architectural registers.
        let max_pow2 = match shape.isa {
            Isa::Scalar => 16,
            _ => 8,
        };
        let m = n / l;
        if let Some(r) = choose_radices(m, max_pow2) {
            let cost = predict(n, shape, &r);
            v.push(Candidate {
                kernel: CandidateKernel::Stockham,
                shape,
                radices: r,
                cost,
            });
        }
    }
    v.sort_by(|a, b| a.cost.total_cmp(&b.cost));
    v
}

/// Zen 4 preference measured in M2 (ADR-0001): 256-bit vectors with 32
/// registers beat 512-bit for f32 in split layout.
fn prefer(c: &mut [Candidate], f64_: bool) {
    for cand in c.iter_mut() {
        if cand.shape.isa == Isa::Avx512 && !f64_ {
            cand.cost *= 1.25;
        }
    }
    c.sort_by(|a, b| a.cost.total_cmp(&b.cost));
}

/// Smallest cheap inner length for Bluestein: `2^a * {1, 3, 5, 9}` >= 2n - 1.
fn bluestein_inner(n: usize) -> usize {
    let min = 2 * n - 1;
    [1usize, 3, 5, 9]
        .iter()
        .map(|&mult| {
            let mut m = mult;
            while m < min {
                m *= 2;
            }
            m
        })
        .min()
        .expect("non-empty")
}

impl<T: FftNum> FftPlanner<T> {
    /// A planner with default options (`Estimate`, detected tier).
    pub fn new() -> Self {
        Self::with_options(PlannerOptions::default())
    }

    /// A planner with the given options.
    pub fn with_options(options: PlannerOptions) -> Self {
        FftPlanner {
            options,
            isa: effective_isa(options.isa_cap),
            cache: HashMap::new(),
        }
    }

    /// The instruction-set tier this planner uses.
    pub fn isa(&self) -> Isa {
        self.isa
    }

    /// Plans an FFT of `len` in `direction`.
    pub fn plan_fft(&mut self, len: usize, direction: FftDirection) -> Arc<dyn Fft<T>> {
        self.plan_impl(len, direction)
    }

    /// Plans a forward FFT.
    pub fn plan_fft_forward(&mut self, len: usize) -> Arc<dyn Fft<T>> {
        self.plan_fft(len, FftDirection::Forward)
    }

    /// Plans an inverse (unnormalized) FFT.
    pub fn plan_fft_inverse(&mut self, len: usize) -> Arc<dyn Fft<T>> {
        self.plan_fft(len, FftDirection::Inverse)
    }

    /// Describes the plan chosen for `len`, e.g.
    /// `stockham avx512-ymm L=8 radices=8x8x8 scratch=4104`.
    pub fn describe_plan(&mut self, len: usize, direction: FftDirection) -> String {
        self.plan_impl(len, direction);
        self.cache[&(len, direction)].description.clone()
    }

    fn plan_impl(&mut self, len: usize, dir: FftDirection) -> Arc<dyn Fft<T>> {
        if let Some(p) = self.cache.get(&(len, dir)) {
            return Arc::clone(&p.fft);
        }
        let mut plan = self.build(len, dir);
        let (fft, batch_shape) = crate::engine::batch::wrap(plan.fft, self.isa);
        plan.fft = fft;
        if let Some(shape) = batch_shape {
            plan.description
                .push_str(&format!(" batch={} lanes={}", shape.isa, shape.lanes));
        }
        let fft = Arc::clone(&plan.fft);
        self.cache.insert((len, dir), plan);
        fft
    }

    fn build(&mut self, len: usize, dir: FftDirection) -> CachedPlan<T> {
        if len <= 1 {
            return CachedPlan::existing(FftImpl::new(
                len,
                dir,
                Kernel::Identity,
                format!("identity n={len}"),
            ));
        }
        let f64_ = T::precision() == Precision::F64;
        if is_smooth(len) {
            let cands = candidates(len, self.isa, f64_);
            let chosen = match self.options.mode {
                PlanMode::Estimate => cands.first().cloned(),
                PlanMode::Measure { time_limit } => {
                    crate::measure::pick::<T>(len, dir, &cands, time_limit)
                }
            };
            if let Some(c) = chosen {
                if c.kernel == CandidateKernel::FourStep {
                    return CachedPlan::existing(fourstep_candidate(len, dir, &c));
                }
                if c.kernel.is_small() {
                    let (a, b) = if c.kernel == CandidateKernel::RectangularSmall {
                        (c.radices[0], c.radices[1])
                    } else {
                        (len / c.shape.lanes, c.shape.lanes)
                    };
                    let description = format!(
                        "small {} n={len} decomposition={}x{} scratch=0 kernel={}",
                        c.shape.isa,
                        a,
                        b,
                        c.kernel.name()
                    );
                    return CachedPlan {
                        fft: build_candidate(len, dir, &c),
                        description,
                    };
                }
                if let Some(fft) = fixed::build(len, dir, c.shape, &c.radices) {
                    let description = format!(
                        "stockham {} split L={} radices={} fixed n={len} scratch={}",
                        c.shape.isa,
                        c.shape.lanes,
                        c.radices
                            .iter()
                            .map(usize::to_string)
                            .collect::<Vec<_>>()
                            .join("x"),
                        fft.get_inplace_scratch_len()
                    );
                    return CachedPlan { fft, description };
                }
                return CachedPlan::existing(self.stockham(len, dir, c));
            }
        }
        // Bluestein over a fast inner length.
        let m = bluestein_inner(len);
        let inner = self.plan_impl(m, FftDirection::Forward);
        let b = BluesteinPlan::new(len, inner);
        let desc = format!(
            "bluestein n={len} m={} inner=[{}]",
            b.m,
            self.cache[&(m, FftDirection::Forward)].description
        );
        CachedPlan::existing(FftImpl::new(len, dir, Kernel::Bluestein(b), desc))
    }

    fn stockham(&self, len: usize, dir: FftDirection, c: Candidate) -> FftImpl<T> {
        let radices: Vec<String> = c.radices.iter().map(|r| r.to_string()).collect();
        let plan = StockhamPlan::<T>::new(len, c.shape.lanes, c.radices.clone());
        let imp = FftImpl::new(
            len,
            dir,
            Kernel::Stockham {
                shape: c.shape,
                plan,
            },
            String::new(),
        );
        let desc = format!(
            "stockham {} split L={} radices={} scratch={}",
            c.shape.isa,
            c.shape.lanes,
            if radices.is_empty() {
                "-".into()
            } else {
                radices.join("x")
            },
            crate::api::Fft::get_inplace_scratch_len(&imp)
        );
        let Kernel::Stockham { shape, plan } = imp.into_kernel() else {
            unreachable!()
        };
        FftImpl::new(len, dir, Kernel::Stockham { shape, plan }, desc)
    }
}

/// Builds a Stockham plan for an explicit candidate (used by Measure mode).
pub(crate) fn build_candidate<T: FftNum>(
    len: usize,
    dir: FftDirection,
    c: &Candidate,
) -> Arc<dyn Fft<T>> {
    match c.kernel {
        CandidateKernel::FourStep => return Arc::new(fourstep_candidate(len, dir, c)),
        CandidateKernel::GenericSmall => return small::build(len, dir, c.shape),
        CandidateKernel::InterleavedSmall => return small::build_interleaved(len, dir, c.shape),
        CandidateKernel::RectangularSmall => {
            return small::build_rectangular(dir, c.shape, c.radices[0], c.radices[1]);
        }
        CandidateKernel::Stockham => {}
    }
    if let Some(fft) = fixed::build(len, dir, c.shape, &c.radices) {
        return fft;
    }
    let plan = StockhamPlan::<T>::new(len, c.shape.lanes, c.radices.clone());
    Arc::new(FftImpl::new(
        len,
        dir,
        Kernel::Stockham {
            shape: c.shape,
            plan,
        },
        String::new(),
    ))
}

fn fourstep_candidate<T: FftNum>(len: usize, dir: FftDirection, c: &Candidate) -> FftImpl<T> {
    let plan = fourstep::FourStepPlan::new(len, c.radices[0], c.shape.lanes);
    let description = format!(
        "fourstep {} split L={} decomposition={}x{} scratch={}",
        c.shape.isa,
        c.shape.lanes,
        plan.a,
        plan.b,
        plan.scratch_len() + crate::fft::align_slack::<T>()
    );
    FftImpl::new(
        len,
        dir,
        Kernel::FourStep {
            shape: c.shape,
            plan,
        },
        description,
    )
}

/// Candidate ordering keeps Estimate first and a Stockham alternative second.
/// The measured Small dispatch table is deliberately separate from the general
/// cost model (ticket 18).
pub(crate) fn candidates(n: usize, isa: Isa, f64_: bool) -> Vec<Candidate> {
    let mut stockham = stockham_candidates(n, isa, f64_);
    prefer(&mut stockham, f64_);
    let direct = [Isa::Avx2, Isa::Avx512Ymm]
        .into_iter()
        .filter(|&i| i <= isa && crate::isa::available(i))
        .map(|isa| Shape { isa, lanes: 1 });
    let mut smalls: Vec<_> = shapes(isa, f64_)
        .into_iter()
        .chain(direct)
        .filter(|&shape| small::eligible(n, shape))
        .map(|shape| Candidate {
            kernel: CandidateKernel::GenericSmall,
            shape,
            radices: vec![n / shape.lanes],
            cost: 0.0,
        })
        .collect();
    // Seed with the existing Stockham choice; only the small-range table
    // changes Estimate. Keep the opposite engine among Measure's first eight.
    let mut result = Vec::new();
    result.append(&mut stockham);
    result.append(&mut smalls);
    result.extend(
        small::interleaved_shapes(n, isa, f64_)
            .into_iter()
            .map(|shape| Candidate {
                kernel: CandidateKernel::InterleavedSmall,
                shape,
                radices: vec![n / shape.lanes],
                cost: 0.0,
            }),
    );
    if let Some((kernel, shape)) = crate::small_dispatch::preferred(n, isa, f64_)
        && let Some(index) = result
            .iter()
            .position(|c| c.kernel == kernel && c.shape == shape)
    {
        let chosen = result.remove(index);
        result.insert(0, chosen);
    }
    // SIMD panels also cover large even lengths, where cache locality can
    // matter more than the cost model's arithmetic estimate.
    let ss = shapes(isa, f64_);
    if !result.is_empty()
        && n > 16
        && (n >= 32768 || ss.first().is_some_and(|s| !n.is_multiple_of(s.lanes)))
        && let Some(a) = fourstep::decomposition(n)
    {
        for (offset, shape) in ss.into_iter().filter(|s| s.lanes > 1).enumerate() {
            result.insert(
                1 + offset,
                Candidate {
                    kernel: CandidateKernel::FourStep,
                    shape,
                    radices: vec![a, n / a],
                    cost: 0.0,
                },
            );
        }
    }
    result.splice(
        2.min(result.len())..2.min(result.len()),
        small::rectangular_candidates(n, isa, f64_),
    );
    // Keep the incumbent first while exposing two-pass orderings for the
    // transition sizes. The original cost model does not price register spills.
    if matches!(n, 108 | 120 | 240 | 504 | 720) {
        for shape in shapes(isa, f64_) {
            if !n.is_multiple_of(shape.lanes) {
                continue;
            }
            let m = n / shape.lanes;
            for &a in PASS_RADICES {
                if !m.is_multiple_of(a) {
                    continue;
                }
                let b = m / a;
                if !PASS_RADICES.contains(&b)
                    || (shape.isa != Isa::Scalar
                        && [a, b].iter().any(|r| r.is_power_of_two() && *r > 8))
                {
                    continue;
                }
                let radices = vec![a, b];
                if !result.iter().any(|c| {
                    c.kernel == CandidateKernel::Stockham
                        && c.shape == shape
                        && c.radices == radices
                }) {
                    result.push(Candidate {
                        kernel: CandidateKernel::Stockham,
                        shape,
                        radices,
                        cost: f64::INFINITY,
                    });
                }
            }
        }
    }
    if let Some((kernel, shape, radices)) = crate::smooth_dispatch::preferred(n, isa, f64_)
        && let Some(index) = result
            .iter()
            .position(|c| c.kernel == kernel && c.shape == shape && c.radices == radices)
    {
        let chosen = result.remove(index);
        result.insert(0, chosen);
    }
    if let Some(first) = result.first()
        && let Some(index) = result
            .iter()
            .position(|c| c.kernel.is_small() != first.kernel.is_small())
    {
        let alternative = result.remove(index);
        result.insert(1, alternative);
    }
    // Retain the original Stockham estimate immediately behind the measured
    // large-N choice, so Measure can still compare the two engines.
    if let Some(chosen) = crate::large_dispatch::preferred(n, isa, f64_) {
        if let Some(index) = result.iter().position(|c| {
            c.kernel == chosen.kernel && c.shape == chosen.shape && c.radices == chosen.radices
        }) {
            result.remove(index);
        }
        result.insert(0, chosen);
    }
    // Specializations and the incumbent must fit in Measure's unchanged
    // eight-candidate window. Never evict Estimate or the opposite engine.
    let mut slot = 2.min(result.len());
    while let Some(index) = result
        .iter()
        .enumerate()
        .skip(slot)
        .find_map(|(i, c)| c.kernel.is_leaf().then_some(i))
    {
        let candidate = result.remove(index);
        result.insert(slot, candidate);
        slot += 1;
    }
    if let Some((kernel, shape)) = crate::small_dispatch::incumbent(n, isa, f64_)
        && let Some(index) = result
            .iter()
            .position(|c| c.kernel == kernel && c.shape == shape)
        && index >= 8
    {
        let candidate = result.remove(index);
        result.insert(slot.min(7), candidate);
    }
    result
}
