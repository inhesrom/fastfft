//! SIMD across independent transforms, with register transposes at the edges.
//!
//! A bounded stack tile keeps public scratch contracts unchanged. Calls with
//! fewer than a vector of transforms and the final remainder use the original
//! single-transform plan. No caller buffer is used as intermediate storage.

use crate::api::{Direction, Fft, FftDirection, FftNum, Length};
use crate::engine::{Shape, shapes, stockham::transpose};
use crate::fft::{fail_inplace, fail_outofplace};
use crate::isa::{Isa, Precision, Vector};
use num_complex::Complex;
use std::sync::Arc;

struct Plan<T> {
    radices: Vec<usize>,
    permutation: Vec<usize>,
    twiddles: Vec<T>,
}

type Entry<T> = unsafe fn(&Plan<T>, *const T, *mut T, usize);

struct Batch<T: FftNum> {
    fallback: Arc<dyn Fft<T>>,
    plan: Plan<T>,
    lanes: usize,
    entry: Entry<T>,
}

impl<T: FftNum> Length for Batch<T> {
    fn len(&self) -> usize {
        self.fallback.len()
    }
}
impl<T: FftNum> Direction for Batch<T> {
    fn fft_direction(&self) -> FftDirection {
        self.fallback.fft_direction()
    }
}
impl<T: FftNum> Batch<T> {
    /// Complete buffers for count transforms; input equals output or is
    /// disjoint. The entry processes only full groups, preserving the input.
    unsafe fn groups(
        &self,
        input: *const Complex<T>,
        output: *mut Complex<T>,
        count: usize,
    ) -> usize {
        let groups = count / self.lanes;
        // SAFETY: constructor verifies precision and ISA; the public wrappers
        // validate complete buffers before the first store.
        unsafe { (self.entry)(&self.plan, input.cast(), output.cast(), groups) };
        groups * self.lanes * self.len()
    }
}
impl<T: FftNum> Fft<T> for Batch<T> {
    fn process_with_scratch(&self, buffer: &mut [Complex<T>], scratch: &mut [Complex<T>]) {
        let n = self.len();
        let need = self.get_inplace_scratch_len();
        if buffer.len() < n || !buffer.len().is_multiple_of(n) || scratch.len() < need {
            fail_inplace(n, buffer.len(), need, scratch.len());
        }
        if buffer.len() / n < self.lanes {
            return self.fallback.process_with_scratch(buffer, scratch);
        }
        // SAFETY: complete aliased buffers validated above.
        let done = unsafe { self.groups(buffer.as_ptr(), buffer.as_mut_ptr(), buffer.len() / n) };
        if done < buffer.len() {
            self.fallback
                .process_with_scratch(&mut buffer[done..], scratch);
        }
    }
    fn process_outofplace_with_scratch(
        &self,
        input: &mut [Complex<T>],
        output: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) {
        let n = self.len();
        let need = self.get_outofplace_scratch_len();
        if input.len() != output.len()
            || input.len() < n
            || !input.len().is_multiple_of(n)
            || scratch.len() < need
        {
            fail_outofplace(n, input.len(), output.len(), need, scratch.len());
        }
        if input.len() / n < self.lanes {
            return self
                .fallback
                .process_outofplace_with_scratch(input, output, scratch);
        }
        // SAFETY: complete disjoint buffers validated above.
        let done = unsafe { self.groups(input.as_ptr(), output.as_mut_ptr(), input.len() / n) };
        if done < input.len() {
            self.fallback.process_outofplace_with_scratch(
                &mut input[done..],
                &mut output[done..],
                scratch,
            );
        }
    }
    fn process_immutable_with_scratch(
        &self,
        input: &[Complex<T>],
        output: &mut [Complex<T>],
        scratch: &mut [Complex<T>],
    ) {
        let n = self.len();
        let need = self.get_immutable_scratch_len();
        if input.len() != output.len()
            || input.len() < n
            || !input.len().is_multiple_of(n)
            || scratch.len() < need
        {
            fail_outofplace(n, input.len(), output.len(), need, scratch.len());
        }
        if input.len() / n < self.lanes {
            return self
                .fallback
                .process_immutable_with_scratch(input, output, scratch);
        }
        // SAFETY: complete disjoint buffers validated above; entry never writes input.
        let done = unsafe { self.groups(input.as_ptr(), output.as_mut_ptr(), input.len() / n) };
        if done < input.len() {
            self.fallback.process_immutable_with_scratch(
                &input[done..],
                &mut output[done..],
                scratch,
            );
        }
    }
    fn get_inplace_scratch_len(&self) -> usize {
        self.fallback.get_inplace_scratch_len()
    }
    fn get_outofplace_scratch_len(&self) -> usize {
        self.fallback.get_outofplace_scratch_len()
    }
    fn get_immutable_scratch_len(&self) -> usize {
        self.fallback.get_immutable_scratch_len()
    }
}

#[inline(always)]
unsafe fn shuffle<V: Vector>(rows: &mut [V; 16]) {
    // SAFETY: the selected array prefix contains exactly V::LANES rows.
    unsafe {
        match V::LANES {
            2 => transpose::<V, 2>(&mut *rows.as_mut_ptr().cast()),
            4 => transpose::<V, 4>(&mut *rows.as_mut_ptr().cast()),
            8 => transpose::<V, 8>(&mut *rows.as_mut_ptr().cast()),
            16 => transpose::<V, 16>(rows),
            _ => unreachable!(),
        }
    }
}

#[inline(always)]
unsafe fn pass<V: Vector, const R: usize>(re: &mut [V], im: &mut [V], ns: usize, tw: *const V::S) {
    // SAFETY: re/im contain N initialized vectors, N is divisible by R*ns,
    // and tw holds R*ns complex factors. All accesses stay in those slices.
    unsafe {
        let zero = V::splat_f64(0.0);
        for j in 0..ns {
            let mut wr = [zero; R];
            let mut wi = [zero; R];
            for k in 1..R {
                wr[k] = V::splat(*tw.add(2 * (j * R + k)));
                wi[k] = V::splat(*tw.add(2 * (j * R + k) + 1));
            }
            for base in (0..re.len()).step_by(R * ns) {
                let mut a = [zero; R];
                let mut b = [zero; R];
                for k in 0..R {
                    a[k] = re[base + j + k * ns];
                    b[k] = im[base + j + k * ns];
                }
                if ns == 1 {
                    crate::codelets::generated::small_notw::<V, R>(&mut a, &mut b);
                } else {
                    crate::codelets::generated::small_tw::<V, R>(&mut a, &mut b, &wr, &wi);
                }
                for k in 0..R {
                    re[base + j + k * ns] = a[k];
                    im[base + j + k * ns] = b[k];
                }
            }
        }
    }
}

#[inline(always)]
unsafe fn run<V: Vector, const N: usize, const INV: bool>(
    plan: &Plan<V::S>,
    mut input: *const V::S,
    mut output: *mut V::S,
    groups: usize,
) {
    // SAFETY: matching features, precision, permutation and complete groups.
    // Every tile is loaded before stores, allowing identical input/output.
    unsafe {
        let l = V::LANES;
        let zero = V::splat_f64(0.0);
        let mut re = [zero; N];
        let mut im = [zero; N];
        for _ in 0..groups {
            for j in (0..N).step_by(l) {
                let mut a = [zero; 16];
                let mut b = [zero; 16];
                for t in 0..l {
                    let p = input.add(2 * (t * N + j));
                    let (r, i) = V::deinterleave(V::load(p), V::load(p.add(l)));
                    (a[t], b[t]) = if INV { (i, r) } else { (r, i) };
                }
                shuffle::<V>(&mut a);
                shuffle::<V>(&mut b);
                for k in 0..l {
                    re[plan.permutation[j + k]] = a[k];
                    im[plan.permutation[j + k]] = b[k];
                }
            }
            let mut ns = 1;
            let mut offset = 0;
            for &r in &plan.radices {
                let tw = plan.twiddles.as_ptr().add(offset);
                match r {
                    2 => pass::<V, 2>(&mut re, &mut im, ns, tw),
                    4 => pass::<V, 4>(&mut re, &mut im, ns, tw),
                    8 => pass::<V, 8>(&mut re, &mut im, ns, tw),
                    _ => unreachable!(),
                }
                offset += 2 * r * ns;
                ns *= r;
            }
            for j in (0..N).step_by(l) {
                let mut a = [zero; 16];
                let mut b = [zero; 16];
                a[..l].copy_from_slice(&re[j..j + l]);
                b[..l].copy_from_slice(&im[j..j + l]);
                shuffle::<V>(&mut a);
                shuffle::<V>(&mut b);
                for t in 0..l {
                    let p = output.add(2 * (t * N + j));
                    let (lo, hi) = if INV {
                        V::interleave(b[t], a[t])
                    } else {
                        V::interleave(a[t], b[t])
                    };
                    V::store(p, lo);
                    V::store(p.add(l), hi);
                }
            }
            input = input.add(2 * N * l);
            output = output.add(2 * N * l);
        }
    }
}

#[allow(unused_macros)]
macro_rules! entry {
    ($name:ident, $s:ty, $v:ty, $features:literal) => {
        #[target_feature(enable = $features)]
        unsafe fn $name<const N: usize, const INV: bool>(
            plan: &Plan<$s>,
            input: *const $s,
            output: *mut $s,
            groups: usize,
        ) {
            // SAFETY: forwarded complete-group contract; features match V.
            unsafe { run::<$v, N, INV>(plan, input, output, groups) }
        }
    };
}
#[cfg(all(target_arch = "x86_64", feature = "sse2"))]
entry!(s32, f32, crate::isa::x86::F32x4, "sse2");
#[cfg(all(target_arch = "x86_64", feature = "sse2"))]
entry!(s64, f64, crate::isa::x86::F64x2, "sse2");
#[cfg(all(target_arch = "x86_64", feature = "avx2"))]
entry!(a32, f32, crate::isa::x86::F32x8, "avx2,fma");
#[cfg(all(target_arch = "x86_64", feature = "avx2"))]
entry!(a64, f64, crate::isa::x86::F64x4, "avx2,fma");
#[cfg(all(target_arch = "x86_64", feature = "avx512"))]
entry!(
    y32,
    f32,
    crate::isa::x86::F32x8v,
    "avx512f,avx512vl,avx512dq,avx512bw,avx512cd,avx2,fma"
);
#[cfg(all(target_arch = "x86_64", feature = "avx512"))]
entry!(
    y64,
    f64,
    crate::isa::x86::F64x4v,
    "avx512f,avx512vl,avx512dq,avx512bw,avx512cd,avx2,fma"
);
#[cfg(all(target_arch = "x86_64", feature = "avx512"))]
entry!(
    z32,
    f32,
    crate::isa::x86::F32x16,
    "avx512f,avx512vl,avx512dq,avx512bw,avx512cd,avx2,fma"
);
#[cfg(all(target_arch = "x86_64", feature = "avx512"))]
entry!(
    z64,
    f64,
    crate::isa::x86::F64x8,
    "avx512f,avx512vl,avx512dq,avx512bw,avx512cd,avx2,fma"
);

fn select<T: FftNum, const N: usize, const INV: bool>(shape: Shape) -> Entry<T> {
    // SAFETY: FftNum is sealed; each match checks the exact scalar type of
    // the function signature. The pointer is only called after ISA validation.
    unsafe {
        match (T::precision(), shape.isa) {
            #[cfg(all(target_arch = "x86_64", feature = "sse2"))]
            (Precision::F32, Isa::Sse2) => core::mem::transmute(s32::<N, INV> as Entry<f32>),
            #[cfg(all(target_arch = "x86_64", feature = "sse2"))]
            (Precision::F64, Isa::Sse2) => core::mem::transmute(s64::<N, INV> as Entry<f64>),
            #[cfg(all(target_arch = "x86_64", feature = "avx2"))]
            (Precision::F32, Isa::Avx2) => core::mem::transmute(a32::<N, INV> as Entry<f32>),
            #[cfg(all(target_arch = "x86_64", feature = "avx2"))]
            (Precision::F64, Isa::Avx2) => core::mem::transmute(a64::<N, INV> as Entry<f64>),
            #[cfg(all(target_arch = "x86_64", feature = "avx512"))]
            (Precision::F32, Isa::Avx512Ymm) => core::mem::transmute(y32::<N, INV> as Entry<f32>),
            #[cfg(all(target_arch = "x86_64", feature = "avx512"))]
            (Precision::F64, Isa::Avx512Ymm) => core::mem::transmute(y64::<N, INV> as Entry<f64>),
            #[cfg(all(target_arch = "x86_64", feature = "avx512"))]
            (Precision::F32, Isa::Avx512) => core::mem::transmute(z32::<N, INV> as Entry<f32>),
            #[cfg(all(target_arch = "x86_64", feature = "avx512"))]
            (Precision::F64, Isa::Avx512) => core::mem::transmute(z64::<N, INV> as Entry<f64>),
            _ => unreachable!(),
        }
    }
}

pub(crate) fn wrap<T: FftNum>(
    fallback: Arc<dyn Fft<T>>,
    isa: Isa,
) -> (Arc<dyn Fft<T>>, Option<Shape>) {
    let n = fallback.len();
    if !(8..=1024).contains(&n) || !n.is_power_of_two() {
        return (fallback, None);
    }
    let Some(shape) = shapes(isa, T::precision() == Precision::F64)
        .into_iter()
        .find(|s| s.lanes > 1 && s.lanes <= n)
    else {
        return (fallback, None);
    };
    let inverse = fallback.fft_direction() == FftDirection::Inverse;
    macro_rules! size {
        ($n:literal) => {
            if inverse {
                select::<T, $n, true>(shape)
            } else {
                select::<T, $n, false>(shape)
            }
        };
    }
    let entry = match n {
        8 => size!(8),
        16 => size!(16),
        32 => size!(32),
        64 => size!(64),
        128 => size!(128),
        256 => size!(256),
        512 => size!(512),
        1024 => size!(1024),
        _ => unreachable!(),
    };
    let mut m = n;
    let mut radices = Vec::new();
    while m > 1 {
        let r = m.min(8);
        radices.push(r);
        m /= r;
    }
    let mut permutation = vec![0; n];
    for dest in 0..n {
        let mut digits = dest;
        let mut source = 0;
        let mut scale = n;
        for &r in &radices {
            scale /= r;
            source += (digits % r) * scale;
            digits /= r;
        }
        permutation[source] = dest;
    }
    let mut twiddles = Vec::new();
    let mut ns = 1;
    for &r in &radices {
        for j in 0..ns {
            for k in 0..r {
                let (a, b) = crate::twiddle::omega(j * k, r * ns);
                twiddles.push(T::from_f64(a).unwrap());
                twiddles.push(T::from_f64(b).unwrap());
            }
        }
        ns *= r;
    }
    (
        Arc::new(Batch {
            fallback,
            plan: Plan {
                radices,
                permutation,
                twiddles,
            },
            lanes: shape.lanes,
            entry,
        }),
        Some(shape),
    )
}
