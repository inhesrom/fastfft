# Benchmarking fastfft

All performance claims about fastfft come from the **arena**
(`bench/arena`, binary `fastfft-arena`), a harness that runs fastfft and the
other Rust FFT libraries (plus a self-built FFTW as a reference) under one
protocol. This document describes the protocol, the suites, the outputs and
how to run it. The design rationale and the mistakes it avoids are in
[`research/rust-fft-landscape.md`](research/rust-fft-landscape.md) §3.

Hosted CI never produces performance numbers: hosted runners are noisy, their
CPUs vary between runs, and Valgrind (callgrind, iai-callgrind) cannot execute
AVX-512 code. Official numbers come from a pinned core on a quiet machine.

## Quick start

```sh
scripts/bench-env.sh setup            # governor/EPP to performance (needs sudo)
scripts/bench-env.sh check            # must print "bench-env: OK" for an official run
cargo xtask fftw-build                # once: FFTW 3.3.11 reference build (~5 min)
cargo xtask arena run --suite pow2 --profile quick
cargo xtask arena run --suite pow2,smooth,rough,batch,realworld --profile full --label baseline
cargo xtask arena report  target/arena/runs/<run>
cargo xtask arena compare target/arena/runs/<a> target/arena/runs/<b>
cargo xtask arena publish target/arena/runs/<run> --label zen4-baseline
scripts/bench-env.sh restore
```

`cargo xtask arena` builds `fastfft-arena` with `--profile arena` (release +
`lto = "fat"`, `codegen-units = 1`, `debug = "line-tables-only"`) for the
**default target CPU**, links FFTW if it has been built, and forwards the
arguments. A run with `RUSTFLAGS="-C target-cpu=native"` is recorded in
`env.json` (`target_cpu_native: true`) and must never be mixed with default
builds.

Small-N gate runs (ticket 11 onward) build the arena with
`RUSTFLAGS="-C llvm-args=-align-all-functions=6"`, so every function in both
libraries starts on a 64-byte line. At N ≤ 8 a call costs 6–8 cycles, and
without the flag either library can gain or lose a whole cycle whenever
unrelated code moves a function across a fetch line (about ±15% in an N=2
ratio). `env.json` records the flag.

For quick before/after checks while developing, the criterion benches in
`crates/fastfft/benches/` are faster to iterate with
(`cargo bench -p fastfft -- --save-baseline before`, then compare with
`critcmp`). They are not used for any published claim.

## Libraries and how each is driven

Each library is driven through its documented fastest API, with planning
outside the timed region and all buffers preallocated.

| Row | How it is driven |
|---|---|
| `fastfft` | `FftPlanner` (default `Estimate` planner, detected ISA); `process_with_scratch`, `process_outofplace_with_scratch`, `process_immutable_with_scratch` with preallocated scratch. Headline row |
| `fastfft/avx2` (default), `fastfft/avx512`, `fastfft/avx512-ymm`, `fastfft/sse2`, `fastfft/scalar` (on request) | Same, with `PlannerOptions::isa_cap` forcing the tier |
| `fastfft/measure` (on request) | `PlanMode::Measure { time_limit: 1 s }` |
| `rustfft` 6.4.x | `FftPlanner` (automatic SIMD: AVX+FMA / SSE4.1); the three `*_with_scratch` methods with preallocated scratch |
| `phastft/split` 0.4.x | `PlannerDit{32,64}` reused; separate re/im arrays (its fast path); in-place only; `parallel` feature off. Its inverse normalizes by 1/N (flagged; the check rescales) |
| `phastft/interleaved` | Its `complex-nums` interleaved API (which deinterleaves into temporary `Vec`s on every call) |
| `tfhe-fft` 0.10.x | `ordered::Plan` with `Method::Measure(50 ms)`; f64, powers of two ≤ 1024 (its ordered plans panic above 2^10), in place |
| `oxifft` 0.4.x | `Plan::dft_1d(n, dir, Flags::MEASURE)`; `execute_inplace` / `execute`; default features minus `threading`. Its opt-in `avx512` feature is not enabled: its changelog says those paths have never been executed |
| `fftw` 3.3.11 (feature `fftw`) | Built by `cargo xtask fftw-build`: sha256-pinned tarball, static, double + single (`--enable-float`), `--enable-sse2 --enable-avx --enable-avx2 --enable-avx512 --enable-fma`, `CFLAGS=-O3`. `FFTW_MEASURE` planning with wisdom saved per host in `bench/arena/wisdom/`; `fftw_plan_many_dft` for batch cells; `FFTW_PRESERVE_INPUT` for immutable cells. FFTW is GPL: it lives only inside the unpublished arena |

oxifft is 0.4.2 rather than the 0.3.x named in the original plan: 0.4.2
fixed wrong results on pre-AVX2 x86 CPUs, and the arena always compares
against each library's current release.

## Measurement protocol (per cell)

A *cell* is one precision × direction × placement × N × batch count ×
alignment (× scenario).

1. The driver (`fastfft-arena run`) starts **one child process per cell**
   (`fastfft-arena run-cell --spec <json>`), pinned with `sched_setaffinity`
   to one core (default CPU 2). The core's SMT siblings are recorded and
   `bench-env.sh check` requires them idle. Each child has a 600 s timeout.
2. **Planning:** every library is planned; planning time is recorded (the
   minimum of five fresh plans for the cheap planners, fastfft `Estimate` and
   rustfft).
3. **Correctness:** every library transforms seeded random input and is
   compared with the testkit reference: the double-double mixed-radix FFT for
   N ≤ 2^20, and rustfft in f64 plus a forward-then-inverse roundtrip above
   that. Batch cells check the first, second and last transform. Immutable
   cells also check that the input is untouched. Libraries that fail
   (error > 200·(log2 N + 1) ε, or NaN) are reported and excluded from
   timing.
4. **Timing data:** zero-filled buffers, as in benchFFT. The real-world
   scenarios use a seeded I/Q stream (Gaussian noise plus tones) in pipelines
   where values stay bounded.
5. **Warm-up:** each library runs for at least the profile's warm-up time
   (200 ms in `full`), which covers boost ramp-up and Intel's AVX-512 license
   warm-up. The warm-up also calibrates *k*, the number of calls per timed
   batch, so that one batch lasts at least 50 µs.
6. **Rounds:** 7 rounds; the library order rotates each round. In each turn a
   library runs batches of *k* calls for at least 100 ms and the per-call time
   of every batch is recorded. Each runner type has its own copy of the timing
   loop (`Runner::turn` and `Runner::calibrate` are provided trait methods), so
   no two libraries share an indirect call site. A shared site lets Zen 4's
   branch predictor favour the first library listed, by about 0.6 ns per call
   ([evidence](benchmarks/2026-09-27-mini-ryzen-small-fair/diagnostics/order-bias.md)).
7. **Statistics per library:** *best* (minimum batch mean: the headline
   number), *p1* (1st-percentile batch mean, which a single outlier batch
   cannot set; the small-N gate uses it in place of best), *median*, 10th and
   90th percentiles. Times are per transform (per-call time ÷ batch count).
   With `--procs K` each cell runs in K child processes, and each library keeps
   the process with its lowest p1.
8. **Drift control:** before the first cell, every 25 cells, and at the end,
   the driver re-runs a control cell (f32 forward in-place N = 4096 with
   fastfft and rustfft). A change of more than 3% against the first control
   flags the run; more than 10% aborts it.

| Profile | Warm-up | Rounds | Turn | Cells |
|---|---|---|---|---|
| `full` | 200 ms | 7 | ≥ 100 ms | all directions and placements |
| `quick` | 50 ms | 3 | ≥ 25 ms | forward in-place only |
| `sweep` | 20 ms | 3 | ≥ 10 ms | used by the `sweep` suite |

## Suites

| Suite | Cells |
|---|---|
| `pow2` | N = 2^1 … 2^24; f32, f64; forward, inverse; in-place, out-of-place |
| `smooth` | benchFFT set {6, 9, 12, 15, 18, 24, 36, 80, 108, 210, 504, 1000, 1960, 4725, 10368, 27000, 75600, 165375} and an SDR/audio set {48, 96, 120, 160, 240, 320, 384, 480, 640, 720, 768, 960, 1200, 1536, 1920, 2400, 3072, 4800, 6144, 12288, 48000, 96000, 1000000}; same 8 variants |
| `rough` | primes {17, 31, 61, 127, 257, 509, 1021, 2053, 4099, 8191, 16381, 65537, 131071} and {2018, 3063, 9797, 65524} (large prime factors); same 8 variants |
| `sweep` | every N from 2 to 4096; f32, f64; forward in-place (coverage plots) |
| `batch` | N ∈ {8, 16, 32, 64, 128, 256, 512, 1024} with 2^20/N transforms per buffer; forward; in-place, out-of-place |
| `realworld` | (a) spectrogram over a 256 MiB interleaved f32 I/Q stream: per non-overlapping window copy, Hann window, FFT in place, write \|X\|² as a row; N ∈ {1024, 4096, 16384, 65536}. (b) overlap-save FIR filter (1025 taps), N = 4096, over 64 MiB. (c) the f64 version of (a) at N = 4096. Metric: million samples per second |
| `datacheck` | zero-filled vs random input, f32/f64 forward, immutable placement (input never changes), N ∈ {64, 4096, 65536, 2^20}: times must agree within 2% |

The windowing, filtering and magnitude code in the scenarios is shared by
every library. Split-layout libraries (phastft/split) deinterleave while
windowing, which is how a user of that API would feed it interleaved I/Q.
Libraries that normalize the inverse get a correspondingly scaled filter.

## Metrics and outputs

Per cell and library: best and median time (ns per transform); benchFFT
"mflops" = 5·N·log2 N / best time in µs; planning time; relative L2 and max
error in units of ε; speedup = rustfft time ÷ library time.

Per suite and precision: geometric-mean speedup (on best and on median
times), win/tie/loss counts with a ±3% tie band, the worst cell, and the
release-gate table (G1–G8) whenever fastfft rows are present.

A run writes `target/arena/runs/<UTC>-<host>[-label]/`:

- `results.jsonl`: one JSON object per cell (plus control cells);
- `env.json`: CPU model/family/stepping/microcode/flags/caches, governor,
  energy-performance preference, boost, SMT, kernel, virtualization, AC
  power, pinned core and siblings, `rustc -vV`, build profile and RUSTFLAGS,
  library versions from `Cargo.lock`, FFTW version and configure line, git
  commit and dirty flag, the environment check result;
- `meta.json`: drift, abort reason, child failures, elapsed time;
- `report.md` and `plots/*.svg` (mflops, speedup and accuracy vs N).

`arena compare A B` prints per-cell ratios and per-suite geomeans for spotting
regressions. `arena publish <run> --label L` copies the report, plots,
`env.json`, `meta.json` and the gzipped JSONL to
`docs/benchmarks/<date>-<host>-<label>/`.

## Accuracy

fastfft's accuracy targets (relative L2 error against the double-double
reference):

- fast paths (all prime factors ≤ 13): ≤ 2ε·log2 N + 2ε;
- Bluestein: ≤ 8ε·log2 M + 8ε, where M is the inner convolution length;
- and never more than 1.5× rustfft's error + ε on the same input.

## Environment control (Zen 4 laptop)

`scripts/bench-env.sh setup [--no-boost] [--core N]` requires AC power, sets
the `performance` governor and energy-performance preference on every CPU,
runs `powerprofilesctl set performance` if available, optionally disables
boost, and saves the previous state. `check` verifies governor, EPP, AC
power, a 1-minute load average ≤ 2 and that the benchmark core and its SMT
siblings are idle (≤ 5% busy over one second). `restore` undoes `setup`.

The arena itself repeats the governor/EPP/AC/load checks and refuses to run
unless they pass or `--allow-dirty-env` is given, in which case the run is
marked unofficial in `env.json` and the report.

Tuning comparisons run with boost off (`--no-boost`) to reduce variance.
Gate runs and published runs use boost on plus the drift check.

## Profiling tools

- `cargo xtask perf-cell --lib fastfft --n 4096 --prec f32` runs `perf stat`
  (cycles, instructions, L1/L2 misses) on one cell. Ubuntu defaults to
  `kernel.perf_event_paranoid = 4`, which blocks unprivileged counters; lower
  it with `sudo sysctl kernel.perf_event_paranoid=1` for profiling sessions.
- `cargo asm` (cargo-show-asm) for inspecting hot loops; `llvm-mca
  -mcpu=znver4` for static throughput estimates of kernels.
- Valgrind-based instruction counting cannot run AVX-512 code; use it only
  on the AVX2/SSE2/scalar tiers if at all.

## Planner tuning

`cargo xtask tune --core 2 --raw target/tune.jsonl --out target/tune.rs`
builds the developer-only `tuning` feature in the arena profile, then pins the
measurement process. Run it on an idle machine. The default sizes are powers
of two through 2^20 and the complete smooth suite. `--max-n 16777216` extends
the power-of-two suite through 2^24; `--n 256,1024` selects a diagnostic subset.
`--precision f32|f64` narrows precision; `--ms 5` sets the sample budget per
candidate and placement. Whole-transform timings take at least 20 batches,
so large scalar candidates can exceed that budget. Compilation must finish
before another timing run.

The tuner measures production Stockham first, twiddled and transpose passes
by radix/precision/tier. Whole-transform candidates include the measured Small
and smooth incumbents, rectangular/packed leaves, fixed Stockham schedules,
FourStep panels, both AVX-512 widths, AVX2 radix-4/radix-8 schedules and alternate
pass orders. All three placements are checked against RustFFT before timing;
the normal accuracy tests independently enforce the double-double thresholds.
The candidate timings use forward transforms through their public FFT methods.
They measure individual candidate engines before the planner's batch wrapper.

`--passes-only` and `--plans-only` split the measurements. Repeat the standalone
executable in three independent processes; the xtask pins each run after its
build completes. The example's `--out` emits single-process seed tables. The
analyzer also derives per-width cache corrections from whole Stockham timings;
use its merged output for the production table:

```sh
python3 scripts/analyze-tuning.py target/passes.jsonl target/plans-1.jsonl target/plans-2.jsonl target/plans-3.jsonl \
  --out crates/fastfft/src/plan/tables/zen4.rs --report target/tuning-summary.json
cargo fmt --all
```

For each candidate/placement the process with the lowest p1 supplies both p1
and median. By default a recipe minimizes the in-place slowdown on both
metrics, matching the existing Measure planner. `--objective all` instead
minimizes the worst slowdown across all three placements. The output always
retains all-placement regressions; some lengths have no single candidate
within 3% in every placement. Untabulated lengths retain the established
small/smooth/large dispatch choices where applicable. Other Stockham choices
use a dynamic program over measured pass costs; unmeasured CPUs use
arithmetic/memory costs for that search. The new Zen 4 tables apply to the
calibrated family 25, model 116 CPU;
other CPU families require their own measurements. Every lookup also respects
runtime ISA caps and compiled features.

Isolated passes have small working sets. Their sum is scaled by the measured
whole-Stockham/pass-sum ratio for the same precision and vector width, with
linear interpolation between power-of-two footprints. This keeps estimates
for untabulated Bluestein inner lengths comparable to measured recipe times,
particularly where narrower vectors cross a cache boundary earlier.
The correction starts at an L2/4 transform footprint and only increases
costs: discounts from power-of-two specializations do not transfer to an
untabulated odd-radix decomposition.

After rebuilding with the tables, run the tuner again and analyze its fresh
JSONL with `--check`. This audits the actual Estimate choice, rather than
reporting the training winner as validation. The check exits nonzero if any
audited default choice exceeds 3% on the selected objective and either timing
metric. Pass `--objective all` to audit the stricter placement target. An arena
run remains necessary to check the production build, inverse transforms,
batch wrapping, drift and release gates.

`cargo xtask tune --planning-only --check-g8 --raw target/planning.jsonl`
checks cold planning on the pow2/smooth/rough suite lengths through 2^20, both
precisions and directions. Every repetition creates a fresh planner; plan
and planner destruction occur after the timed interval. These diagnostic rows
exclude `describe_plan` and caller scratch allocation for both libraries. The
arena's historical `plan_ns` includes adapter setup; retain both results when
assessing G8. The diagnostic exits nonzero if any checked length exceeds 2×.
Suite sampling alone does not establish G8 for every integer length ≤ 2^20.
