//! Developer-only tuning API. Not part of the supported FFT API.
use crate::api::{Fft, FftDirection, FftNum};
use crate::engine::Shape;
use crate::isa::Isa;
use crate::planner::{Candidate, CandidateKernel};
use std::sync::Arc;

/// An opaque, validated production candidate. Constructed only by enumeration.
#[derive(Clone, Debug)]
pub struct Configuration(Candidate, usize, bool);

impl Configuration {
    pub fn kernel(&self) -> &'static str {
        self.0.kernel.name()
    }
    pub fn isa(&self) -> Isa {
        self.0.shape.isa
    }
    pub fn lanes(&self) -> usize {
        self.0.shape.lanes
    }
    pub fn radices(&self) -> &[usize] {
        &self.0.radices
    }
    pub fn build<T: FftNum>(&self, n: usize, dir: FftDirection) -> Arc<dyn Fft<T>> {
        // Enumeration is length/precision-specific; callers cannot substitute
        // another shape, size or precision through this safe diagnostic API.
        assert_eq!((n, core::mem::size_of::<T>() == 8), (self.1, self.2));
        crate::planner::build_candidate(n, dir, &self.0)
    }
    pub fn same(&self, other: &Self) -> bool {
        self.0.kernel == other.0.kernel
            && self.0.shape == other.0.shape
            && self.0.radices == other.0.radices
    }
    pub fn rust_kernel(&self) -> &'static str {
        match self.0.kernel {
            CandidateKernel::Stockham => "Stockham",
            CandidateKernel::FourStep => "FourStep",
            CandidateKernel::GenericSmall => "GenericSmall",
            CandidateKernel::InterleavedSmall => "InterleavedSmall",
            CandidateKernel::RectangularSmall => "RectangularSmall",
        }
    }
}

/// Incumbents plus alternate radix orders, AVX2 schedules and panel splits.
pub fn configurations(n: usize, f64_: bool) -> Vec<Configuration> {
    if n < 2 || !crate::planner::is_smooth(n) {
        return Vec::new();
    }
    let cap = crate::isa::effective_isa(None);
    let mut result = Vec::<Configuration>::new();
    let mut add = |c: Candidate| {
        let c = Configuration(c, n, f64_);
        if !result.iter().any(|r| r.same(&c)) {
            result.push(c);
        }
    };
    for tier in [
        Isa::Scalar,
        Isa::Sse2,
        Isa::Avx2,
        Isa::Avx512Ymm,
        Isa::Avx512,
    ] {
        if tier > cap || !crate::isa::available(tier) {
            continue;
        }
        for c in crate::planner::candidates(n, tier, f64_) {
            add(c);
        }
        let lanes = match tier {
            Isa::Scalar => 1,
            Isa::Sse2 => {
                if f64_ {
                    2
                } else {
                    4
                }
            }
            Isa::Avx512 => {
                if f64_ {
                    8
                } else {
                    16
                }
            }
            _ => {
                if f64_ {
                    4
                } else {
                    8
                }
            }
        };
        if !n.is_multiple_of(lanes) || (lanes > 1 && n < 2 * lanes) {
            continue;
        }
        let shape = Shape { isa: tier, lanes };
        for max in [4, 8] {
            for rs in [
                crate::planner::choose_radices(n / lanes, max),
                crate::plan::radices(n / lanes, shape, f64_, max),
            ]
            .into_iter()
            .flatten()
            {
                for shift in 0..rs.len().max(1) {
                    let mut radices = rs.clone();
                    radices.rotate_left(shift);
                    add(Candidate {
                        kernel: CandidateKernel::Stockham,
                        shape,
                        cost: 0.0,
                        radices: radices.clone(),
                    });
                    radices.reverse();
                    add(Candidate {
                        kernel: CandidateKernel::Stockham,
                        shape,
                        cost: 0.0,
                        radices,
                    });
                }
            }
        }
    }
    result
}

/// Isolated production pass samples: precision, ISA, kind, radix, ns/element.
pub fn passes(f64_: bool, milliseconds: u64) -> Vec<(Isa, u8, usize, f64)> {
    crate::engine::tuning::passes(f64_, milliseconds)
}

/// The actual Estimate configuration, for independent candidate audits.
pub fn estimated(n: usize, cap: Isa, f64_: bool) -> Option<Configuration> {
    if n < 2 || !crate::planner::is_smooth(n) {
        return None;
    }
    crate::planner::estimate(n, crate::isa::effective_isa(Some(cap)), f64_)
        .map(|c| Configuration(c, n, f64_))
}
