# Tune cost tables and the Estimate model

Type: task
Status: claimed
Blocked by: 11, 13, 14, 15
Roadmap: FFT-051

## Question

What should replace the hand-set cost model (`pass_cost`, `predict`, `prefer` in `planner.rs`)?

## Progress

Claimed on 2026-10-02 on `ticket-18-tune-cost-tables`, based on ticket 17
(`0801f9b`). Implement reproducible production-kernel tuning and measured
planner tables, then check candidate quality and Estimate planning overhead.

On 2026-10-03 the maintainer clarified that the 3% candidate target is for
in-place execution, matching Measure. Out-of-place and immutable measurements
remain regression checks; one recipe need not win independently in all three.

## Work

- Implement `cargo xtask tune`. xtask refers to an example `tune` in `crates/fastfft` that does not exist yet.
- Measure per-pass costs by radix, pass type and tier.
- Commit the Zen 4 tables (`plan/tables/zen4.rs`) and choose tier, width and radices from them.
- Choose the vector width per size as well (ADR-0001 §8, item 3).
  - On Zen 4, f64 defaults to 512-bit, but 256-bit measured faster at N = 256 (+7%) and 1024 (+2%).
  - Today the planner always picks 512-bit for f64.
- Cover the odd and composite radices, up to 15 (up to 30 split data registers). M2 did not measure them (§8, item 4).
- Choose AVX2 radices per size using production-kernel costs. [Ticket 10's radix measurements](../../../docs/benchmarks/2026-09-25-mini-ryzen-m3-quick/checkpoint.md#avx2-radix-4-versus-8) retain maximum radix 8 globally: radix 4 is modestly faster over M3 (2.9% f32 / 3.8% f64 best-time geomean), but slower over the complete supported range. Prototype schedules are not interchangeable with the library's schedules.
- Recheck Estimate planning overhead: ticket 10's main quick run reaches 60.99× rustfft at rough f64 N=31, far above G8.
- Ticket 17 adds a Bluestein length heuristic over four inner candidates
  and prepacked pointwise factors. Its quick rough run passes G3, but the
  worst planning ratio rises from 76.01× to 310.59× at f64 N=31. Replace
  repeated candidate enumeration with the measured cost tables and account
  for chirp/kernel preparation and reusable inner plans. Include its
  `2N-2` convolution boundary and tiny-f32 pointwise width choice when tuning.
- Ticket 13 adds measured smooth-size overrides in `smooth_dispatch.rs`
  alongside `small_dispatch.rs`. These include rectangular/packed leaves,
  alternate fixed Stockham schedules and FourStep panels; include all these
  candidates when replacing the cost model. Its final quick smooth run
  passes G2 but still fails G8 (32.84× at f32 N=24).

## Done when

- Estimate picks within 3% of the best candidate on the pow2 and smooth suites.
- G8 holds: Estimate planning time ≤ 2× rustfft's for N ≤ 2^20.
