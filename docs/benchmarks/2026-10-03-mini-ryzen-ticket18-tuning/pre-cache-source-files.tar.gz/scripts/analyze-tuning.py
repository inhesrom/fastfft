#!/usr/bin/env python3
"""Merge independent tune processes, emit measured tables, and audit Estimate.

Uses the process with the lowest p1 for each candidate/placement; its median
travels with that sample. A shared plan minimizes the worst p1/median slowdown
on the selected objective (in-place by default, matching Measure). Raw losing
samples and all-placement regressions remain in the input files.
"""
import argparse
import gzip
import json
import math
from pathlib import Path

TIERS = ['scalar', 'sse2', 'avx2', 'avx512-ymm', 'avx512']
ISAS = ['Scalar', 'Sse2', 'Avx2', 'Avx512Ymm', 'Avx512']
KERNELS = dict(stockham='Stockham', fourstep='FourStep', generic='GenericSmall',
               interleaved='InterleavedSmall', rectangular='RectangularSmall')


def key(row):
    return row['kernel'], row['isa'], row['lanes'], tuple(row['radices'])


def analyze(paths, objective):
    passes, cells, estimates = {}, {}, {}
    calibrated = True
    for path in paths:
        environment_seen = False
        opener = gzip.open if str(path).endswith('.gz') else open
        with opener(path, 'rt') as stream:
            for line in stream:
                row = json.loads(line)
                if row['kind'] == 'environment':
                    environment_seen = True
                    fields = {}
                    for cpu_line in row.get('cpuinfo', '').splitlines():
                        if ':' in cpu_line:
                            k, v = cpu_line.split(':', 1)
                            fields[k.strip()] = v.strip()
                    calibrated &= (fields.get('vendor_id') == 'AuthenticAMD'
                                   and fields.get('cpu family') == '25'
                                   and fields.get('model') == '116')
                elif row['kind'] == 'pass':
                    k = row['f64'], row['isa'], row['pass'], row['radix']
                    value = row['ns_per_element']
                    assert math.isfinite(value) and value > 0
                    passes[k] = min(passes.get(k, math.inf), value)
                elif row['kind'] == 'candidate':
                    if not all(math.isfinite(row[m]) and row[m] > 0
                               for m in ('p1_ns', 'median_ns')):
                        raise ValueError(f'Invalid candidate timing in {path}')
                    cell = row['precision'], row['n']
                    k = key(row), row['placement']
                    values = cells.setdefault(cell, {})
                    old = values.get(k)
                    if old is None or row['p1_ns'] < old['p1_ns']:
                        values[k] = row
                elif row['kind'] == 'estimate':
                    k = row['precision'], row['n'], row['cap']
                    choice = key(row)
                    if k in estimates and estimates[k] != choice:
                        raise ValueError(f'Estimates from different source builds: {k}')
                    estimates[k] = choice
        calibrated &= environment_seen
    recipes, audit = [], []
    for (precision, n), samples in sorted(cells.items()):
        configs = sorted({k for k, _ in samples})
        # Incomplete candidates (e.g. interrupted process) cannot win.
        configs = [k for k in configs if all((k, m) in samples for m in range(3))]
        for cap_index, cap in enumerate(TIERS):
            eligible = [k for k in configs if TIERS.index(k[1]) <= cap_index]
            if not eligible:
                continue
            best = {(m, metric): min(samples[k, m][metric] for k in eligible)
                    for m in range(3) for metric in ('p1_ns', 'median_ns')}
            def ratios(k):
                return {f'{m}:{metric}': samples[k, m][metric] / best[m, metric]
                        for m in range(3) for metric in ('p1_ns', 'median_ns')}
            def score(k):
                values = ratios(k)
                return max(v for label, v in values.items()
                           if objective == 'all' or label.startswith('0:'))
            winner = min(eligible, key=score)
            record = dict(precision=precision, n=n, cap=cap, kernel=winner[0],
                          isa=winner[1], lanes=winner[2], radices=winner[3],
                          ns=samples[winner, 0]['p1_ns'],
                          winner_worst_ratio=max(ratios(winner).values()),
                          winner_objective_ratio=score(winner))
            recipes.append(record)
            estimated = estimates.get((precision, n, cap))
            if estimated:
                if estimated not in eligible:
                    raise ValueError(f'Estimate was not timed: {(precision, n, cap)}')
                audit.append(dict(precision=precision, n=n, cap=cap,
                                  ratios=ratios(estimated),
                                  worst_ratio=max(ratios(estimated).values()),
                                  objective_ratio=score(estimated),
                                  ip_ratio=ratios(estimated)['0:p1_ns']))
    return passes, recipes, audit, calibrated


def rust_table(passes, recipes):
    text = ['//! Production-kernel calibration for Ryzen 7 7840HS (family 25, model 116).',
            '//! Generated by scripts/analyze-tuning.py from retained tune JSONL.',
            'use crate::isa::Isa;', 'use crate::planner::CandidateKernel;',
            'use crate::plan::{PassCost, Recipe};',
            '#[rustfmt::skip]', 'pub(crate) const PASSES: &[PassCost] = &[']
    for (f64_, isa, kind, radix), ns in sorted(passes.items()):
        text.append(f'    PassCost {{ f64_: {str(f64_).lower()}, isa: Isa::{ISAS[TIERS.index(isa)]}, kind: {kind}, radix: {radix}, ns: {ns:.9f} }},')
    text.extend(['];', '#[rustfmt::skip]', 'pub(crate) const RECIPES: &[Recipe] = &['])
    for r in sorted(recipes, key=lambda r: (r['precision'], r['n'], TIERS.index(r['cap']))):
        text.append(f"    Recipe {{ n: {r['n']}, f64_: {str(r['precision']=='f64').lower()}, cap: Isa::{ISAS[TIERS.index(r['cap'])]}, kernel: CandidateKernel::{KERNELS[r['kernel']]}, isa: Isa::{ISAS[TIERS.index(r['isa'])]}, lanes: {r['lanes']}, radices: &{list(r['radices'])}, ns: {r['ns']:.6f} }},")
    return '\n'.join(text + ['];', ''])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('raw', type=Path, nargs='+')
    parser.add_argument('--out', type=Path)
    parser.add_argument('--report', type=Path)
    parser.add_argument('--objective', choices=['inplace', 'all'], default='inplace', help='match Measure (inplace), or minimize the worst placement')
    parser.add_argument('--check', action='store_true', help='require audited default Estimate within 3%% on the selected objective, both metrics')
    args = parser.parse_args()
    passes, recipes, audit, calibrated = analyze(args.raw, args.objective)
    if args.out:
        if not calibrated:
            parser.error("Zen 4 table output requires measurements from family 25, model 116")
        if not passes or not recipes:
            parser.error('a complete table requires both pass and candidate samples')
        args.out.write_text(rust_table(passes, recipes))
    default = [a for a in audit if a['cap']=='avx512']
    failures = [a for a in default if a['objective_ratio'] > 1.03]
    report = dict(objective=args.objective, pass_samples=len(passes), recipes=recipes, audit=audit,
                  default_audited=len(default), default_failures=failures)
    if args.report:
        args.report.write_text(json.dumps(report, indent=2)+'\n')
    print(f'{len(passes)} pass costs; {len(recipes)} recipes; {len(default)} default estimates audited; {len(failures)} above 3%')
    if args.check and (not default or failures):
        raise SystemExit(1)


if __name__ == '__main__':
    main()
