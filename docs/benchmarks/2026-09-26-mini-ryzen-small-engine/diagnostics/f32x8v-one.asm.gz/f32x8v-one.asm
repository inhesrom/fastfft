000000000056d460 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56d460:	c5 fc 10 2f          	vmovups (%rdi),%ymm5
  56d464:	c5 7c 10 57 20       	vmovups 0x20(%rdi),%ymm10
  56d469:	c5 7c 10 5f 40       	vmovups 0x40(%rdi),%ymm11
  56d46e:	c5 7c 10 67 60       	vmovups 0x60(%rdi),%ymm12
  56d473:	c4 c1 54 c6 c2 88    	vshufps $0x88,%ymm10,%ymm5,%ymm0
  56d479:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56d47f:	c4 c1 24 c6 cc 88    	vshufps $0x88,%ymm12,%ymm11,%ymm1
  56d485:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  56d48b:	c5 fc 58 f1          	vaddps %ymm1,%ymm0,%ymm6
  56d48f:	c4 e3 7d 19 f2 01    	vextractf128 $0x1,%ymm6,%xmm2
  56d495:	c4 41 30 57 c9       	vxorps %xmm9,%xmm9,%xmm9
  56d49a:	c4 c1 6d 15 d9       	vunpckhpd %ymm9,%ymm2,%ymm3
  56d49f:	c5 fc 5c c9          	vsubps %ymm1,%ymm0,%ymm1
  56d4a3:	c4 e3 7d 19 cf 01    	vextractf128 $0x1,%ymm1,%xmm7
  56d4a9:	c4 c1 45 15 e1       	vunpckhpd %ymm9,%ymm7,%ymm4
  56d4ae:	c5 e4 c6 c4 dd       	vshufps $0xdd,%ymm4,%ymm3,%ymm0
  56d4b3:	c5 fc c6 c0 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm0
  56d4b8:	c5 e4 c6 dc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm3
  56d4bd:	c5 e4 c6 e3 d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm4
  56d4c2:	c4 c3 6d 0c d9 cc    	vblendps $0xcc,%ymm9,%ymm2,%ymm3
  56d4c8:	c4 c3 45 0c f9 cc    	vblendps $0xcc,%ymm9,%ymm7,%ymm7
  56d4ce:	c5 e4 c6 d7 dd       	vshufps $0xdd,%ymm7,%ymm3,%ymm2
  56d4d3:	c5 ec c6 d2 d8       	vshufps $0xd8,%ymm2,%ymm2,%ymm2
  56d4d8:	c5 e4 c6 df 88       	vshufps $0x88,%ymm7,%ymm3,%ymm3
  56d4dd:	c5 e4 c6 fb d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm7
  56d4e2:	c5 f8 28 de          	vmovaps %xmm6,%xmm3
  56d4e6:	c5 bd 73 db 08       	vpsrldq $0x8,%ymm3,%ymm8
  56d4eb:	c5 f8 28 d9          	vmovaps %xmm1,%xmm3
  56d4ef:	c5 95 73 db 08       	vpsrldq $0x8,%ymm3,%ymm13
  56d4f4:	c4 c1 3c c6 dd dd    	vshufps $0xdd,%ymm13,%ymm8,%ymm3
  56d4fa:	c5 e4 c6 db d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm3
  56d4ff:	c4 41 3c c6 c5 88    	vshufps $0x88,%ymm13,%ymm8,%ymm8
  56d505:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  56d50b:	c5 7a 7e ee          	vmovq  %xmm6,%xmm13
  56d50f:	c5 fa 7e c9          	vmovq  %xmm1,%xmm1
  56d513:	c5 94 c6 f1 dd       	vshufps $0xdd,%ymm1,%ymm13,%ymm6
  56d518:	c5 cc c6 f6 d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm6
  56d51d:	c5 94 c6 c9 88       	vshufps $0x88,%ymm1,%ymm13,%ymm1
  56d522:	c5 f4 c6 c9 d8       	vshufps $0xd8,%ymm1,%ymm1,%ymm1
  56d527:	c4 c1 54 c6 ea dd    	vshufps $0xdd,%ymm10,%ymm5,%ymm5
  56d52d:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  56d533:	c4 41 24 c6 d4 dd    	vshufps $0xdd,%ymm12,%ymm11,%ymm10
  56d539:	c4 43 fd 01 d2 d8    	vpermpd $0xd8,%ymm10,%ymm10
  56d53f:	c5 2c 58 dd          	vaddps %ymm5,%ymm10,%ymm11
  56d543:	c4 43 7d 19 dd 01    	vextractf128 $0x1,%ymm11,%xmm13
  56d549:	c4 41 15 15 e1       	vunpckhpd %ymm9,%ymm13,%ymm12
  56d54e:	c4 41 54 5c f2       	vsubps %ymm10,%ymm5,%ymm14
  56d553:	c4 43 7d 19 f2 01    	vextractf128 $0x1,%ymm14,%xmm10
  56d559:	c4 41 2d 15 f9       	vunpckhpd %ymm9,%ymm10,%ymm15
  56d55e:	c4 c1 1c c6 ef dd    	vshufps $0xdd,%ymm15,%ymm12,%ymm5
  56d564:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  56d569:	c4 41 1c c6 e7 88    	vshufps $0x88,%ymm15,%ymm12,%ymm12
  56d56f:	c4 41 1c c6 e4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm12
  56d575:	c4 43 15 0c e9 cc    	vblendps $0xcc,%ymm9,%ymm13,%ymm13
  56d57b:	c4 43 2d 0c d1 cc    	vblendps $0xcc,%ymm9,%ymm10,%ymm10
  56d581:	c4 41 14 c6 ca dd    	vshufps $0xdd,%ymm10,%ymm13,%ymm9
  56d587:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  56d58d:	c4 41 14 c6 d2 88    	vshufps $0x88,%ymm10,%ymm13,%ymm10
  56d593:	62 c1 2c 28 c6 ca d8 	vshufps $0xd8,%ymm10,%ymm10,%ymm17
  56d59a:	c4 41 78 28 d3       	vmovaps %xmm11,%xmm10
  56d59f:	c4 c1 15 73 da 08    	vpsrldq $0x8,%ymm10,%ymm13
  56d5a5:	c4 41 78 28 d6       	vmovaps %xmm14,%xmm10
  56d5aa:	c4 c1 05 73 da 08    	vpsrldq $0x8,%ymm10,%ymm15
  56d5b0:	c4 41 14 c6 d7 dd    	vshufps $0xdd,%ymm15,%ymm13,%ymm10
  56d5b6:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  56d5bc:	c4 41 14 c6 ef 88    	vshufps $0x88,%ymm15,%ymm13,%ymm13
  56d5c2:	62 c1 14 28 c6 d5 d8 	vshufps $0xd8,%ymm13,%ymm13,%ymm18
  56d5c9:	c4 41 7a 7e db       	vmovq  %xmm11,%xmm11
  56d5ce:	c4 41 7a 7e ee       	vmovq  %xmm14,%xmm13
  56d5d3:	c4 41 24 c6 f5 dd    	vshufps $0xdd,%ymm13,%ymm11,%ymm14
  56d5d9:	62 c1 0c 28 c6 c6 d8 	vshufps $0xd8,%ymm14,%ymm14,%ymm16
  56d5e0:	c4 41 24 c6 dd 88    	vshufps $0x88,%ymm13,%ymm11,%ymm11
  56d5e6:	c4 41 24 c6 db d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm11
  56d5ec:	62 e1 7c 28 10 5a 02 	vmovups 0x40(%rdx),%ymm19
  56d5f3:	62 e1 7c 28 10 62 03 	vmovups 0x60(%rdx),%ymm20
  56d5fa:	62 e1 7c 28 10 6a 04 	vmovups 0x80(%rdx),%ymm21
  56d601:	62 e1 7c 28 10 72 05 	vmovups 0xa0(%rdx),%ymm22
  56d608:	c5 7c 10 b2 c0 00 00 	vmovups 0xc0(%rdx),%ymm14
  56d60f:	00 
  56d610:	c5 7c 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm13
  56d617:	00 
  56d618:	62 e1 7c 28 10 7a 08 	vmovups 0x100(%rdx),%ymm23
  56d61f:	62 61 7c 28 10 42 09 	vmovups 0x120(%rdx),%ymm24
  56d626:	62 61 7c 28 10 4a 0a 	vmovups 0x140(%rdx),%ymm25
  56d62d:	62 31 74 20 59 ff    	vmulps %ymm23,%ymm17,%ymm15
  56d633:	62 12 45 28 bc f8    	vfnmadd231ps %ymm24,%ymm7,%ymm15
  56d639:	62 a1 44 28 59 ff    	vmulps %ymm23,%ymm7,%ymm23
  56d63f:	62 61 7c 28 10 52 0b 	vmovups 0x160(%rdx),%ymm26
  56d646:	62 82 75 20 b8 f8    	vfmadd231ps %ymm24,%ymm17,%ymm23
  56d64c:	c5 fc 10 ba 80 01 00 	vmovups 0x180(%rdx),%ymm7
  56d653:	00 
  56d654:	62 a1 6c 20 59 cd    	vmulps %ymm21,%ymm18,%ymm17
  56d65a:	62 a2 3d 28 bc ce    	vfnmadd231ps %ymm22,%ymm8,%ymm17
  56d660:	62 31 3c 28 59 c5    	vmulps %ymm21,%ymm8,%ymm8
  56d666:	62 e1 7c 28 10 6a 0d 	vmovups 0x1a0(%rdx),%ymm21
  56d66d:	62 32 6d 20 b8 c6    	vfmadd231ps %ymm22,%ymm18,%ymm8
  56d673:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  56d67a:	62 e1 1c 28 59 f7    	vmulps %ymm7,%ymm12,%ymm22
  56d680:	62 a2 5d 28 bc f5    	vfnmadd231ps %ymm21,%ymm4,%ymm22
  56d686:	62 61 5c 28 59 c7    	vmulps %ymm7,%ymm4,%ymm24
  56d68c:	62 61 7c 28 10 5a 0f 	vmovups 0x1e0(%rdx),%ymm27
  56d693:	62 22 1d 28 b8 c5    	vfmadd231ps %ymm21,%ymm12,%ymm24
  56d699:	c4 c1 24 58 e7       	vaddps %ymm15,%ymm11,%ymm4
  56d69e:	62 31 7c 20 59 e3    	vmulps %ymm19,%ymm16,%ymm12
  56d6a4:	62 32 4d 28 bc e4    	vfnmadd231ps %ymm20,%ymm6,%ymm12
  56d6aa:	62 a1 4c 28 59 db    	vmulps %ymm19,%ymm6,%ymm19
  56d6b0:	62 b1 74 20 58 f6    	vaddps %ymm22,%ymm17,%ymm6
  56d6b6:	62 a2 7d 20 b8 dc    	vfmadd231ps %ymm20,%ymm16,%ymm19
  56d6bc:	62 81 34 28 59 c1    	vmulps %ymm25,%ymm9,%ymm16
  56d6c2:	62 82 6d 28 bc c2    	vfnmadd231ps %ymm26,%ymm2,%ymm16
  56d6c8:	62 b1 1c 28 58 f8    	vaddps %ymm16,%ymm12,%ymm7
  56d6ce:	62 81 6c 28 59 e1    	vmulps %ymm25,%ymm2,%ymm20
  56d6d4:	62 c1 2c 28 59 ee    	vmulps %ymm14,%ymm10,%ymm21
  56d6da:	62 c2 65 28 bc ed    	vfnmadd231ps %ymm13,%ymm3,%ymm21
  56d6e0:	62 82 35 28 b8 e2    	vfmadd231ps %ymm26,%ymm9,%ymm20
  56d6e6:	62 31 54 28 59 ca    	vmulps %ymm18,%ymm5,%ymm9
  56d6ec:	62 12 7d 28 bc cb    	vfnmadd231ps %ymm27,%ymm0,%ymm9
  56d6f2:	62 d1 54 20 58 d1    	vaddps %ymm9,%ymm21,%ymm2
  56d6f8:	c5 8c 59 db          	vmulps %ymm3,%ymm14,%ymm3
  56d6fc:	62 71 44 20 58 f1    	vaddps %ymm1,%ymm23,%ymm14
  56d702:	c4 c2 2d b8 dd       	vfmadd231ps %ymm13,%ymm10,%ymm3
  56d707:	62 11 3c 28 58 d0    	vaddps %ymm24,%ymm8,%ymm10
  56d70d:	62 31 64 20 58 ec    	vaddps %ymm20,%ymm19,%ymm13
  56d713:	62 b1 7c 28 59 c2    	vmulps %ymm18,%ymm0,%ymm0
  56d719:	62 92 55 28 b8 c3    	vfmadd231ps %ymm27,%ymm5,%ymm0
  56d71f:	c5 e4 58 e8          	vaddps %ymm0,%ymm3,%ymm5
  56d723:	c4 41 24 5c df       	vsubps %ymm15,%ymm11,%ymm11
  56d728:	62 11 3c 28 5c c0    	vsubps %ymm24,%ymm8,%ymm8
  56d72e:	62 31 1c 28 5c e0    	vsubps %ymm16,%ymm12,%ymm12
  56d734:	62 31 64 20 5c fc    	vsubps %ymm20,%ymm19,%ymm15
  56d73a:	62 e2 7d 28 18 05 a4 	vbroadcastss -0x4f145c(%rip),%ymm16        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56d741:	eb b0 ff 
  56d744:	62 c1 1c 28 58 d7    	vaddps %ymm15,%ymm12,%ymm18
  56d74a:	62 a1 6c 20 59 d0    	vmulps %ymm16,%ymm18,%ymm18
  56d750:	c5 e4 5c c0          	vsubps %ymm0,%ymm3,%ymm0
  56d754:	62 d1 54 20 5c d9    	vsubps %ymm9,%ymm21,%ymm3
  56d75a:	c5 7c 5c cb          	vsubps %ymm3,%ymm0,%ymm9
  56d75e:	62 31 34 28 59 c8    	vmulps %ymm16,%ymm9,%ymm9
  56d764:	62 b1 74 28 5c cf    	vsubps %ymm23,%ymm1,%ymm1
  56d76a:	62 a1 4c 20 5c c9    	vsubps %ymm17,%ymm22,%ymm17
  56d770:	c4 41 04 5c e4       	vsubps %ymm12,%ymm15,%ymm12
  56d775:	62 31 1c 28 59 e0    	vmulps %ymm16,%ymm12,%ymm12
  56d77b:	c5 e4 58 c0          	vaddps %ymm0,%ymm3,%ymm0
  56d77f:	62 b1 7c 28 59 c0    	vmulps %ymm16,%ymm0,%ymm0
  56d785:	c5 c0 58 da          	vaddps %xmm2,%xmm7,%xmm3
  56d789:	c5 58 58 fe          	vaddps %xmm6,%xmm4,%xmm15
  56d78d:	62 e1 04 08 58 c3    	vaddps %xmm3,%xmm15,%xmm16
  56d793:	62 e1 14 08 58 dd    	vaddps %xmm5,%xmm13,%xmm19
  56d799:	62 c1 2c 08 58 e6    	vaddps %xmm14,%xmm10,%xmm20
  56d79f:	62 a1 5c 00 58 eb    	vaddps %xmm19,%xmm20,%xmm21
  56d7a5:	62 a1 54 00 14 c0    	vunpcklps %xmm16,%xmm21,%xmm16
  56d7ab:	62 e1 7c 08 11 06    	vmovups %xmm16,(%rsi)
  56d7b1:	62 c1 6c 00 58 c1    	vaddps %xmm9,%xmm18,%xmm16
  56d7b7:	62 c1 24 08 58 e8    	vaddps %xmm8,%xmm11,%xmm21
  56d7bd:	62 a1 54 00 58 f0    	vaddps %xmm16,%xmm21,%xmm22
  56d7c3:	62 e1 1c 08 5c f8    	vsubps %xmm0,%xmm12,%xmm23
  56d7c9:	62 61 74 00 58 c1    	vaddps %xmm1,%xmm17,%xmm24
  56d7cf:	62 21 3c 00 58 cf    	vaddps %xmm23,%xmm24,%xmm25
  56d7d5:	62 a1 34 00 14 f6    	vunpcklps %xmm22,%xmm25,%xmm22
  56d7db:	62 e1 7c 08 11 76 01 	vmovups %xmm22,0x10(%rsi)
  56d7e2:	c5 90 5c ed          	vsubps %xmm5,%xmm13,%xmm5
  56d7e6:	c5 d8 5c e6          	vsubps %xmm6,%xmm4,%xmm4
  56d7ea:	c5 e8 5c d7          	vsubps %xmm7,%xmm2,%xmm2
  56d7ee:	c5 d8 58 f5          	vaddps %xmm5,%xmm4,%xmm6
  56d7f2:	c4 c1 08 5c fa       	vsubps %xmm10,%xmm14,%xmm7
  56d7f7:	c5 40 58 d2          	vaddps %xmm2,%xmm7,%xmm10
  56d7fb:	c5 a8 14 f6          	vunpcklps %xmm6,%xmm10,%xmm6
  56d7ff:	c5 f8 11 76 20       	vmovups %xmm6,0x20(%rsi)
  56d804:	c5 98 58 c0          	vaddps %xmm0,%xmm12,%xmm0
  56d808:	c4 c1 20 5c f0       	vsubps %xmm8,%xmm11,%xmm6
  56d80d:	62 31 34 08 5c c2    	vsubps %xmm18,%xmm9,%xmm8
  56d813:	c5 48 58 c8          	vaddps %xmm0,%xmm6,%xmm9
  56d817:	62 b1 74 08 5c c9    	vsubps %xmm17,%xmm1,%xmm1
  56d81d:	c5 38 58 d1          	vaddps %xmm1,%xmm8,%xmm10
  56d821:	c4 41 28 14 c9       	vunpcklps %xmm9,%xmm10,%xmm9
  56d826:	c5 78 11 4e 30       	vmovups %xmm9,0x30(%rsi)
  56d82b:	c5 80 5c db          	vsubps %xmm3,%xmm15,%xmm3
  56d82f:	62 31 5c 00 5c cb    	vsubps %xmm19,%xmm20,%xmm9
  56d835:	c5 b0 14 db          	vunpcklps %xmm3,%xmm9,%xmm3
  56d839:	c5 f8 11 5e 40       	vmovups %xmm3,0x40(%rsi)
  56d83e:	62 b1 54 00 5c d8    	vsubps %xmm16,%xmm21,%xmm3
  56d844:	62 31 3c 00 5c cf    	vsubps %xmm23,%xmm24,%xmm9
  56d84a:	c5 b0 14 db          	vunpcklps %xmm3,%xmm9,%xmm3
  56d84e:	c5 f8 11 5e 50       	vmovups %xmm3,0x50(%rsi)
  56d853:	c5 d8 5c dd          	vsubps %xmm5,%xmm4,%xmm3
  56d857:	c5 c0 5c d2          	vsubps %xmm2,%xmm7,%xmm2
  56d85b:	c5 e8 14 d3          	vunpcklps %xmm3,%xmm2,%xmm2
  56d85f:	c5 f8 11 56 60       	vmovups %xmm2,0x60(%rsi)
  56d864:	c5 c8 5c c0          	vsubps %xmm0,%xmm6,%xmm0
  56d868:	c4 c1 70 5c c8       	vsubps %xmm8,%xmm1,%xmm1
  56d86d:	c5 f0 14 c0          	vunpcklps %xmm0,%xmm1,%xmm0
  56d871:	c5 f8 11 46 70       	vmovups %xmm0,0x70(%rsi)
  56d876:	c5 f8 77             	vzeroupper
  56d879:	c3                   	ret
  56d87a:	cc                   	int3
  56d87b:	cc                   	int3
  56d87c:	cc                   	int3
  56d87d:	cc                   	int3
  56d87e:	cc                   	int3
  56d87f:	cc                   	int3


000000000056d880 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56d880:	c5 fc 10 07          	vmovups (%rdi),%ymm0
  56d884:	c5 fc 10 4f 20       	vmovups 0x20(%rdi),%ymm1
  56d889:	c5 fc 10 57 40       	vmovups 0x40(%rdi),%ymm2
  56d88e:	c5 fc 10 5f 60       	vmovups 0x60(%rdi),%ymm3
  56d893:	c5 fc 10 a7 80 00 00 	vmovups 0x80(%rdi),%ymm4
  56d89a:	00 
  56d89b:	c5 fc 10 af a0 00 00 	vmovups 0xa0(%rdi),%ymm5
  56d8a2:	00 
  56d8a3:	c5 fc 10 b7 c0 00 00 	vmovups 0xc0(%rdi),%ymm6
  56d8aa:	00 
  56d8ab:	c5 fc 10 bf e0 00 00 	vmovups 0xe0(%rdi),%ymm7
  56d8b2:	00 
  56d8b3:	c5 7c c6 c1 dd       	vshufps $0xdd,%ymm1,%ymm0,%ymm8
  56d8b8:	c4 43 fd 01 c8 d8    	vpermpd $0xd8,%ymm8,%ymm9
  56d8be:	c5 5c c6 c5 dd       	vshufps $0xdd,%ymm5,%ymm4,%ymm8
  56d8c3:	c4 43 fd 01 d0 d8    	vpermpd $0xd8,%ymm8,%ymm10
  56d8c9:	c4 41 34 58 c2       	vaddps %ymm10,%ymm9,%ymm8
  56d8ce:	c5 6c c6 db dd       	vshufps $0xdd,%ymm3,%ymm2,%ymm11
  56d8d3:	c4 43 fd 01 db d8    	vpermpd $0xd8,%ymm11,%ymm11
  56d8d9:	c5 4c c6 e7 dd       	vshufps $0xdd,%ymm7,%ymm6,%ymm12
  56d8de:	c4 43 fd 01 e4 d8    	vpermpd $0xd8,%ymm12,%ymm12
  56d8e4:	c4 41 24 58 ec       	vaddps %ymm12,%ymm11,%ymm13
  56d8e9:	c4 41 3c 58 f5       	vaddps %ymm13,%ymm8,%ymm14
  56d8ee:	c4 41 3c 5c ed       	vsubps %ymm13,%ymm8,%ymm13
  56d8f3:	c4 41 0d 15 c5       	vunpckhpd %ymm13,%ymm14,%ymm8
  56d8f8:	c5 cc c6 f7 88       	vshufps $0x88,%ymm7,%ymm6,%ymm6
  56d8fd:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  56d903:	c5 ec c6 d3 88       	vshufps $0x88,%ymm3,%ymm2,%ymm2
  56d908:	c4 e3 fd 01 d2 d8    	vpermpd $0xd8,%ymm2,%ymm2
  56d90e:	c5 cc 5c da          	vsubps %ymm2,%ymm6,%ymm3
  56d912:	c4 c1 34 5c fa       	vsubps %ymm10,%ymm9,%ymm7
  56d917:	c5 64 58 cf          	vaddps %ymm7,%ymm3,%ymm9
  56d91b:	c5 c4 5c db          	vsubps %ymm3,%ymm7,%ymm3
  56d91f:	c5 35 15 fb          	vunpckhpd %ymm3,%ymm9,%ymm15
  56d923:	c4 41 0d 14 d5       	vunpcklpd %ymm13,%ymm14,%ymm10
  56d928:	c5 35 14 cb          	vunpcklpd %ymm3,%ymm9,%ymm9
  56d92c:	c5 fc c6 c1 88       	vshufps $0x88,%ymm1,%ymm0,%ymm0
  56d931:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56d937:	c5 dc c6 cd 88       	vshufps $0x88,%ymm5,%ymm4,%ymm1
  56d93c:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  56d942:	c5 fc 58 d9          	vaddps %ymm1,%ymm0,%ymm3
  56d946:	c5 ec 58 d6          	vaddps %ymm6,%ymm2,%ymm2
  56d94a:	c5 e4 58 e2          	vaddps %ymm2,%ymm3,%ymm4
  56d94e:	c5 e4 5c d2          	vsubps %ymm2,%ymm3,%ymm2
  56d952:	c5 5d 15 ea          	vunpckhpd %ymm2,%ymm4,%ymm13
  56d956:	c5 fc 5c c1          	vsubps %ymm1,%ymm0,%ymm0
  56d95a:	c4 c1 24 5c cc       	vsubps %ymm12,%ymm11,%ymm1
  56d95f:	c5 fc 58 d9          	vaddps %ymm1,%ymm0,%ymm3
  56d963:	c5 fc 5c c1          	vsubps %ymm1,%ymm0,%ymm0
  56d967:	62 e1 e5 28 15 c0    	vunpckhpd %ymm0,%ymm3,%ymm16
  56d96d:	c5 dd 14 d2          	vunpcklpd %ymm2,%ymm4,%ymm2
  56d971:	c5 e5 14 d8          	vunpcklpd %ymm0,%ymm3,%ymm3
  56d975:	c5 e8 c6 c3 88       	vshufps $0x88,%xmm3,%xmm2,%xmm0
  56d97a:	c5 f8 29 44 24 e8    	vmovaps %xmm0,-0x18(%rsp)
  56d980:	c4 e3 7d 19 dd 01    	vextractf128 $0x1,%ymm3,%xmm5
  56d986:	c4 e3 7d 19 d6 01    	vextractf128 $0x1,%ymm2,%xmm6
  56d98c:	c5 c8 c6 cd 88       	vshufps $0x88,%xmm5,%xmm6,%xmm1
  56d991:	c5 f0 c6 e1 d8       	vshufps $0xd8,%xmm1,%xmm1,%xmm4
  56d996:	c4 c1 28 c6 c1 88    	vshufps $0x88,%xmm9,%xmm10,%xmm0
  56d99c:	c5 f8 29 44 24 d8    	vmovaps %xmm0,-0x28(%rsp)
  56d9a2:	c4 43 7d 19 cb 01    	vextractf128 $0x1,%ymm9,%xmm11
  56d9a8:	c4 43 7d 19 d4 01    	vextractf128 $0x1,%ymm10,%xmm12
  56d9ae:	c4 c1 18 c6 fb 88    	vshufps $0x88,%xmm11,%xmm12,%xmm7
  56d9b4:	62 61 44 08 c6 e7 d8 	vshufps $0xd8,%xmm7,%xmm7,%xmm28
  56d9bb:	c5 e8 c6 d3 dd       	vshufps $0xdd,%xmm3,%xmm2,%xmm2
  56d9c0:	c5 e8 c6 ca d8       	vshufps $0xd8,%xmm2,%xmm2,%xmm1
  56d9c5:	c5 c8 c6 d5 dd       	vshufps $0xdd,%xmm5,%xmm6,%xmm2
  56d9ca:	c5 e8 c6 c2 d8       	vshufps $0xd8,%xmm2,%xmm2,%xmm0
  56d9cf:	c5 f8 29 44 24 98    	vmovaps %xmm0,-0x68(%rsp)
  56d9d5:	c4 c1 28 c6 e9 dd    	vshufps $0xdd,%xmm9,%xmm10,%xmm5
  56d9db:	c5 d0 c6 dd d8       	vshufps $0xd8,%xmm5,%xmm5,%xmm3
  56d9e0:	c4 c1 18 c6 eb dd    	vshufps $0xdd,%xmm11,%xmm12,%xmm5
  56d9e6:	c5 d0 c6 d5 d8       	vshufps $0xd8,%xmm5,%xmm5,%xmm2
  56d9eb:	62 31 14 08 c6 c8 88 	vshufps $0x88,%xmm16,%xmm13,%xmm9
  56d9f2:	c4 41 30 c6 d9 d8    	vshufps $0xd8,%xmm9,%xmm9,%xmm11
  56d9f8:	62 c3 7d 28 19 c1 01 	vextractf32x4 $0x1,%ymm16,%xmm9
  56d9ff:	62 33 7d 28 19 e9 01 	vextractf32x4 $0x1,%ymm13,%xmm17
  56da06:	62 51 74 00 c6 d1 88 	vshufps $0x88,%xmm9,%xmm17,%xmm10
  56da0d:	c4 c1 28 c6 f2 d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm6
  56da13:	c5 f8 29 74 24 88    	vmovaps %xmm6,-0x78(%rsp)
  56da19:	c4 41 38 c6 d7 88    	vshufps $0x88,%xmm15,%xmm8,%xmm10
  56da1f:	c4 41 28 c6 f2 d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm14
  56da25:	62 33 7d 28 19 fa 01 	vextractf32x4 $0x1,%ymm15,%xmm18
  56da2c:	62 33 7d 28 19 c3 01 	vextractf32x4 $0x1,%ymm8,%xmm19
  56da33:	62 31 64 00 c6 d2 88 	vshufps $0x88,%xmm18,%xmm19,%xmm10
  56da3a:	c4 41 28 c6 e2 d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm12
  56da40:	62 31 14 08 c6 d0 dd 	vshufps $0xdd,%xmm16,%xmm13,%xmm10
  56da47:	c4 c1 28 c6 ea d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm5
  56da4d:	62 d1 74 00 c6 f9 dd 	vshufps $0xdd,%xmm9,%xmm17,%xmm7
  56da54:	c5 f8 29 7c 24 a8    	vmovaps %xmm7,-0x58(%rsp)
  56da5a:	c4 41 38 c6 c7 dd    	vshufps $0xdd,%xmm15,%xmm8,%xmm8
  56da60:	c4 41 38 c6 f8 d8    	vshufps $0xd8,%xmm8,%xmm8,%xmm15
  56da66:	62 a1 64 00 c6 c2 dd 	vshufps $0xdd,%xmm18,%xmm19,%xmm16
  56da6d:	62 e1 7c 08 10 4a 04 	vmovups 0x40(%rdx),%xmm17
  56da74:	62 e1 7c 08 10 52 06 	vmovups 0x60(%rdx),%xmm18
  56da7b:	62 e1 7c 08 10 5a 08 	vmovups 0x80(%rdx),%xmm19
  56da82:	62 e1 7c 08 10 6a 0a 	vmovups 0xa0(%rdx),%xmm21
  56da89:	62 e1 7c 08 10 72 10 	vmovups 0x100(%rdx),%xmm22
  56da90:	62 e1 7c 08 10 7a 12 	vmovups 0x120(%rdx),%xmm23
  56da97:	62 61 7c 08 10 42 14 	vmovups 0x140(%rdx),%xmm24
  56da9e:	62 61 7c 08 10 4a 16 	vmovups 0x160(%rdx),%xmm25
  56daa5:	62 61 7c 08 10 52 18 	vmovups 0x180(%rdx),%xmm26
  56daac:	62 61 7c 08 10 5a 1a 	vmovups 0x1a0(%rdx),%xmm27
  56dab3:	62 31 5c 08 59 c6    	vmulps %xmm22,%xmm4,%xmm8
  56dab9:	c5 f8 28 fc          	vmovaps %xmm4,%xmm7
  56dabd:	62 31 1c 00 59 cf    	vmulps %xmm23,%xmm28,%xmm9
  56dac3:	62 c1 3c 08 5c e1    	vsubps %xmm9,%xmm8,%xmm20
  56dac9:	62 31 24 08 59 c3    	vmulps %xmm19,%xmm11,%xmm8
  56dacf:	62 31 0c 08 59 cd    	vmulps %xmm21,%xmm14,%xmm9
  56dad5:	c4 c1 38 5c e1       	vsubps %xmm9,%xmm8,%xmm4
  56dada:	c5 f8 29 64 24 c8    	vmovaps %xmm4,-0x38(%rsp)
  56dae0:	62 11 4c 08 59 ca    	vmulps %xmm26,%xmm6,%xmm9
  56dae6:	62 01 1c 08 59 eb    	vmulps %xmm27,%xmm12,%xmm29
  56daec:	62 91 34 08 5c e5    	vsubps %xmm29,%xmm9,%xmm4
  56daf2:	c5 f8 29 64 24 b8    	vmovaps %xmm4,-0x48(%rsp)
  56daf8:	62 21 74 08 59 e9    	vmulps %xmm17,%xmm1,%xmm29
  56dafe:	c5 78 28 e9          	vmovaps %xmm1,%xmm13
  56db02:	62 21 64 08 59 f2    	vmulps %xmm18,%xmm3,%xmm30
  56db08:	c5 f8 28 f3          	vmovaps %xmm3,%xmm6
  56db0c:	62 01 14 00 5c ee    	vsubps %xmm30,%xmm29,%xmm29
  56db12:	62 01 7c 08 59 f0    	vmulps %xmm24,%xmm0,%xmm30
  56db18:	62 01 6c 08 59 f9    	vmulps %xmm25,%xmm2,%xmm31
  56db1e:	c5 78 28 d2          	vmovaps %xmm2,%xmm10
  56db22:	62 01 0c 00 5c f7    	vsubps %xmm31,%xmm30,%xmm30
  56db28:	62 61 7c 08 10 7a 0c 	vmovups 0xc0(%rdx),%xmm31
  56db2f:	c5 f8 10 a2 e0 00 00 	vmovups 0xe0(%rdx),%xmm4
  56db36:	00 
  56db37:	62 91 54 08 59 c7    	vmulps %xmm31,%xmm5,%xmm0
  56db3d:	c5 78 28 cd          	vmovaps %xmm5,%xmm9
  56db41:	c5 78 29 fb          	vmovaps %xmm15,%xmm3
  56db45:	c5 80 59 d4          	vmulps %xmm4,%xmm15,%xmm2
  56db49:	c5 78 5c c2          	vsubps %xmm2,%xmm0,%xmm8
  56db4d:	c4 e3 79 04 54 24 a8 	vpermilps $0xd8,-0x58(%rsp),%xmm2
  56db54:	d8 
  56db55:	62 31 7c 00 c6 f8 d8 	vshufps $0xd8,%xmm16,%xmm16,%xmm15
  56db5c:	62 e1 7c 08 10 42 1c 	vmovups 0x1c0(%rdx),%xmm16
  56db63:	c5 f8 10 8a e0 01 00 	vmovups 0x1e0(%rdx),%xmm1
  56db6a:	00 
  56db6b:	62 b1 6c 08 59 c0    	vmulps %xmm16,%xmm2,%xmm0
  56db71:	c5 80 59 e9          	vmulps %xmm1,%xmm15,%xmm5
  56db75:	c5 f8 5c c5          	vsubps %xmm5,%xmm0,%xmm0
  56db79:	62 b1 1c 00 59 ee    	vmulps %xmm22,%xmm28,%xmm5
  56db7f:	62 f1 44 00 59 ff    	vmulps %xmm7,%xmm23,%xmm7
  56db85:	c5 c0 58 ed          	vaddps %xmm5,%xmm7,%xmm5
  56db89:	62 b1 0c 08 59 fb    	vmulps %xmm19,%xmm14,%xmm7
  56db8f:	62 51 54 00 59 db    	vmulps %xmm11,%xmm21,%xmm11
  56db95:	c5 a0 58 ff          	vaddps %xmm7,%xmm11,%xmm7
  56db99:	62 11 1c 08 59 da    	vmulps %xmm26,%xmm12,%xmm11
  56db9f:	62 71 24 00 59 a4 24 	vmulps -0x78(%rsp),%xmm27,%xmm12
  56dba6:	88 ff ff ff 
  56dbaa:	c4 41 18 58 db       	vaddps %xmm11,%xmm12,%xmm11
  56dbaf:	62 b1 4c 08 59 f1    	vmulps %xmm17,%xmm6,%xmm6
  56dbb5:	62 51 6c 00 59 e5    	vmulps %xmm13,%xmm18,%xmm12
  56dbbb:	c5 98 58 f6          	vaddps %xmm6,%xmm12,%xmm6
  56dbbf:	62 11 2c 08 59 e0    	vmulps %xmm24,%xmm10,%xmm12
  56dbc5:	62 71 34 00 59 b4 24 	vmulps -0x68(%rsp),%xmm25,%xmm14
  56dbcc:	98 ff ff ff 
  56dbd0:	c4 41 08 58 e4       	vaddps %xmm12,%xmm14,%xmm12
  56dbd5:	62 11 64 08 59 ef    	vmulps %xmm31,%xmm3,%xmm13
  56dbdb:	c5 b0 59 dc          	vmulps %xmm4,%xmm9,%xmm3
  56dbdf:	c5 90 58 db          	vaddps %xmm3,%xmm13,%xmm3
  56dbe3:	62 31 04 08 59 d0    	vmulps %xmm16,%xmm15,%xmm10
  56dbe9:	c5 f0 59 ca          	vmulps %xmm2,%xmm1,%xmm1
  56dbed:	c4 e3 79 04 54 24 e8 	vpermilps $0xd8,-0x18(%rsp),%xmm2
  56dbf4:	d8 
  56dbf5:	c4 63 79 04 6c 24 d8 	vpermilps $0xd8,-0x28(%rsp),%xmm13
  56dbfc:	d8 
  56dbfd:	c5 a8 58 c9          	vaddps %xmm1,%xmm10,%xmm1
  56dc01:	62 31 6c 08 58 d4    	vaddps %xmm20,%xmm2,%xmm10
  56dc07:	62 b1 6c 08 5c d4    	vsubps %xmm20,%xmm2,%xmm2
  56dc0d:	c5 20 58 f7          	vaddps %xmm7,%xmm11,%xmm14
  56dc11:	c4 c1 40 5c fb       	vsubps %xmm11,%xmm7,%xmm7
  56dc16:	62 11 14 00 58 de    	vaddps %xmm30,%xmm29,%xmm11
  56dc1c:	62 11 14 00 5c fe    	vsubps %xmm30,%xmm29,%xmm15
  56dc22:	62 c1 4c 08 58 c4    	vaddps %xmm12,%xmm6,%xmm16
  56dc28:	c4 c1 48 5c f4       	vsubps %xmm12,%xmm6,%xmm6
  56dc2d:	c5 60 58 e1          	vaddps %xmm1,%xmm3,%xmm12
  56dc31:	c5 e0 5c c9          	vsubps %xmm1,%xmm3,%xmm1
  56dc35:	c5 b8 58 d8          	vaddps %xmm0,%xmm8,%xmm3
  56dc39:	c5 b8 5c c0          	vsubps %xmm0,%xmm8,%xmm0
  56dc3d:	c5 90 58 e5          	vaddps %xmm5,%xmm13,%xmm4
  56dc41:	c5 90 5c ed          	vsubps %xmm5,%xmm13,%xmm5
  56dc45:	c5 78 28 44 24 c8    	vmovaps -0x38(%rsp),%xmm8
  56dc4b:	c5 78 28 4c 24 b8    	vmovaps -0x48(%rsp),%xmm9
  56dc51:	c4 41 38 58 e9       	vaddps %xmm9,%xmm8,%xmm13
  56dc56:	c4 41 30 5c c0       	vsubps %xmm8,%xmm9,%xmm8
  56dc5b:	c5 00 58 ce          	vaddps %xmm6,%xmm15,%xmm9
  56dc5f:	c4 c1 48 5c f7       	vsubps %xmm15,%xmm6,%xmm6
  56dc64:	c5 70 5c f8          	vsubps %xmm0,%xmm1,%xmm15
  56dc68:	c5 f8 58 c1          	vaddps %xmm1,%xmm0,%xmm0
  56dc6c:	c4 e2 79 18 0d 73 e6 	vbroadcastss -0x4f198d(%rip),%xmm1        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56dc73:	b0 ff 
  56dc75:	c5 30 59 c9          	vmulps %xmm1,%xmm9,%xmm9
  56dc79:	c5 00 59 f9          	vmulps %xmm1,%xmm15,%xmm15
  56dc7d:	c5 c8 59 f1          	vmulps %xmm1,%xmm6,%xmm6
  56dc81:	c5 f8 59 c1          	vmulps %xmm1,%xmm0,%xmm0
  56dc85:	c4 c1 28 58 cd       	vaddps %xmm13,%xmm10,%xmm1
  56dc8a:	c4 41 28 5c d5       	vsubps %xmm13,%xmm10,%xmm10
  56dc8f:	62 51 7c 00 58 ec    	vaddps %xmm12,%xmm16,%xmm13
  56dc95:	62 51 7c 00 5c e4    	vsubps %xmm12,%xmm16,%xmm12
  56dc9b:	62 e1 0c 08 58 c4    	vaddps %xmm4,%xmm14,%xmm16
  56dca1:	c4 c1 58 5c e6       	vsubps %xmm14,%xmm4,%xmm4
  56dca6:	c5 20 58 f3          	vaddps %xmm3,%xmm11,%xmm14
  56dcaa:	c4 c1 60 5c db       	vsubps %xmm11,%xmm3,%xmm3
  56dcaf:	c5 68 58 df          	vaddps %xmm7,%xmm2,%xmm11
  56dcb3:	c5 e8 5c d7          	vsubps %xmm7,%xmm2,%xmm2
  56dcb7:	c5 c8 5c f8          	vsubps %xmm0,%xmm6,%xmm7
  56dcbb:	c5 c8 58 c0          	vaddps %xmm0,%xmm6,%xmm0
  56dcbf:	c5 b8 58 f5          	vaddps %xmm5,%xmm8,%xmm6
  56dcc3:	c4 c1 50 5c e8       	vsubps %xmm8,%xmm5,%xmm5
  56dcc8:	c4 41 30 58 c7       	vaddps %xmm15,%xmm9,%xmm8
  56dccd:	c4 41 00 5c c9       	vsubps %xmm9,%xmm15,%xmm9
  56dcd2:	c5 08 58 f9          	vaddps %xmm1,%xmm14,%xmm15
  56dcd6:	c4 c1 70 5c ce       	vsubps %xmm14,%xmm1,%xmm1
  56dcdb:	62 51 7c 00 58 f5    	vaddps %xmm13,%xmm16,%xmm14
  56dce1:	62 51 7c 00 5c ed    	vsubps %xmm13,%xmm16,%xmm13
  56dce7:	62 c1 24 08 58 c0    	vaddps %xmm8,%xmm11,%xmm16
  56dced:	c4 41 20 5c c0       	vsubps %xmm8,%xmm11,%xmm8
  56dcf2:	c5 48 58 df          	vaddps %xmm7,%xmm6,%xmm11
  56dcf6:	c5 c8 5c f7          	vsubps %xmm7,%xmm6,%xmm6
  56dcfa:	c4 c1 28 58 fc       	vaddps %xmm12,%xmm10,%xmm7
  56dcff:	c4 41 28 5c d4       	vsubps %xmm12,%xmm10,%xmm10
  56dd04:	c5 58 58 e3          	vaddps %xmm3,%xmm4,%xmm12
  56dd08:	c5 d8 5c db          	vsubps %xmm3,%xmm4,%xmm3
  56dd0c:	c5 e8 58 e0          	vaddps %xmm0,%xmm2,%xmm4
  56dd10:	c5 e8 5c c0          	vsubps %xmm0,%xmm2,%xmm0
  56dd14:	c5 b0 58 d5          	vaddps %xmm5,%xmm9,%xmm2
  56dd18:	c4 c1 50 5c e9       	vsubps %xmm9,%xmm5,%xmm5
  56dd1d:	c4 41 00 14 ce       	vunpcklps %xmm14,%xmm15,%xmm9
  56dd22:	c4 41 00 15 f6       	vunpckhps %xmm14,%xmm15,%xmm14
  56dd27:	c5 78 11 0e          	vmovups %xmm9,(%rsi)
  56dd2b:	c5 78 11 76 10       	vmovups %xmm14,0x10(%rsi)
  56dd30:	62 51 7c 00 14 cb    	vunpcklps %xmm11,%xmm16,%xmm9
  56dd36:	62 51 7c 00 15 db    	vunpckhps %xmm11,%xmm16,%xmm11
  56dd3c:	c5 78 11 4e 20       	vmovups %xmm9,0x20(%rsi)
  56dd41:	c5 78 11 5e 30       	vmovups %xmm11,0x30(%rsi)
  56dd46:	c4 41 40 14 cc       	vunpcklps %xmm12,%xmm7,%xmm9
  56dd4b:	c4 c1 40 15 fc       	vunpckhps %xmm12,%xmm7,%xmm7
  56dd50:	c5 78 11 4e 40       	vmovups %xmm9,0x40(%rsi)
  56dd55:	c5 f8 11 7e 50       	vmovups %xmm7,0x50(%rsi)
  56dd5a:	c5 d8 14 fa          	vunpcklps %xmm2,%xmm4,%xmm7
  56dd5e:	c5 d8 15 d2          	vunpckhps %xmm2,%xmm4,%xmm2
  56dd62:	c5 f8 11 7e 60       	vmovups %xmm7,0x60(%rsi)
  56dd67:	c5 f8 11 56 70       	vmovups %xmm2,0x70(%rsi)
  56dd6c:	c4 c1 70 14 d5       	vunpcklps %xmm13,%xmm1,%xmm2
  56dd71:	c4 c1 70 15 cd       	vunpckhps %xmm13,%xmm1,%xmm1
  56dd76:	c5 f8 11 96 80 00 00 	vmovups %xmm2,0x80(%rsi)
  56dd7d:	00 
  56dd7e:	c5 f8 11 8e 90 00 00 	vmovups %xmm1,0x90(%rsi)
  56dd85:	00 
  56dd86:	c5 b8 14 ce          	vunpcklps %xmm6,%xmm8,%xmm1
  56dd8a:	c5 b8 15 d6          	vunpckhps %xmm6,%xmm8,%xmm2
  56dd8e:	c5 f8 11 8e a0 00 00 	vmovups %xmm1,0xa0(%rsi)
  56dd95:	00 
  56dd96:	c5 f8 11 96 b0 00 00 	vmovups %xmm2,0xb0(%rsi)
  56dd9d:	00 
  56dd9e:	c5 a8 14 cb          	vunpcklps %xmm3,%xmm10,%xmm1
  56dda2:	c5 a8 15 d3          	vunpckhps %xmm3,%xmm10,%xmm2
  56dda6:	c5 f8 11 8e c0 00 00 	vmovups %xmm1,0xc0(%rsi)
  56ddad:	00 
  56ddae:	c5 f8 11 96 d0 00 00 	vmovups %xmm2,0xd0(%rsi)
  56ddb5:	00 
  56ddb6:	c5 f8 14 cd          	vunpcklps %xmm5,%xmm0,%xmm1
  56ddba:	c5 f8 15 c5          	vunpckhps %xmm5,%xmm0,%xmm0
  56ddbe:	c5 f8 11 8e e0 00 00 	vmovups %xmm1,0xe0(%rsi)
  56ddc5:	00 
  56ddc6:	c5 f8 11 86 f0 00 00 	vmovups %xmm0,0xf0(%rsi)
  56ddcd:	00 
  56ddce:	c5 f8 77             	vzeroupper
  56ddd1:	c3                   	ret
  56ddd2:	cc                   	int3
  56ddd3:	cc                   	int3
  56ddd4:	cc                   	int3
  56ddd5:	cc                   	int3
  56ddd6:	cc                   	int3
  56ddd7:	cc                   	int3
  56ddd8:	cc                   	int3
  56ddd9:	cc                   	int3
  56ddda:	cc                   	int3
  56dddb:	cc                   	int3
  56dddc:	cc                   	int3
  56dddd:	cc                   	int3
  56ddde:	cc                   	int3
  56dddf:	cc                   	int3


000000000056dde0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56dde0:	c5 fc 10 2f          	vmovups (%rdi),%ymm5
  56dde4:	c5 7c 10 57 20       	vmovups 0x20(%rdi),%ymm10
  56dde9:	c5 7c 10 5f 40       	vmovups 0x40(%rdi),%ymm11
  56ddee:	c5 7c 10 67 60       	vmovups 0x60(%rdi),%ymm12
  56ddf3:	c4 c1 54 c6 c2 dd    	vshufps $0xdd,%ymm10,%ymm5,%ymm0
  56ddf9:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56ddff:	c4 c1 24 c6 cc dd    	vshufps $0xdd,%ymm12,%ymm11,%ymm1
  56de05:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  56de0b:	c5 fc 58 f1          	vaddps %ymm1,%ymm0,%ymm6
  56de0f:	c4 e3 7d 19 f2 01    	vextractf128 $0x1,%ymm6,%xmm2
  56de15:	c4 41 30 57 c9       	vxorps %xmm9,%xmm9,%xmm9
  56de1a:	c4 c1 6d 15 d9       	vunpckhpd %ymm9,%ymm2,%ymm3
  56de1f:	c5 fc 5c c9          	vsubps %ymm1,%ymm0,%ymm1
  56de23:	c4 e3 7d 19 cf 01    	vextractf128 $0x1,%ymm1,%xmm7
  56de29:	c4 c1 45 15 e1       	vunpckhpd %ymm9,%ymm7,%ymm4
  56de2e:	c5 e4 c6 c4 dd       	vshufps $0xdd,%ymm4,%ymm3,%ymm0
  56de33:	c5 fc c6 c0 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm0
  56de38:	c5 e4 c6 dc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm3
  56de3d:	c5 e4 c6 e3 d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm4
  56de42:	c4 c3 6d 0c d9 cc    	vblendps $0xcc,%ymm9,%ymm2,%ymm3
  56de48:	c4 c3 45 0c f9 cc    	vblendps $0xcc,%ymm9,%ymm7,%ymm7
  56de4e:	c5 e4 c6 d7 dd       	vshufps $0xdd,%ymm7,%ymm3,%ymm2
  56de53:	c5 ec c6 d2 d8       	vshufps $0xd8,%ymm2,%ymm2,%ymm2
  56de58:	c5 e4 c6 df 88       	vshufps $0x88,%ymm7,%ymm3,%ymm3
  56de5d:	c5 e4 c6 fb d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm7
  56de62:	c5 f8 28 de          	vmovaps %xmm6,%xmm3
  56de66:	c5 bd 73 db 08       	vpsrldq $0x8,%ymm3,%ymm8
  56de6b:	c5 f8 28 d9          	vmovaps %xmm1,%xmm3
  56de6f:	c5 95 73 db 08       	vpsrldq $0x8,%ymm3,%ymm13
  56de74:	c4 c1 3c c6 dd dd    	vshufps $0xdd,%ymm13,%ymm8,%ymm3
  56de7a:	c5 e4 c6 db d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm3
  56de7f:	c4 41 3c c6 c5 88    	vshufps $0x88,%ymm13,%ymm8,%ymm8
  56de85:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  56de8b:	c5 7a 7e ee          	vmovq  %xmm6,%xmm13
  56de8f:	c5 fa 7e c9          	vmovq  %xmm1,%xmm1
  56de93:	c5 94 c6 f1 dd       	vshufps $0xdd,%ymm1,%ymm13,%ymm6
  56de98:	c5 cc c6 f6 d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm6
  56de9d:	c5 94 c6 c9 88       	vshufps $0x88,%ymm1,%ymm13,%ymm1
  56dea2:	c5 f4 c6 c9 d8       	vshufps $0xd8,%ymm1,%ymm1,%ymm1
  56dea7:	c4 c1 54 c6 ea 88    	vshufps $0x88,%ymm10,%ymm5,%ymm5
  56dead:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  56deb3:	c4 41 24 c6 d4 88    	vshufps $0x88,%ymm12,%ymm11,%ymm10
  56deb9:	c4 43 fd 01 d2 d8    	vpermpd $0xd8,%ymm10,%ymm10
  56debf:	c5 2c 58 dd          	vaddps %ymm5,%ymm10,%ymm11
  56dec3:	c4 43 7d 19 dd 01    	vextractf128 $0x1,%ymm11,%xmm13
  56dec9:	c4 41 15 15 e1       	vunpckhpd %ymm9,%ymm13,%ymm12
  56dece:	c4 41 54 5c f2       	vsubps %ymm10,%ymm5,%ymm14
  56ded3:	c4 43 7d 19 f2 01    	vextractf128 $0x1,%ymm14,%xmm10
  56ded9:	c4 41 2d 15 f9       	vunpckhpd %ymm9,%ymm10,%ymm15
  56dede:	c4 c1 1c c6 ef dd    	vshufps $0xdd,%ymm15,%ymm12,%ymm5
  56dee4:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  56dee9:	c4 41 1c c6 e7 88    	vshufps $0x88,%ymm15,%ymm12,%ymm12
  56deef:	c4 41 1c c6 e4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm12
  56def5:	c4 43 15 0c e9 cc    	vblendps $0xcc,%ymm9,%ymm13,%ymm13
  56defb:	c4 43 2d 0c d1 cc    	vblendps $0xcc,%ymm9,%ymm10,%ymm10
  56df01:	c4 41 14 c6 ca dd    	vshufps $0xdd,%ymm10,%ymm13,%ymm9
  56df07:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  56df0d:	c4 41 14 c6 d2 88    	vshufps $0x88,%ymm10,%ymm13,%ymm10
  56df13:	62 c1 2c 28 c6 ca d8 	vshufps $0xd8,%ymm10,%ymm10,%ymm17
  56df1a:	c4 41 78 28 d3       	vmovaps %xmm11,%xmm10
  56df1f:	c4 c1 15 73 da 08    	vpsrldq $0x8,%ymm10,%ymm13
  56df25:	c4 41 78 28 d6       	vmovaps %xmm14,%xmm10
  56df2a:	c4 c1 05 73 da 08    	vpsrldq $0x8,%ymm10,%ymm15
  56df30:	c4 41 14 c6 d7 dd    	vshufps $0xdd,%ymm15,%ymm13,%ymm10
  56df36:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  56df3c:	c4 41 14 c6 ef 88    	vshufps $0x88,%ymm15,%ymm13,%ymm13
  56df42:	62 c1 14 28 c6 d5 d8 	vshufps $0xd8,%ymm13,%ymm13,%ymm18
  56df49:	c4 41 7a 7e db       	vmovq  %xmm11,%xmm11
  56df4e:	c4 41 7a 7e ee       	vmovq  %xmm14,%xmm13
  56df53:	c4 41 24 c6 f5 dd    	vshufps $0xdd,%ymm13,%ymm11,%ymm14
  56df59:	62 c1 0c 28 c6 c6 d8 	vshufps $0xd8,%ymm14,%ymm14,%ymm16
  56df60:	c4 41 24 c6 dd 88    	vshufps $0x88,%ymm13,%ymm11,%ymm11
  56df66:	c4 41 24 c6 db d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm11
  56df6c:	62 e1 7c 28 10 5a 02 	vmovups 0x40(%rdx),%ymm19
  56df73:	62 e1 7c 28 10 62 03 	vmovups 0x60(%rdx),%ymm20
  56df7a:	62 e1 7c 28 10 6a 04 	vmovups 0x80(%rdx),%ymm21
  56df81:	62 e1 7c 28 10 72 05 	vmovups 0xa0(%rdx),%ymm22
  56df88:	c5 7c 10 b2 c0 00 00 	vmovups 0xc0(%rdx),%ymm14
  56df8f:	00 
  56df90:	c5 7c 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm13
  56df97:	00 
  56df98:	62 e1 7c 28 10 7a 08 	vmovups 0x100(%rdx),%ymm23
  56df9f:	62 61 7c 28 10 42 09 	vmovups 0x120(%rdx),%ymm24
  56dfa6:	62 61 7c 28 10 4a 0a 	vmovups 0x140(%rdx),%ymm25
  56dfad:	62 31 74 20 59 ff    	vmulps %ymm23,%ymm17,%ymm15
  56dfb3:	62 12 45 28 bc f8    	vfnmadd231ps %ymm24,%ymm7,%ymm15
  56dfb9:	62 a1 44 28 59 ff    	vmulps %ymm23,%ymm7,%ymm23
  56dfbf:	62 61 7c 28 10 52 0b 	vmovups 0x160(%rdx),%ymm26
  56dfc6:	62 82 75 20 b8 f8    	vfmadd231ps %ymm24,%ymm17,%ymm23
  56dfcc:	c5 fc 10 ba 80 01 00 	vmovups 0x180(%rdx),%ymm7
  56dfd3:	00 
  56dfd4:	62 a1 6c 20 59 cd    	vmulps %ymm21,%ymm18,%ymm17
  56dfda:	62 a2 3d 28 bc ce    	vfnmadd231ps %ymm22,%ymm8,%ymm17
  56dfe0:	62 31 3c 28 59 c5    	vmulps %ymm21,%ymm8,%ymm8
  56dfe6:	62 e1 7c 28 10 6a 0d 	vmovups 0x1a0(%rdx),%ymm21
  56dfed:	62 32 6d 20 b8 c6    	vfmadd231ps %ymm22,%ymm18,%ymm8
  56dff3:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  56dffa:	62 e1 1c 28 59 f7    	vmulps %ymm7,%ymm12,%ymm22
  56e000:	62 a2 5d 28 bc f5    	vfnmadd231ps %ymm21,%ymm4,%ymm22
  56e006:	62 61 5c 28 59 c7    	vmulps %ymm7,%ymm4,%ymm24
  56e00c:	62 61 7c 28 10 5a 0f 	vmovups 0x1e0(%rdx),%ymm27
  56e013:	62 22 1d 28 b8 c5    	vfmadd231ps %ymm21,%ymm12,%ymm24
  56e019:	c4 c1 24 58 e7       	vaddps %ymm15,%ymm11,%ymm4
  56e01e:	62 31 7c 20 59 e3    	vmulps %ymm19,%ymm16,%ymm12
  56e024:	62 32 4d 28 bc e4    	vfnmadd231ps %ymm20,%ymm6,%ymm12
  56e02a:	62 a1 4c 28 59 db    	vmulps %ymm19,%ymm6,%ymm19
  56e030:	62 b1 74 20 58 f6    	vaddps %ymm22,%ymm17,%ymm6
  56e036:	62 a2 7d 20 b8 dc    	vfmadd231ps %ymm20,%ymm16,%ymm19
  56e03c:	62 81 34 28 59 c1    	vmulps %ymm25,%ymm9,%ymm16
  56e042:	62 82 6d 28 bc c2    	vfnmadd231ps %ymm26,%ymm2,%ymm16
  56e048:	62 b1 1c 28 58 f8    	vaddps %ymm16,%ymm12,%ymm7
  56e04e:	62 91 6c 28 59 d1    	vmulps %ymm25,%ymm2,%ymm2
  56e054:	62 c1 2c 28 59 e6    	vmulps %ymm14,%ymm10,%ymm20
  56e05a:	62 c2 65 28 bc e5    	vfnmadd231ps %ymm13,%ymm3,%ymm20
  56e060:	62 92 35 28 b8 d2    	vfmadd231ps %ymm26,%ymm9,%ymm2
  56e066:	62 31 54 28 59 ca    	vmulps %ymm18,%ymm5,%ymm9
  56e06c:	62 12 7d 28 bc cb    	vfnmadd231ps %ymm27,%ymm0,%ymm9
  56e072:	62 c1 5c 20 58 e9    	vaddps %ymm9,%ymm20,%ymm21
  56e078:	c5 8c 59 db          	vmulps %ymm3,%ymm14,%ymm3
  56e07c:	62 71 44 20 58 f1    	vaddps %ymm1,%ymm23,%ymm14
  56e082:	c4 c2 2d b8 dd       	vfmadd231ps %ymm13,%ymm10,%ymm3
  56e087:	62 11 3c 28 58 d0    	vaddps %ymm24,%ymm8,%ymm10
  56e08d:	62 71 64 20 58 ea    	vaddps %ymm2,%ymm19,%ymm13
  56e093:	62 b1 7c 28 59 c2    	vmulps %ymm18,%ymm0,%ymm0
  56e099:	62 92 55 28 b8 c3    	vfmadd231ps %ymm27,%ymm5,%ymm0
  56e09f:	c5 e4 58 e8          	vaddps %ymm0,%ymm3,%ymm5
  56e0a3:	c4 41 24 5c df       	vsubps %ymm15,%ymm11,%ymm11
  56e0a8:	62 11 3c 28 5c c0    	vsubps %ymm24,%ymm8,%ymm8
  56e0ae:	62 31 1c 28 5c e0    	vsubps %ymm16,%ymm12,%ymm12
  56e0b4:	62 f1 64 20 5c d2    	vsubps %ymm2,%ymm19,%ymm2
  56e0ba:	c4 62 7d 18 3d 25 e2 	vbroadcastss -0x4f1ddb(%rip),%ymm15        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56e0c1:	b0 ff 
  56e0c3:	62 e1 1c 28 58 c2    	vaddps %ymm2,%ymm12,%ymm16
  56e0c9:	62 c1 7c 20 59 c7    	vmulps %ymm15,%ymm16,%ymm16
  56e0cf:	c5 e4 5c c0          	vsubps %ymm0,%ymm3,%ymm0
  56e0d3:	62 d1 5c 20 5c d9    	vsubps %ymm9,%ymm20,%ymm3
  56e0d9:	c5 7c 5c cb          	vsubps %ymm3,%ymm0,%ymm9
  56e0dd:	c4 41 34 59 cf       	vmulps %ymm15,%ymm9,%ymm9
  56e0e2:	62 b1 74 28 5c cf    	vsubps %ymm23,%ymm1,%ymm1
  56e0e8:	62 a1 4c 20 5c c9    	vsubps %ymm17,%ymm22,%ymm17
  56e0ee:	c4 c1 6c 5c d4       	vsubps %ymm12,%ymm2,%ymm2
  56e0f3:	c5 84 59 d2          	vmulps %ymm2,%ymm15,%ymm2
  56e0f7:	c5 e4 58 c0          	vaddps %ymm0,%ymm3,%ymm0
  56e0fb:	c5 84 59 c0          	vmulps %ymm0,%ymm15,%ymm0
  56e0ff:	c5 90 58 dd          	vaddps %xmm5,%xmm13,%xmm3
  56e103:	c4 41 28 58 e6       	vaddps %xmm14,%xmm10,%xmm12
  56e108:	c5 18 58 fb          	vaddps %xmm3,%xmm12,%xmm15
  56e10c:	62 a1 44 08 58 d5    	vaddps %xmm21,%xmm7,%xmm18
  56e112:	62 e1 5c 08 58 de    	vaddps %xmm6,%xmm4,%xmm19
  56e118:	62 a1 64 00 58 e2    	vaddps %xmm18,%xmm19,%xmm20
  56e11e:	62 51 5c 00 14 ff    	vunpcklps %xmm15,%xmm20,%xmm15
  56e124:	c5 78 11 3e          	vmovups %xmm15,(%rsi)
  56e128:	c5 68 5c f8          	vsubps %xmm0,%xmm2,%xmm15
  56e12c:	62 e1 74 00 58 e1    	vaddps %xmm1,%xmm17,%xmm20
  56e132:	62 c1 5c 00 58 f7    	vaddps %xmm15,%xmm20,%xmm22
  56e138:	62 c1 7c 00 58 f9    	vaddps %xmm9,%xmm16,%xmm23
  56e13e:	62 41 24 08 58 c0    	vaddps %xmm8,%xmm11,%xmm24
  56e144:	62 21 3c 00 58 cf    	vaddps %xmm23,%xmm24,%xmm25
  56e14a:	62 a1 34 00 14 f6    	vunpcklps %xmm22,%xmm25,%xmm22
  56e150:	62 e1 7c 08 11 76 01 	vmovups %xmm22,0x10(%rsi)
  56e157:	62 f1 54 00 5c ff    	vsubps %xmm7,%xmm21,%xmm7
  56e15d:	c4 41 08 5c d2       	vsubps %xmm10,%xmm14,%xmm10
  56e162:	c5 90 5c ed          	vsubps %xmm5,%xmm13,%xmm5
  56e166:	c5 28 58 ef          	vaddps %xmm7,%xmm10,%xmm13
  56e16a:	c5 d8 5c e6          	vsubps %xmm6,%xmm4,%xmm4
  56e16e:	c5 d8 58 f5          	vaddps %xmm5,%xmm4,%xmm6
  56e172:	c4 c1 48 14 f5       	vunpcklps %xmm13,%xmm6,%xmm6
  56e177:	c5 f8 11 76 20       	vmovups %xmm6,0x20(%rsi)
  56e17c:	62 b1 34 08 5c f0    	vsubps %xmm16,%xmm9,%xmm6
  56e182:	62 b1 74 08 5c c9    	vsubps %xmm17,%xmm1,%xmm1
  56e188:	c5 e8 58 c0          	vaddps %xmm0,%xmm2,%xmm0
  56e18c:	c5 f0 58 d6          	vaddps %xmm6,%xmm1,%xmm2
  56e190:	c4 41 20 5c c0       	vsubps %xmm8,%xmm11,%xmm8
  56e195:	c5 38 58 c8          	vaddps %xmm0,%xmm8,%xmm9
  56e199:	c5 b0 14 d2          	vunpcklps %xmm2,%xmm9,%xmm2
  56e19d:	c5 f8 11 56 30       	vmovups %xmm2,0x30(%rsi)
  56e1a2:	c5 98 5c d3          	vsubps %xmm3,%xmm12,%xmm2
  56e1a6:	62 b1 64 00 5c da    	vsubps %xmm18,%xmm19,%xmm3
  56e1ac:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  56e1b0:	c5 f8 11 56 40       	vmovups %xmm2,0x40(%rsi)
  56e1b5:	62 d1 5c 00 5c d7    	vsubps %xmm15,%xmm20,%xmm2
  56e1bb:	62 b1 3c 00 5c df    	vsubps %xmm23,%xmm24,%xmm3
  56e1c1:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  56e1c5:	c5 f8 11 56 50       	vmovups %xmm2,0x50(%rsi)
  56e1ca:	c5 a8 5c d7          	vsubps %xmm7,%xmm10,%xmm2
  56e1ce:	c5 d8 5c dd          	vsubps %xmm5,%xmm4,%xmm3
  56e1d2:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  56e1d6:	c5 f8 11 56 60       	vmovups %xmm2,0x60(%rsi)
  56e1db:	c5 f0 5c ce          	vsubps %xmm6,%xmm1,%xmm1
  56e1df:	c5 b8 5c c0          	vsubps %xmm0,%xmm8,%xmm0
  56e1e3:	c5 f8 14 c1          	vunpcklps %xmm1,%xmm0,%xmm0
  56e1e7:	c5 f8 11 46 70       	vmovups %xmm0,0x70(%rsi)
  56e1ec:	c5 f8 77             	vzeroupper
  56e1ef:	c3                   	ret


000000000056e1f0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56e1f0:	c5 fc 10 0f          	vmovups (%rdi),%ymm1
  56e1f4:	c5 fc 10 57 20       	vmovups 0x20(%rdi),%ymm2
  56e1f9:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  56e1fe:	c5 fc 10 7f 60       	vmovups 0x60(%rdi),%ymm7
  56e203:	c5 7c 10 87 80 00 00 	vmovups 0x80(%rdi),%ymm8
  56e20a:	00 
  56e20b:	c5 7c 10 8f a0 00 00 	vmovups 0xa0(%rdi),%ymm9
  56e212:	00 
  56e213:	c5 7c 10 97 c0 00 00 	vmovups 0xc0(%rdi),%ymm10
  56e21a:	00 
  56e21b:	c5 7c 10 9f e0 00 00 	vmovups 0xe0(%rdi),%ymm11
  56e222:	00 
  56e223:	c5 7c 10 af 00 01 00 	vmovups 0x100(%rdi),%ymm13
  56e22a:	00 
  56e22b:	c5 7c 10 b7 20 01 00 	vmovups 0x120(%rdi),%ymm14
  56e232:	00 
  56e233:	c5 f4 c6 da 88       	vshufps $0x88,%ymm2,%ymm1,%ymm3
  56e238:	62 e3 fd 28 01 c3 d8 	vpermpd $0xd8,%ymm3,%ymm16
  56e23f:	c5 fc c6 df 88       	vshufps $0x88,%ymm7,%ymm0,%ymm3
  56e244:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  56e24a:	c4 c1 14 c6 e6 88    	vshufps $0x88,%ymm14,%ymm13,%ymm4
  56e250:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  56e256:	62 e1 64 28 58 d4    	vaddps %ymm4,%ymm3,%ymm18
  56e25c:	62 31 7c 20 58 e2    	vaddps %ymm18,%ymm16,%ymm12
  56e262:	c4 c1 3c c6 e9 88    	vshufps $0x88,%ymm9,%ymm8,%ymm5
  56e268:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  56e26e:	c4 c1 2c c6 f3 88    	vshufps $0x88,%ymm11,%ymm10,%ymm6
  56e274:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  56e27a:	62 e1 54 28 58 de    	vaddps %ymm6,%ymm5,%ymm19
  56e280:	62 a1 1c 28 58 e3    	vaddps %ymm19,%ymm12,%ymm20
  56e286:	c5 fc c6 c7 dd       	vshufps $0xdd,%ymm7,%ymm0,%ymm0
  56e28b:	c4 63 fd 01 e0 d8    	vpermpd $0xd8,%ymm0,%ymm12
  56e291:	c4 c1 14 c6 c6 dd    	vshufps $0xdd,%ymm14,%ymm13,%ymm0
  56e297:	c4 63 fd 01 f0 d8    	vpermpd $0xd8,%ymm0,%ymm14
  56e29d:	c4 c1 1c 5c c6       	vsubps %ymm14,%ymm12,%ymm0
  56e2a2:	c4 c1 3c c6 f9 dd    	vshufps $0xdd,%ymm9,%ymm8,%ymm7
  56e2a8:	c4 63 fd 01 ff d8    	vpermpd $0xd8,%ymm7,%ymm15
  56e2ae:	c4 c1 2c c6 fb dd    	vshufps $0xdd,%ymm11,%ymm10,%ymm7
  56e2b4:	62 e3 fd 28 01 cf d8 	vpermpd $0xd8,%ymm7,%ymm17
  56e2bb:	62 31 04 28 5c d9    	vsubps %ymm17,%ymm15,%ymm11
  56e2c1:	c4 62 7d 18 05 ce e6 	vbroadcastss -0x4f1932(%rip),%ymm8        # 7c998 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x30a8>
  56e2c8:	b0 ff 
  56e2ca:	c4 41 24 59 e8       	vmulps %ymm8,%ymm11,%ymm13
  56e2cf:	c4 62 7d 18 0d 04 e0 	vbroadcastss -0x4f1ffc(%rip),%ymm9        # 7c2dc <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29ec>
  56e2d6:	b0 ff 
  56e2d8:	c4 62 7d 18 15 cb e5 	vbroadcastss -0x4f1a35(%rip),%ymm10        # 7c8ac <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2fbc>
  56e2df:	b0 ff 
  56e2e1:	c4 42 7d b8 e9       	vfmadd231ps %ymm9,%ymm0,%ymm13
  56e2e6:	62 c1 7c 28 28 ea    	vmovaps %ymm10,%ymm21
  56e2ec:	c4 e2 7d 18 3d 73 e4 	vbroadcastss -0x4f1b8d(%rip),%ymm7        # 7c768 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2e78>
  56e2f3:	b0 ff 
  56e2f5:	62 a2 6d 20 a8 e8    	vfmadd213ps %ymm16,%ymm18,%ymm21
  56e2fb:	62 e2 65 20 bc ef    	vfnmadd231ps %ymm7,%ymm19,%ymm21
  56e301:	62 a1 14 28 58 f5    	vaddps %ymm21,%ymm13,%ymm22
  56e307:	62 a3 dd 20 23 fe 03 	vshuff64x2 $0x3,%ymm22,%ymm20,%ymm23
  56e30e:	62 a2 45 28 ac d0    	vfnmadd213ps %ymm16,%ymm7,%ymm18
  56e314:	62 a2 2d 28 b8 d3    	vfmadd231ps %ymm19,%ymm10,%ymm18
  56e31a:	c5 bc 59 c0          	vmulps %ymm0,%ymm8,%ymm0
  56e31e:	c4 c2 35 bc c3       	vfnmadd231ps %ymm11,%ymm9,%ymm0
  56e323:	62 e1 6c 20 5c d8    	vsubps %ymm0,%ymm18,%ymm19
  56e329:	62 a3 7d 28 19 d8 01 	vextractf32x4 $0x1,%ymm19,%xmm16
  56e330:	62 21 c5 20 15 c0    	vunpckhpd %ymm16,%ymm23,%ymm24
  56e336:	62 c1 54 20 5c ed    	vsubps %ymm13,%ymm21,%ymm21
  56e33c:	62 83 7d 28 19 e9 01 	vextractf32x4 $0x1,%ymm21,%xmm25
  56e343:	62 b1 7c 28 58 c2    	vaddps %ymm18,%ymm0,%ymm0
  56e349:	62 b3 7d 28 19 c2 01 	vextractf32x4 $0x1,%ymm0,%xmm18
  56e350:	62 31 b5 20 15 ea    	vunpckhpd %ymm18,%ymm25,%ymm13
  56e356:	62 51 3c 20 c6 dd dd 	vshufps $0xdd,%ymm13,%ymm24,%ymm11
  56e35d:	62 51 3c 20 c6 ed 88 	vshufps $0x88,%ymm13,%ymm24,%ymm13
  56e364:	62 a1 c5 20 14 f8    	vunpcklpd %ymm16,%ymm23,%ymm23
  56e36a:	62 a1 b5 20 14 d2    	vunpcklpd %ymm18,%ymm25,%ymm18
  56e370:	62 a1 44 20 c6 c2 dd 	vshufps $0xdd,%ymm18,%ymm23,%ymm16
  56e377:	62 a1 44 20 c6 d2 88 	vshufps $0x88,%ymm18,%ymm23,%ymm18
  56e37e:	62 a3 5d 20 18 e6 01 	vinsertf32x4 $0x1,%xmm22,%ymm20,%ymm20
  56e385:	62 a1 7c 08 28 db    	vmovaps %xmm19,%xmm19
  56e38b:	62 a1 dd 20 15 f3    	vunpckhpd %ymm19,%ymm20,%ymm22
  56e391:	62 a1 7c 08 28 ed    	vmovaps %xmm21,%xmm21
  56e397:	c5 f8 28 c0          	vmovaps %xmm0,%xmm0
  56e39b:	62 e1 d5 20 15 f8    	vunpckhpd %ymm0,%ymm21,%ymm23
  56e3a1:	62 21 4c 20 c6 c7 dd 	vshufps $0xdd,%ymm23,%ymm22,%ymm24
  56e3a8:	62 a1 4c 20 c6 f7 88 	vshufps $0x88,%ymm23,%ymm22,%ymm22
  56e3af:	62 a1 dd 20 14 db    	vunpcklpd %ymm19,%ymm20,%ymm19
  56e3b5:	62 f1 d5 20 14 c0    	vunpcklpd %ymm0,%ymm21,%ymm0
  56e3bb:	62 e1 64 20 c6 e0 dd 	vshufps $0xdd,%ymm0,%ymm19,%ymm20
  56e3c2:	62 f1 64 20 c6 c0 88 	vshufps $0x88,%ymm0,%ymm19,%ymm0
  56e3c9:	c5 f4 c6 ca dd       	vshufps $0xdd,%ymm2,%ymm1,%ymm1
  56e3ce:	c4 c1 1c 58 d6       	vaddps %ymm14,%ymm12,%ymm2
  56e3d3:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  56e3d9:	62 31 04 28 58 e1    	vaddps %ymm17,%ymm15,%ymm12
  56e3df:	c5 74 58 f2          	vaddps %ymm2,%ymm1,%ymm14
  56e3e3:	c4 41 0c 58 fc       	vaddps %ymm12,%ymm14,%ymm15
  56e3e8:	c5 e4 5c dc          	vsubps %ymm4,%ymm3,%ymm3
  56e3ec:	c5 7c 29 d4          	vmovaps %ymm10,%ymm4
  56e3f0:	c4 e2 6d a8 e1       	vfmadd213ps %ymm1,%ymm2,%ymm4
  56e3f5:	c4 e2 1d bc e7       	vfnmadd231ps %ymm7,%ymm12,%ymm4
  56e3fa:	c5 d4 5c ee          	vsubps %ymm6,%ymm5,%ymm5
  56e3fe:	c5 bc 59 f5          	vmulps %ymm5,%ymm8,%ymm6
  56e402:	c4 c2 65 b8 f1       	vfmadd231ps %ymm9,%ymm3,%ymm6
  56e407:	c4 e2 6d ac f9       	vfnmadd213ps %ymm1,%ymm2,%ymm7
  56e40c:	62 e1 5c 28 5c ce    	vsubps %ymm6,%ymm4,%ymm17
  56e412:	62 33 85 28 23 f1 03 	vshuff64x2 $0x3,%ymm17,%ymm15,%ymm14
  56e419:	c4 c2 1d b8 fa       	vfmadd231ps %ymm10,%ymm12,%ymm7
  56e41e:	c5 bc 59 cb          	vmulps %ymm3,%ymm8,%ymm1
  56e422:	c4 c2 55 bc c9       	vfnmadd231ps %ymm9,%ymm5,%ymm1
  56e427:	c5 44 58 c1          	vaddps %ymm1,%ymm7,%ymm8
  56e42b:	c4 63 7d 19 c5 01    	vextractf128 $0x1,%ymm8,%xmm5
  56e431:	c5 8d 15 d5          	vunpckhpd %ymm5,%ymm14,%ymm2
  56e435:	c5 5c 58 ce          	vaddps %ymm6,%ymm4,%ymm9
  56e439:	62 33 7d 28 19 cb 01 	vextractf32x4 $0x1,%ymm9,%xmm19
  56e440:	62 e1 44 28 5c e9    	vsubps %ymm1,%ymm7,%ymm21
  56e446:	62 a3 7d 28 19 ef 01 	vextractf32x4 $0x1,%ymm21,%xmm23
  56e44d:	62 b1 e5 20 15 cf    	vunpckhpd %ymm23,%ymm19,%ymm1
  56e453:	c5 6c c6 d1 dd       	vshufps $0xdd,%ymm1,%ymm2,%ymm10
  56e458:	62 61 6c 28 c6 c9 88 	vshufps $0x88,%ymm1,%ymm2,%ymm25
  56e45f:	c4 c1 24 c6 cb d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm1
  56e465:	c4 c1 14 c6 fd d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm7
  56e46b:	62 b1 7c 20 c6 e0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm4
  56e472:	62 31 6c 20 c6 ea d8 	vshufps $0xd8,%ymm18,%ymm18,%ymm13
  56e479:	62 91 3c 20 c6 d8 d8 	vshufps $0xd8,%ymm24,%ymm24,%ymm3
  56e480:	62 31 4c 20 c6 e6 d8 	vshufps $0xd8,%ymm22,%ymm22,%ymm12
  56e487:	62 b1 5c 20 c6 f4 d8 	vshufps $0xd8,%ymm20,%ymm20,%ymm6
  56e48e:	c4 c1 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm2
  56e494:	62 11 34 20 c6 d1 d8 	vshufps $0xd8,%ymm25,%ymm25,%ymm10
  56e49b:	c5 0d 14 dd          	vunpcklpd %ymm5,%ymm14,%ymm11
  56e49f:	62 31 e5 20 14 f7    	vunpcklpd %ymm23,%ymm19,%ymm14
  56e4a5:	c4 c1 24 c6 ee dd    	vshufps $0xdd,%ymm14,%ymm11,%ymm5
  56e4ab:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  56e4b0:	c4 41 24 c6 de 88    	vshufps $0x88,%ymm14,%ymm11,%ymm11
  56e4b6:	c4 41 24 c6 f3 d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm14
  56e4bc:	62 33 05 28 18 d9 01 	vinsertf32x4 $0x1,%xmm17,%ymm15,%ymm11
  56e4c3:	c4 41 78 28 f8       	vmovaps %xmm8,%xmm15
  56e4c8:	62 c1 a5 28 15 c7    	vunpckhpd %ymm15,%ymm11,%ymm16
  56e4ce:	c4 41 78 28 c9       	vmovaps %xmm9,%xmm9
  56e4d3:	62 a1 7c 08 28 cd    	vmovaps %xmm21,%xmm17
  56e4d9:	62 a1 b5 28 15 d1    	vunpckhpd %ymm17,%ymm9,%ymm18
  56e4df:	62 31 7c 20 c6 c2 dd 	vshufps $0xdd,%ymm18,%ymm16,%ymm8
  56e4e6:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  56e4ec:	62 a1 7c 20 c6 c2 88 	vshufps $0x88,%ymm18,%ymm16,%ymm16
  56e4f3:	62 a1 7c 20 c6 c0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm16
  56e4fa:	c4 41 25 14 df       	vunpcklpd %ymm15,%ymm11,%ymm11
  56e4ff:	62 31 b5 28 14 c9    	vunpcklpd %ymm17,%ymm9,%ymm9
  56e505:	c4 41 24 c6 f9 dd    	vshufps $0xdd,%ymm9,%ymm11,%ymm15
  56e50b:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  56e511:	c4 41 24 c6 c9 88    	vshufps $0x88,%ymm9,%ymm11,%ymm9
  56e517:	62 e1 7c 28 10 4a 08 	vmovups 0x100(%rdx),%ymm17
  56e51e:	62 e1 7c 28 10 52 09 	vmovups 0x120(%rdx),%ymm18
  56e525:	62 31 0c 28 59 d9    	vmulps %ymm17,%ymm14,%ymm11
  56e52b:	62 32 15 28 bc da    	vfnmadd231ps %ymm18,%ymm13,%ymm11
  56e531:	62 31 14 28 59 e9    	vmulps %ymm17,%ymm13,%ymm13
  56e537:	62 e1 7c 28 10 4a 04 	vmovups 0x80(%rdx),%ymm17
  56e53e:	62 32 0d 28 b8 ea    	vfmadd231ps %ymm18,%ymm14,%ymm13
  56e544:	62 e1 7c 28 10 52 05 	vmovups 0xa0(%rdx),%ymm18
  56e54b:	62 31 7c 20 59 f1    	vmulps %ymm17,%ymm16,%ymm14
  56e551:	62 32 1d 28 bc f2    	vfnmadd231ps %ymm18,%ymm12,%ymm14
  56e557:	62 a1 1c 28 59 c9    	vmulps %ymm17,%ymm12,%ymm17
  56e55d:	62 e1 7c 28 10 5a 0c 	vmovups 0x180(%rdx),%ymm19
  56e564:	62 a2 7d 20 b8 ca    	vfmadd231ps %ymm18,%ymm16,%ymm17
  56e56a:	62 e1 7c 28 10 42 0d 	vmovups 0x1a0(%rdx),%ymm16
  56e571:	62 31 2c 28 59 e3    	vmulps %ymm19,%ymm10,%ymm12
  56e577:	62 32 45 28 bc e0    	vfnmadd231ps %ymm16,%ymm7,%ymm12
  56e57d:	62 b1 44 28 59 fb    	vmulps %ymm19,%ymm7,%ymm7
  56e583:	62 e1 7c 28 10 52 02 	vmovups 0x40(%rdx),%ymm18
  56e58a:	62 b2 2d 28 b8 f8    	vfmadd231ps %ymm16,%ymm10,%ymm7
  56e590:	c5 7c 10 52 60       	vmovups 0x60(%rdx),%ymm10
  56e595:	62 a1 04 28 59 c2    	vmulps %ymm18,%ymm15,%ymm16
  56e59b:	62 c2 4d 28 bc c2    	vfnmadd231ps %ymm10,%ymm6,%ymm16
  56e5a1:	62 b1 4c 28 59 f2    	vmulps %ymm18,%ymm6,%ymm6
  56e5a7:	62 e1 7c 28 10 52 0a 	vmovups 0x140(%rdx),%ymm18
  56e5ae:	c4 c2 05 b8 f2       	vfmadd231ps %ymm10,%ymm15,%ymm6
  56e5b3:	c5 7c 10 92 60 01 00 	vmovups 0x160(%rdx),%ymm10
  56e5ba:	00 
  56e5bb:	62 31 54 28 59 fa    	vmulps %ymm18,%ymm5,%ymm15
  56e5c1:	c4 42 5d bc fa       	vfnmadd231ps %ymm10,%ymm4,%ymm15
  56e5c6:	62 b1 5c 28 59 e2    	vmulps %ymm18,%ymm4,%ymm4
  56e5cc:	62 e1 7c 28 10 52 06 	vmovups 0xc0(%rdx),%ymm18
  56e5d3:	c4 c2 55 b8 e2       	vfmadd231ps %ymm10,%ymm5,%ymm4
  56e5d8:	c5 fc 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm5
  56e5df:	00 
  56e5e0:	62 31 3c 28 59 d2    	vmulps %ymm18,%ymm8,%ymm10
  56e5e6:	c4 62 65 bc d5       	vfnmadd231ps %ymm5,%ymm3,%ymm10
  56e5eb:	62 b1 64 28 59 da    	vmulps %ymm18,%ymm3,%ymm3
  56e5f1:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  56e5f8:	c4 e2 3d b8 dd       	vfmadd231ps %ymm5,%ymm8,%ymm3
  56e5fd:	c5 fc 10 aa e0 01 00 	vmovups 0x1e0(%rdx),%ymm5
  56e604:	00 
  56e605:	62 31 6c 28 59 c2    	vmulps %ymm18,%ymm2,%ymm8
  56e60b:	c4 62 75 bc c5       	vfnmadd231ps %ymm5,%ymm1,%ymm8
  56e610:	62 b1 74 28 59 ca    	vmulps %ymm18,%ymm1,%ymm1
  56e616:	c5 fc c6 c0 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm0
  56e61b:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  56e621:	c4 e2 6d b8 cd       	vfmadd231ps %ymm5,%ymm2,%ymm1
  56e626:	c4 c1 34 58 d3       	vaddps %ymm11,%ymm9,%ymm2
  56e62b:	c4 c1 0c 58 ec       	vaddps %ymm12,%ymm14,%ymm5
  56e630:	c4 41 34 5c cb       	vsubps %ymm11,%ymm9,%ymm9
  56e635:	62 71 74 20 58 df    	vaddps %ymm7,%ymm17,%ymm11
  56e63b:	62 f1 74 20 5c ff    	vsubps %ymm7,%ymm17,%ymm7
  56e641:	62 c1 7c 20 58 cf    	vaddps %ymm15,%ymm16,%ymm17
  56e647:	62 51 7c 20 5c ff    	vsubps %ymm15,%ymm16,%ymm15
  56e64d:	62 e1 4c 28 58 c4    	vaddps %ymm4,%ymm6,%ymm16
  56e653:	c5 cc 5c e4          	vsubps %ymm4,%ymm6,%ymm4
  56e657:	c5 e4 58 f1          	vaddps %ymm1,%ymm3,%ymm6
  56e65b:	c5 e4 5c c9          	vsubps %ymm1,%ymm3,%ymm1
  56e65f:	c4 c1 2c 58 d8       	vaddps %ymm8,%ymm10,%ymm3
  56e664:	c4 41 2c 5c c0       	vsubps %ymm8,%ymm10,%ymm8
  56e669:	c5 14 58 d0          	vaddps %ymm0,%ymm13,%ymm10
  56e66d:	c4 c1 7c 5c c5       	vsubps %ymm13,%ymm0,%ymm0
  56e672:	c5 6c 58 ed          	vaddps %ymm5,%ymm2,%ymm13
  56e676:	c4 41 1c 5c e6       	vsubps %ymm14,%ymm12,%ymm12
  56e67b:	c5 04 58 f4          	vaddps %ymm4,%ymm15,%ymm14
  56e67f:	c4 c1 5c 5c e7       	vsubps %ymm15,%ymm4,%ymm4
  56e684:	c4 41 74 5c f8       	vsubps %ymm8,%ymm1,%ymm15
  56e689:	c5 bc 58 c9          	vaddps %ymm1,%ymm8,%ymm1
  56e68d:	c4 62 7d 18 05 52 dc 	vbroadcastss -0x4f23ae(%rip),%ymm8        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56e694:	b0 ff 
  56e696:	c4 41 0c 59 f0       	vmulps %ymm8,%ymm14,%ymm14
  56e69b:	c4 41 04 59 f8       	vmulps %ymm8,%ymm15,%ymm15
  56e6a0:	c5 bc 59 e4          	vmulps %ymm4,%ymm8,%ymm4
  56e6a4:	c5 bc 59 c9          	vmulps %ymm1,%ymm8,%ymm1
  56e6a8:	62 71 74 20 58 c3    	vaddps %ymm3,%ymm17,%ymm8
  56e6ae:	c5 ec 5c d5          	vsubps %ymm5,%ymm2,%ymm2
  56e6b2:	62 f1 7c 20 58 ee    	vaddps %ymm6,%ymm16,%ymm5
  56e6b8:	62 f1 7c 20 5c f6    	vsubps %ymm6,%ymm16,%ymm6
  56e6be:	62 c1 24 28 58 c2    	vaddps %ymm10,%ymm11,%ymm16
  56e6c4:	c4 41 2c 5c d3       	vsubps %ymm11,%ymm10,%ymm10
  56e6c9:	c4 41 14 58 d8       	vaddps %ymm8,%ymm13,%ymm11
  56e6ce:	62 b1 64 28 5c d9    	vsubps %ymm17,%ymm3,%ymm3
  56e6d4:	62 e1 34 28 58 cf    	vaddps %ymm7,%ymm9,%ymm17
  56e6da:	c5 b4 5c ff          	vsubps %ymm7,%ymm9,%ymm7
  56e6de:	c5 5c 5c c9          	vsubps %ymm1,%ymm4,%ymm9
  56e6e2:	c5 dc 58 c9          	vaddps %ymm1,%ymm4,%ymm1
  56e6e6:	c5 9c 58 e0          	vaddps %ymm0,%ymm12,%ymm4
  56e6ea:	c4 c1 7c 5c c4       	vsubps %ymm12,%ymm0,%ymm0
  56e6ef:	c4 41 0c 58 e7       	vaddps %ymm15,%ymm14,%ymm12
  56e6f4:	c4 41 04 5c f6       	vsubps %ymm14,%ymm15,%ymm14
  56e6f9:	62 71 7c 20 58 fd    	vaddps %ymm5,%ymm16,%ymm15
  56e6ff:	c4 41 14 5c c0       	vsubps %ymm8,%ymm13,%ymm8
  56e704:	62 51 74 20 58 ec    	vaddps %ymm12,%ymm17,%ymm13
  56e70a:	62 f1 7c 20 5c ed    	vsubps %ymm5,%ymm16,%ymm5
  56e710:	62 c1 5c 28 58 c1    	vaddps %ymm9,%ymm4,%ymm16
  56e716:	62 51 74 20 5c e4    	vsubps %ymm12,%ymm17,%ymm12
  56e71c:	62 e1 6c 28 58 ce    	vaddps %ymm6,%ymm2,%ymm17
  56e722:	c4 c1 5c 5c e1       	vsubps %ymm9,%ymm4,%ymm4
  56e727:	c5 2c 58 cb          	vaddps %ymm3,%ymm10,%ymm9
  56e72b:	c5 ec 5c d6          	vsubps %ymm6,%ymm2,%ymm2
  56e72f:	c5 c4 58 f1          	vaddps %ymm1,%ymm7,%ymm6
  56e733:	c5 ac 5c db          	vsubps %ymm3,%ymm10,%ymm3
  56e737:	c5 0c 58 d0          	vaddps %ymm0,%ymm14,%ymm10
  56e73b:	c5 c4 5c c9          	vsubps %ymm1,%ymm7,%ymm1
  56e73f:	c4 c1 7c 5c c6       	vsubps %ymm14,%ymm0,%ymm0
  56e744:	c5 fc 28 3d f4 25 b1 	vmovaps -0x4eda0c(%rip),%ymm7        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  56e74b:	ff 
  56e74c:	c4 43 7d 19 fe 01    	vextractf128 $0x1,%ymm15,%xmm14
  56e752:	62 52 45 28 7f fb    	vpermt2ps %ymm11,%ymm7,%ymm15
  56e758:	c5 7c 11 3e          	vmovups %ymm15,(%rsi)
  56e75c:	c4 43 7d 19 db 01    	vextractf128 $0x1,%ymm11,%xmm11
  56e762:	c4 41 08 14 db       	vunpcklps %xmm11,%xmm14,%xmm11
  56e767:	c5 78 13 5e 20       	vmovlps %xmm11,0x20(%rsi)
  56e76c:	62 c3 7d 28 19 c3 01 	vextractf32x4 $0x1,%ymm16,%xmm11
  56e773:	62 c2 45 28 7f c5    	vpermt2ps %ymm13,%ymm7,%ymm16
  56e779:	62 e1 7c 28 11 86 28 	vmovups %ymm16,0x28(%rsi)
  56e780:	00 00 00 
  56e783:	c4 43 7d 19 ed 01    	vextractf128 $0x1,%ymm13,%xmm13
  56e789:	c4 41 20 14 dd       	vunpcklps %xmm13,%xmm11,%xmm11
  56e78e:	c5 78 13 5e 48       	vmovlps %xmm11,0x48(%rsi)
  56e793:	c4 43 7d 19 cb 01    	vextractf128 $0x1,%ymm9,%xmm11
  56e799:	62 32 45 28 7f c9    	vpermt2ps %ymm17,%ymm7,%ymm9
  56e79f:	c5 7c 11 4e 50       	vmovups %ymm9,0x50(%rsi)
  56e7a4:	62 c3 7d 28 19 c9 01 	vextractf32x4 $0x1,%ymm17,%xmm9
  56e7ab:	c4 41 20 14 c9       	vunpcklps %xmm9,%xmm11,%xmm9
  56e7b0:	c5 78 13 4e 70       	vmovlps %xmm9,0x70(%rsi)
  56e7b5:	c4 43 7d 19 d1 01    	vextractf128 $0x1,%ymm10,%xmm9
  56e7bb:	62 72 45 28 7f d6    	vpermt2ps %ymm6,%ymm7,%ymm10
  56e7c1:	c5 7c 11 56 78       	vmovups %ymm10,0x78(%rsi)
  56e7c6:	c4 e3 7d 19 f6 01    	vextractf128 $0x1,%ymm6,%xmm6
  56e7cc:	c5 b0 14 f6          	vunpcklps %xmm6,%xmm9,%xmm6
  56e7d0:	c5 f8 13 b6 98 00 00 	vmovlps %xmm6,0x98(%rsi)
  56e7d7:	00 
  56e7d8:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  56e7de:	62 d2 45 28 7f e8    	vpermt2ps %ymm8,%ymm7,%ymm5
  56e7e4:	c5 fc 11 ae a0 00 00 	vmovups %ymm5,0xa0(%rsi)
  56e7eb:	00 
  56e7ec:	c4 63 7d 19 c5 01    	vextractf128 $0x1,%ymm8,%xmm5
  56e7f2:	c5 c8 14 ed          	vunpcklps %xmm5,%xmm6,%xmm5
  56e7f6:	c5 f8 13 ae c0 00 00 	vmovlps %xmm5,0xc0(%rsi)
  56e7fd:	00 
  56e7fe:	c4 e3 7d 19 e5 01    	vextractf128 $0x1,%ymm4,%xmm5
  56e804:	62 d2 45 28 7f e4    	vpermt2ps %ymm12,%ymm7,%ymm4
  56e80a:	c5 fc 11 a6 c8 00 00 	vmovups %ymm4,0xc8(%rsi)
  56e811:	00 
  56e812:	c4 63 7d 19 e4 01    	vextractf128 $0x1,%ymm12,%xmm4
  56e818:	c5 d0 14 e4          	vunpcklps %xmm4,%xmm5,%xmm4
  56e81c:	c5 f8 13 a6 e8 00 00 	vmovlps %xmm4,0xe8(%rsi)
  56e823:	00 
  56e824:	c4 e3 7d 19 dc 01    	vextractf128 $0x1,%ymm3,%xmm4
  56e82a:	62 f2 45 28 7f da    	vpermt2ps %ymm2,%ymm7,%ymm3
  56e830:	c5 fc 11 9e f0 00 00 	vmovups %ymm3,0xf0(%rsi)
  56e837:	00 
  56e838:	c4 e3 7d 19 d2 01    	vextractf128 $0x1,%ymm2,%xmm2
  56e83e:	c5 d8 14 d2          	vunpcklps %xmm2,%xmm4,%xmm2
  56e842:	c5 f8 13 96 10 01 00 	vmovlps %xmm2,0x110(%rsi)
  56e849:	00 
  56e84a:	62 f2 7d 28 77 f9    	vpermi2ps %ymm1,%ymm0,%ymm7
  56e850:	c5 fc 11 be 18 01 00 	vmovups %ymm7,0x118(%rsi)
  56e857:	00 
  56e858:	c4 e3 7d 19 c9 01    	vextractf128 $0x1,%ymm1,%xmm1
  56e85e:	c4 e3 7d 19 c0 01    	vextractf128 $0x1,%ymm0,%xmm0
  56e864:	c5 f8 14 c1          	vunpcklps %xmm1,%xmm0,%xmm0
  56e868:	c5 f8 13 86 38 01 00 	vmovlps %xmm0,0x138(%rsi)
  56e86f:	00 
  56e870:	c5 f8 77             	vzeroupper
  56e873:	c3                   	ret
  56e874:	cc                   	int3
  56e875:	cc                   	int3
  56e876:	cc                   	int3
  56e877:	cc                   	int3
  56e878:	cc                   	int3
  56e879:	cc                   	int3
  56e87a:	cc                   	int3
  56e87b:	cc                   	int3
  56e87c:	cc                   	int3
  56e87d:	cc                   	int3
  56e87e:	cc                   	int3
  56e87f:	cc                   	int3


000000000056e880 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56e880:	c5 fc 10 2f          	vmovups (%rdi),%ymm5
  56e884:	c5 7c 10 4f 20       	vmovups 0x20(%rdi),%ymm9
  56e889:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  56e88e:	c5 fc 10 4f 60       	vmovups 0x60(%rdi),%ymm1
  56e893:	c5 fc 10 97 80 00 00 	vmovups 0x80(%rdi),%ymm2
  56e89a:	00 
  56e89b:	c5 fc 10 9f a0 00 00 	vmovups 0xa0(%rdi),%ymm3
  56e8a2:	00 
  56e8a3:	c4 c1 54 c6 e1 88    	vshufps $0x88,%ymm9,%ymm5,%ymm4
  56e8a9:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  56e8af:	c5 fc c6 f1 88       	vshufps $0x88,%ymm1,%ymm0,%ymm6
  56e8b4:	c4 63 fd 01 d6 d8    	vpermpd $0xd8,%ymm6,%ymm10
  56e8ba:	c5 ec c6 f3 88       	vshufps $0x88,%ymm3,%ymm2,%ymm6
  56e8bf:	c4 63 fd 01 e6 d8    	vpermpd $0xd8,%ymm6,%ymm12
  56e8c5:	c4 c1 2c 58 f4       	vaddps %ymm12,%ymm10,%ymm6
  56e8ca:	c5 5c 58 c6          	vaddps %ymm6,%ymm4,%ymm8
  56e8ce:	c4 63 7d 19 c7 01    	vextractf128 $0x1,%ymm8,%xmm7
  56e8d4:	c5 fc c6 c1 dd       	vshufps $0xdd,%ymm1,%ymm0,%ymm0
  56e8d9:	c4 63 fd 01 e8 d8    	vpermpd $0xd8,%ymm0,%ymm13
  56e8df:	c5 ec c6 c3 dd       	vshufps $0xdd,%ymm3,%ymm2,%ymm0
  56e8e4:	c4 63 fd 01 f0 d8    	vpermpd $0xd8,%ymm0,%ymm14
  56e8ea:	c4 c1 14 5c c6       	vsubps %ymm14,%ymm13,%ymm0
  56e8ef:	c4 62 7d 18 3d 6c d8 	vbroadcastss -0x4f2794(%rip),%ymm15        # 7c164 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2874>
  56e8f6:	b0 ff 
  56e8f8:	c5 84 59 c0          	vmulps %ymm0,%ymm15,%ymm0
  56e8fc:	62 e2 7d 28 18 05 1e 	vbroadcastss -0x4f24e2(%rip),%ymm16        # 7c424 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2b34>
  56e903:	db b0 ff 
  56e906:	62 f2 7d 20 ac f4    	vfnmadd213ps %ymm4,%ymm16,%ymm6
  56e90c:	c5 fc 58 d6          	vaddps %ymm6,%ymm0,%ymm2
  56e910:	c4 e3 7d 19 d1 01    	vextractf128 $0x1,%ymm2,%xmm1
  56e916:	c5 c5 15 d9          	vunpckhpd %ymm1,%ymm7,%ymm3
  56e91a:	c5 cc 5c f0          	vsubps %ymm0,%ymm6,%ymm6
  56e91e:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  56e924:	c4 41 20 57 db       	vxorps %xmm11,%xmm11,%xmm11
  56e929:	c4 c1 7d 15 e3       	vunpckhpd %ymm11,%ymm0,%ymm4
  56e92e:	62 e1 64 28 c6 cc dd 	vshufps $0xdd,%ymm4,%ymm3,%ymm17
  56e935:	62 a1 74 20 c6 c9 d8 	vshufps $0xd8,%ymm17,%ymm17,%ymm17
  56e93c:	c5 e4 c6 dc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm3
  56e941:	c5 e4 c6 e3 d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm4
  56e946:	c5 c5 14 d9          	vunpcklpd %ymm1,%ymm7,%ymm3
  56e94a:	c4 c3 7d 0c c3 cc    	vblendps $0xcc,%ymm11,%ymm0,%ymm0
  56e950:	c5 e4 c6 c8 dd       	vshufps $0xdd,%ymm0,%ymm3,%ymm1
  56e955:	c5 f4 c6 c9 d8       	vshufps $0xd8,%ymm1,%ymm1,%ymm1
  56e95a:	c5 e4 c6 c0 88       	vshufps $0x88,%ymm0,%ymm3,%ymm0
  56e95f:	c5 fc c6 f8 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm7
  56e964:	c5 78 29 c0          	vmovaps %xmm8,%xmm0
  56e968:	c5 f8 28 da          	vmovaps %xmm2,%xmm3
  56e96c:	c5 7d 15 c3          	vunpckhpd %ymm3,%ymm0,%ymm8
  56e970:	c5 f8 28 d6          	vmovaps %xmm6,%xmm2
  56e974:	62 f1 6d 20 73 da 08 	vpsrldq $0x8,%ymm2,%ymm18
  56e97b:	62 b1 3c 28 c6 d2 dd 	vshufps $0xdd,%ymm18,%ymm8,%ymm2
  56e982:	c5 ec c6 d2 d8       	vshufps $0xd8,%ymm2,%ymm2,%ymm2
  56e987:	62 31 3c 28 c6 c2 88 	vshufps $0x88,%ymm18,%ymm8,%ymm8
  56e98e:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  56e994:	c5 fd 14 c3          	vunpcklpd %ymm3,%ymm0,%ymm0
  56e998:	c5 fa 7e de          	vmovq  %xmm6,%xmm3
  56e99c:	c5 fc c6 f3 dd       	vshufps $0xdd,%ymm3,%ymm0,%ymm6
  56e9a1:	c5 cc c6 f6 d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm6
  56e9a6:	c5 fc c6 db 88       	vshufps $0x88,%ymm3,%ymm0,%ymm3
  56e9ab:	c4 c1 54 c6 c1 dd    	vshufps $0xdd,%ymm9,%ymm5,%ymm0
  56e9b1:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56e9b7:	c4 c1 14 58 ee       	vaddps %ymm14,%ymm13,%ymm5
  56e9bc:	c5 7c 58 ed          	vaddps %ymm5,%ymm0,%ymm13
  56e9c0:	c4 43 7d 19 e9 01    	vextractf128 $0x1,%ymm13,%xmm9
  56e9c6:	62 e2 55 28 ac c0    	vfnmadd213ps %ymm0,%ymm5,%ymm16
  56e9cc:	c4 c1 2c 5c c4       	vsubps %ymm12,%ymm10,%ymm0
  56e9d1:	c5 84 59 c0          	vmulps %ymm0,%ymm15,%ymm0
  56e9d5:	62 71 7c 20 5c d0    	vsubps %ymm0,%ymm16,%ymm10
  56e9db:	c4 43 7d 19 d6 01    	vextractf128 $0x1,%ymm10,%xmm14
  56e9e1:	c4 41 35 15 e6       	vunpckhpd %ymm14,%ymm9,%ymm12
  56e9e6:	62 f1 7c 20 58 c0    	vaddps %ymm0,%ymm16,%ymm0
  56e9ec:	c4 c3 7d 19 c7 01    	vextractf128 $0x1,%ymm0,%xmm15
  56e9f2:	62 c1 85 28 15 c3    	vunpckhpd %ymm11,%ymm15,%ymm16
  56e9f8:	62 b1 1c 28 c6 e8 dd 	vshufps $0xdd,%ymm16,%ymm12,%ymm5
  56e9ff:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  56ea04:	62 31 1c 28 c6 e0 88 	vshufps $0x88,%ymm16,%ymm12,%ymm12
  56ea0b:	c4 41 1c c6 e4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm12
  56ea11:	c4 41 35 14 f6       	vunpcklpd %ymm14,%ymm9,%ymm14
  56ea16:	c4 43 05 0c db cc    	vblendps $0xcc,%ymm11,%ymm15,%ymm11
  56ea1c:	c4 41 0c c6 cb dd    	vshufps $0xdd,%ymm11,%ymm14,%ymm9
  56ea22:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  56ea28:	c4 41 0c c6 db 88    	vshufps $0x88,%ymm11,%ymm14,%ymm11
  56ea2e:	c4 41 24 c6 fb d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm15
  56ea34:	c4 41 78 28 dd       	vmovaps %xmm13,%xmm11
  56ea39:	c4 41 78 28 ea       	vmovaps %xmm10,%xmm13
  56ea3e:	c4 41 25 15 f5       	vunpckhpd %ymm13,%ymm11,%ymm14
  56ea43:	c5 78 28 d0          	vmovaps %xmm0,%xmm10
  56ea47:	62 d1 7d 20 73 da 08 	vpsrldq $0x8,%ymm10,%ymm16
  56ea4e:	62 31 0c 28 c6 d0 dd 	vshufps $0xdd,%ymm16,%ymm14,%ymm10
  56ea55:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  56ea5b:	62 31 0c 28 c6 f0 88 	vshufps $0x88,%ymm16,%ymm14,%ymm14
  56ea62:	62 c1 0c 28 c6 c6 d8 	vshufps $0xd8,%ymm14,%ymm14,%ymm16
  56ea69:	c4 41 25 14 dd       	vunpcklpd %ymm13,%ymm11,%ymm11
  56ea6e:	c5 fa 7e c0          	vmovq  %xmm0,%xmm0
  56ea72:	c5 24 c6 e8 dd       	vshufps $0xdd,%ymm0,%ymm11,%ymm13
  56ea77:	c4 41 14 c6 f5 d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm14
  56ea7d:	c5 24 c6 d8 88       	vshufps $0x88,%ymm0,%ymm11,%ymm11
  56ea82:	c5 fc 10 82 00 01 00 	vmovups 0x100(%rdx),%ymm0
  56ea89:	00 
  56ea8a:	62 e1 7c 28 10 52 09 	vmovups 0x120(%rdx),%ymm18
  56ea91:	c5 04 59 e8          	vmulps %ymm0,%ymm15,%ymm13
  56ea95:	62 32 45 28 bc ea    	vfnmadd231ps %ymm18,%ymm7,%ymm13
  56ea9b:	c5 c4 59 f8          	vmulps %ymm0,%ymm7,%ymm7
  56ea9f:	c5 fc 10 82 80 00 00 	vmovups 0x80(%rdx),%ymm0
  56eaa6:	00 
  56eaa7:	62 b2 05 28 b8 fa    	vfmadd231ps %ymm18,%ymm15,%ymm7
  56eaad:	62 e1 7c 28 10 52 05 	vmovups 0xa0(%rdx),%ymm18
  56eab4:	62 71 7c 20 59 f8    	vmulps %ymm0,%ymm16,%ymm15
  56eaba:	62 32 3d 28 bc fa    	vfnmadd231ps %ymm18,%ymm8,%ymm15
  56eac0:	c5 bc 59 c0          	vmulps %ymm0,%ymm8,%ymm0
  56eac4:	c5 7c 10 82 80 01 00 	vmovups 0x180(%rdx),%ymm8
  56eacb:	00 
  56eacc:	62 b2 7d 20 b8 c2    	vfmadd231ps %ymm18,%ymm16,%ymm0
  56ead2:	62 e1 7c 28 10 42 0d 	vmovups 0x1a0(%rdx),%ymm16
  56ead9:	62 c1 1c 28 59 d0    	vmulps %ymm8,%ymm12,%ymm18
  56eadf:	62 a2 5d 28 bc d0    	vfnmadd231ps %ymm16,%ymm4,%ymm18
  56eae5:	c5 bc 59 e4          	vmulps %ymm4,%ymm8,%ymm4
  56eae9:	c5 7c 10 42 40       	vmovups 0x40(%rdx),%ymm8
  56eaee:	62 b2 1d 28 b8 e0    	vfmadd231ps %ymm16,%ymm12,%ymm4
  56eaf4:	c5 7c 10 62 60       	vmovups 0x60(%rdx),%ymm12
  56eaf9:	62 c1 0c 28 59 c0    	vmulps %ymm8,%ymm14,%ymm16
  56eaff:	62 c2 4d 28 bc c4    	vfnmadd231ps %ymm12,%ymm6,%ymm16
  56eb05:	c5 bc 59 f6          	vmulps %ymm6,%ymm8,%ymm6
  56eb09:	c5 7c 10 82 40 01 00 	vmovups 0x140(%rdx),%ymm8
  56eb10:	00 
  56eb11:	c4 c2 0d b8 f4       	vfmadd231ps %ymm12,%ymm14,%ymm6
  56eb16:	c5 7c 10 a2 60 01 00 	vmovups 0x160(%rdx),%ymm12
  56eb1d:	00 
  56eb1e:	c4 41 34 59 f0       	vmulps %ymm8,%ymm9,%ymm14
  56eb23:	c4 42 75 bc f4       	vfnmadd231ps %ymm12,%ymm1,%ymm14
  56eb28:	c5 bc 59 c9          	vmulps %ymm1,%ymm8,%ymm1
  56eb2c:	c5 7c 10 82 c0 00 00 	vmovups 0xc0(%rdx),%ymm8
  56eb33:	00 
  56eb34:	c4 c2 35 b8 cc       	vfmadd231ps %ymm12,%ymm9,%ymm1
  56eb39:	c5 7c 10 8a e0 00 00 	vmovups 0xe0(%rdx),%ymm9
  56eb40:	00 
  56eb41:	c4 41 2c 59 e0       	vmulps %ymm8,%ymm10,%ymm12
  56eb46:	c4 42 6d bc e1       	vfnmadd231ps %ymm9,%ymm2,%ymm12
  56eb4b:	c5 bc 59 d2          	vmulps %ymm2,%ymm8,%ymm2
  56eb4f:	c5 7c 10 82 c0 01 00 	vmovups 0x1c0(%rdx),%ymm8
  56eb56:	00 
  56eb57:	c4 c2 2d b8 d1       	vfmadd231ps %ymm9,%ymm10,%ymm2
  56eb5c:	c5 7c 10 8a e0 01 00 	vmovups 0x1e0(%rdx),%ymm9
  56eb63:	00 
  56eb64:	c5 3c 59 d5          	vmulps %ymm5,%ymm8,%ymm10
  56eb68:	62 52 75 20 bc d1    	vfnmadd231ps %ymm9,%ymm17,%ymm10
  56eb6e:	62 51 74 20 59 c0    	vmulps %ymm8,%ymm17,%ymm8
  56eb74:	c5 e4 c6 db d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm3
  56eb79:	c4 41 24 c6 db d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm11
  56eb7f:	c4 42 55 b8 c1       	vfmadd231ps %ymm9,%ymm5,%ymm8
  56eb84:	c4 c1 24 58 ed       	vaddps %ymm13,%ymm11,%ymm5
  56eb89:	62 31 04 28 58 ca    	vaddps %ymm18,%ymm15,%ymm9
  56eb8f:	c4 41 24 5c dd       	vsubps %ymm13,%ymm11,%ymm11
  56eb94:	c5 7c 58 ec          	vaddps %ymm4,%ymm0,%ymm13
  56eb98:	c5 fc 5c e4          	vsubps %ymm4,%ymm0,%ymm4
  56eb9c:	62 c1 7c 20 58 ce    	vaddps %ymm14,%ymm16,%ymm17
  56eba2:	62 d1 7c 20 5c c6    	vsubps %ymm14,%ymm16,%ymm0
  56eba8:	c5 4c 58 f1          	vaddps %ymm1,%ymm6,%ymm14
  56ebac:	c5 cc 5c c9          	vsubps %ymm1,%ymm6,%ymm1
  56ebb0:	c5 bc 58 f2          	vaddps %ymm2,%ymm8,%ymm6
  56ebb4:	c4 c1 6c 5c d0       	vsubps %ymm8,%ymm2,%ymm2
  56ebb9:	c4 41 1c 58 c2       	vaddps %ymm10,%ymm12,%ymm8
  56ebbe:	c4 41 1c 5c d2       	vsubps %ymm10,%ymm12,%ymm10
  56ebc3:	c5 44 58 e3          	vaddps %ymm3,%ymm7,%ymm12
  56ebc7:	c5 e4 5c df          	vsubps %ymm7,%ymm3,%ymm3
  56ebcb:	c5 b4 58 fd          	vaddps %ymm5,%ymm9,%ymm7
  56ebcf:	62 51 6c 20 5c ff    	vsubps %ymm15,%ymm18,%ymm15
  56ebd5:	62 e1 7c 28 58 c1    	vaddps %ymm1,%ymm0,%ymm16
  56ebdb:	c5 f4 5c c0          	vsubps %ymm0,%ymm1,%ymm0
  56ebdf:	c4 c1 6c 5c ca       	vsubps %ymm10,%ymm2,%ymm1
  56ebe4:	c5 ac 58 d2          	vaddps %ymm2,%ymm10,%ymm2
  56ebe8:	c4 62 7d 18 15 f7 d6 	vbroadcastss -0x4f2909(%rip),%ymm10        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56ebef:	b0 ff 
  56ebf1:	62 c1 7c 20 59 c2    	vmulps %ymm10,%ymm16,%ymm16
  56ebf7:	62 c1 74 28 59 d2    	vmulps %ymm10,%ymm1,%ymm18
  56ebfd:	c5 ac 59 c8          	vmulps %ymm0,%ymm10,%ymm1
  56ec01:	c5 2c 59 d2          	vmulps %ymm2,%ymm10,%ymm10
  56ec05:	62 c1 74 20 58 d8    	vaddps %ymm8,%ymm17,%ymm19
  56ec0b:	c4 c1 54 5c e9       	vsubps %ymm9,%ymm5,%ymm5
  56ec10:	c5 0c 58 ce          	vaddps %ymm6,%ymm14,%ymm9
  56ec14:	c5 8c 5c f6          	vsubps %ymm6,%ymm14,%ymm6
  56ec18:	c4 41 14 58 f4       	vaddps %ymm12,%ymm13,%ymm14
  56ec1d:	c4 c1 1c 5c c5       	vsubps %ymm13,%ymm12,%ymm0
  56ec22:	62 31 44 28 58 e3    	vaddps %ymm19,%ymm7,%ymm12
  56ec28:	62 b1 3c 28 5c d1    	vsubps %ymm17,%ymm8,%ymm2
  56ec2e:	c5 24 58 c4          	vaddps %ymm4,%ymm11,%ymm8
  56ec32:	c5 a4 5c e4          	vsubps %ymm4,%ymm11,%ymm4
  56ec36:	c4 41 74 5c da       	vsubps %ymm10,%ymm1,%ymm11
  56ec3b:	c5 2c 58 d1          	vaddps %ymm1,%ymm10,%ymm10
  56ec3f:	c5 04 58 eb          	vaddps %ymm3,%ymm15,%ymm13
  56ec43:	c4 c1 64 5c cf       	vsubps %ymm15,%ymm3,%ymm1
  56ec48:	62 31 7c 20 58 fa    	vaddps %ymm18,%ymm16,%ymm15
  56ec4e:	62 b1 6c 20 5c d8    	vsubps %ymm16,%ymm18,%ymm3
  56ec54:	62 c1 3c 28 58 c7    	vaddps %ymm15,%ymm8,%ymm16
  56ec5a:	62 b1 44 28 5c fb    	vsubps %ymm19,%ymm7,%ymm7
  56ec60:	62 e1 54 28 58 ce    	vaddps %ymm6,%ymm5,%ymm17
  56ec66:	c4 41 3c 5c c7       	vsubps %ymm15,%ymm8,%ymm8
  56ec6b:	c5 2c 58 fc          	vaddps %ymm4,%ymm10,%ymm15
  56ec6f:	c5 d4 5c f6          	vsubps %ymm6,%ymm5,%ymm6
  56ec73:	c4 c1 5c 5c e2       	vsubps %ymm10,%ymm4,%ymm4
  56ec78:	c4 c1 08 58 e9       	vaddps %xmm9,%xmm14,%xmm5
  56ec7d:	c5 7c 28 15 5b 3a b1 	vmovaps -0x4ec5a5(%rip),%ymm10        # 826e0 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x8df0>
  56ec84:	ff 
  56ec85:	62 d2 2d 28 7f ec    	vpermt2ps %ymm12,%ymm10,%ymm5
  56ec8b:	c4 41 10 58 e3       	vaddps %xmm11,%xmm13,%xmm12
  56ec90:	62 32 2d 28 7f e0    	vpermt2ps %ymm16,%ymm10,%ymm12
  56ec96:	62 e1 7c 08 58 c2    	vaddps %xmm2,%xmm0,%xmm16
  56ec9c:	62 a2 2d 28 7f c1    	vpermt2ps %ymm17,%ymm10,%ymm16
  56eca2:	62 e1 74 08 58 cb    	vaddps %xmm3,%xmm1,%xmm17
  56eca8:	62 c2 2d 28 7f cf    	vpermt2ps %ymm15,%ymm10,%ymm17
  56ecae:	c4 41 08 5c c9       	vsubps %xmm9,%xmm14,%xmm9
  56ecb3:	62 72 2d 28 7f cf    	vpermt2ps %ymm7,%ymm10,%ymm9
  56ecb9:	c4 c1 10 5c fb       	vsubps %xmm11,%xmm13,%xmm7
  56ecbe:	62 d2 2d 28 7f f8    	vpermt2ps %ymm8,%ymm10,%ymm7
  56ecc4:	c5 f8 5c c2          	vsubps %xmm2,%xmm0,%xmm0
  56ecc8:	62 f2 2d 28 7f c6    	vpermt2ps %ymm6,%ymm10,%ymm0
  56ecce:	c5 f0 5c cb          	vsubps %xmm3,%xmm1,%xmm1
  56ecd2:	62 f2 2d 28 7f cc    	vpermt2ps %ymm4,%ymm10,%ymm1
  56ecd8:	c4 e3 7d 19 ea 01    	vextractf128 $0x1,%ymm5,%xmm2
  56ecde:	c5 f8 13 56 10       	vmovlps %xmm2,0x10(%rsi)
  56ece3:	c5 f8 11 2e          	vmovups %xmm5,(%rsi)
  56ece7:	c4 63 7d 19 e2 01    	vextractf128 $0x1,%ymm12,%xmm2
  56eced:	c5 f8 13 56 28       	vmovlps %xmm2,0x28(%rsi)
  56ecf2:	c5 78 11 66 18       	vmovups %xmm12,0x18(%rsi)
  56ecf7:	62 e3 7d 28 19 c2 01 	vextractf32x4 $0x1,%ymm16,%xmm2
  56ecfe:	c5 f8 13 56 40       	vmovlps %xmm2,0x40(%rsi)
  56ed03:	62 e1 7c 08 11 46 03 	vmovups %xmm16,0x30(%rsi)
  56ed0a:	62 e3 7d 28 19 ca 01 	vextractf32x4 $0x1,%ymm17,%xmm2
  56ed11:	c5 f8 13 56 58       	vmovlps %xmm2,0x58(%rsi)
  56ed16:	62 e1 7c 08 11 8e 48 	vmovups %xmm17,0x48(%rsi)
  56ed1d:	00 00 00 
  56ed20:	c4 63 7d 19 ca 01    	vextractf128 $0x1,%ymm9,%xmm2
  56ed26:	c5 f8 13 56 70       	vmovlps %xmm2,0x70(%rsi)
  56ed2b:	c5 78 11 4e 60       	vmovups %xmm9,0x60(%rsi)
  56ed30:	c4 e3 7d 19 fa 01    	vextractf128 $0x1,%ymm7,%xmm2
  56ed36:	c5 f8 13 96 88 00 00 	vmovlps %xmm2,0x88(%rsi)
  56ed3d:	00 
  56ed3e:	c5 f8 11 7e 78       	vmovups %xmm7,0x78(%rsi)
  56ed43:	c4 e3 7d 19 c2 01    	vextractf128 $0x1,%ymm0,%xmm2
  56ed49:	c5 f8 13 96 a0 00 00 	vmovlps %xmm2,0xa0(%rsi)
  56ed50:	00 
  56ed51:	c5 f8 11 86 90 00 00 	vmovups %xmm0,0x90(%rsi)
  56ed58:	00 
  56ed59:	c4 e3 7d 19 c8 01    	vextractf128 $0x1,%ymm1,%xmm0
  56ed5f:	c5 f8 13 86 b8 00 00 	vmovlps %xmm0,0xb8(%rsi)
  56ed66:	00 
  56ed67:	c5 f8 11 8e a8 00 00 	vmovups %xmm1,0xa8(%rsi)
  56ed6e:	00 
  56ed6f:	c5 f8 77             	vzeroupper
  56ed72:	c3                   	ret
  56ed73:	cc                   	int3
  56ed74:	cc                   	int3
  56ed75:	cc                   	int3
  56ed76:	cc                   	int3
  56ed77:	cc                   	int3
  56ed78:	cc                   	int3
  56ed79:	cc                   	int3
  56ed7a:	cc                   	int3
  56ed7b:	cc                   	int3
  56ed7c:	cc                   	int3
  56ed7d:	cc                   	int3
  56ed7e:	cc                   	int3
  56ed7f:	cc                   	int3


000000000056ed80 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56ed80:	c5 7c 10 17          	vmovups (%rdi),%ymm10
  56ed84:	c5 7c 10 5f 20       	vmovups 0x20(%rdi),%ymm11
  56ed89:	c5 fc 10 67 40       	vmovups 0x40(%rdi),%ymm4
  56ed8e:	c5 fc 10 77 60       	vmovups 0x60(%rdi),%ymm6
  56ed93:	c5 7c 10 87 80 00 00 	vmovups 0x80(%rdi),%ymm8
  56ed9a:	00 
  56ed9b:	c5 7c 10 8f a0 00 00 	vmovups 0xa0(%rdi),%ymm9
  56eda2:	00 
  56eda3:	c5 7c 10 a7 c0 00 00 	vmovups 0xc0(%rdi),%ymm12
  56edaa:	00 
  56edab:	c5 7c 10 af e0 00 00 	vmovups 0xe0(%rdi),%ymm13
  56edb2:	00 
  56edb3:	62 e1 7c 28 10 4f 08 	vmovups 0x100(%rdi),%ymm17
  56edba:	62 e1 7c 28 10 67 09 	vmovups 0x120(%rdi),%ymm20
  56edc1:	62 e1 7c 28 10 6f 0a 	vmovups 0x140(%rdi),%ymm21
  56edc8:	62 e1 7c 28 10 77 0b 	vmovups 0x160(%rdi),%ymm22
  56edcf:	62 61 7c 28 10 47 0c 	vmovups 0x180(%rdi),%ymm24
  56edd6:	62 61 7c 28 10 4f 0d 	vmovups 0x1a0(%rdi),%ymm25
  56eddd:	c4 c1 2c c6 c3 88    	vshufps $0x88,%ymm11,%ymm10,%ymm0
  56ede3:	62 e3 fd 28 01 c0 d8 	vpermpd $0xd8,%ymm0,%ymm16
  56edea:	c5 dc c6 c6 88       	vshufps $0x88,%ymm6,%ymm4,%ymm0
  56edef:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56edf5:	c5 fc 11 44 24 b8    	vmovups %ymm0,-0x48(%rsp)
  56edfb:	62 91 3c 20 c6 c9 88 	vshufps $0x88,%ymm25,%ymm24,%ymm1
  56ee02:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  56ee08:	c5 fc 11 4c 24 d8    	vmovups %ymm1,-0x28(%rsp)
  56ee0e:	c5 7c 58 f1          	vaddps %ymm1,%ymm0,%ymm14
  56ee12:	62 d1 7c 20 58 ee    	vaddps %ymm14,%ymm16,%ymm5
  56ee18:	c4 c1 3c c6 d1 88    	vshufps $0x88,%ymm9,%ymm8,%ymm2
  56ee1e:	c4 e3 fd 01 d2 d8    	vpermpd $0xd8,%ymm2,%ymm2
  56ee24:	62 b1 54 20 c6 de 88 	vshufps $0x88,%ymm22,%ymm21,%ymm3
  56ee2b:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  56ee31:	62 e1 6c 28 58 d3    	vaddps %ymm3,%ymm2,%ymm18
  56ee37:	62 31 54 28 58 fa    	vaddps %ymm18,%ymm5,%ymm15
  56ee3d:	c4 c1 1c c6 ed 88    	vshufps $0x88,%ymm13,%ymm12,%ymm5
  56ee43:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  56ee49:	62 b1 74 20 c6 fc 88 	vshufps $0x88,%ymm20,%ymm17,%ymm7
  56ee50:	c4 e3 fd 01 ff d8    	vpermpd $0xd8,%ymm7,%ymm7
  56ee56:	62 e1 54 28 58 df    	vaddps %ymm7,%ymm5,%ymm19
  56ee5c:	62 a1 04 28 58 fb    	vaddps %ymm19,%ymm15,%ymm23
  56ee62:	c4 41 1c c6 e5 dd    	vshufps $0xdd,%ymm13,%ymm12,%ymm12
  56ee68:	c4 43 fd 01 fc d8    	vpermpd $0xd8,%ymm12,%ymm15
  56ee6e:	62 31 74 20 c6 e4 dd 	vshufps $0xdd,%ymm20,%ymm17,%ymm12
  56ee75:	62 c3 fd 28 01 cc d8 	vpermpd $0xd8,%ymm12,%ymm17
  56ee7c:	62 21 04 28 5c d1    	vsubps %ymm17,%ymm15,%ymm26
  56ee82:	c4 41 3c c6 c1 dd    	vshufps $0xdd,%ymm9,%ymm8,%ymm8
  56ee88:	62 c3 fd 28 01 e0 d8 	vpermpd $0xd8,%ymm8,%ymm20
  56ee8f:	62 31 54 20 c6 c6 dd 	vshufps $0xdd,%ymm22,%ymm21,%ymm8
  56ee96:	62 c3 fd 28 01 e8 d8 	vpermpd $0xd8,%ymm8,%ymm21
  56ee9d:	62 21 5c 20 5c dd    	vsubps %ymm21,%ymm20,%ymm27
  56eea3:	c5 dc c6 e6 dd       	vshufps $0xdd,%ymm6,%ymm4,%ymm4
  56eea8:	62 e3 fd 28 01 f4 d8 	vpermpd $0xd8,%ymm4,%ymm22
  56eeaf:	62 91 3c 20 c6 e1 dd 	vshufps $0xdd,%ymm25,%ymm24,%ymm4
  56eeb6:	62 63 fd 28 01 c4 d8 	vpermpd $0xd8,%ymm4,%ymm24
  56eebd:	62 01 4c 20 5c c8    	vsubps %ymm24,%ymm22,%ymm25
  56eec3:	c4 e2 7d 18 25 fc d7 	vbroadcastss -0x4f2804(%rip),%ymm4        # 7c6c8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2dd8>
  56eeca:	b0 ff 
  56eecc:	62 61 34 20 59 e4    	vmulps %ymm4,%ymm25,%ymm28
  56eed2:	c4 e2 7d 18 35 a9 d8 	vbroadcastss -0x4f2757(%rip),%ymm6        # 7c784 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2e94>
  56eed9:	b0 ff 
  56eedb:	c4 62 7d 18 0d 80 d5 	vbroadcastss -0x4f2a80(%rip),%ymm9        # 7c464 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2b74>
  56eee2:	b0 ff 
  56eee4:	62 62 25 20 bc e6    	vfnmadd231ps %ymm6,%ymm27,%ymm28
  56eeea:	62 42 2d 20 b8 e1    	vfmadd231ps %ymm9,%ymm26,%ymm28
  56eef0:	c4 62 7d 18 25 bf d7 	vbroadcastss -0x4f2841(%rip),%ymm12        # 7c6b8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2dc8>
  56eef7:	b0 ff 
  56eef9:	62 41 7c 28 28 ec    	vmovaps %ymm12,%ymm29
  56eeff:	62 22 0d 28 ac e8    	vfnmadd213ps %ymm16,%ymm14,%ymm29
  56ef05:	c4 62 7d 18 05 c6 d7 	vbroadcastss -0x4f283a(%rip),%ymm8        # 7c6d4 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2de4>
  56ef0c:	b0 ff 
  56ef0e:	62 42 6d 20 b8 e8    	vfmadd231ps %ymm8,%ymm18,%ymm29
  56ef14:	c4 62 7d 18 2d 27 d2 	vbroadcastss -0x4f2dd9(%rip),%ymm13        # 7c144 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2854>
  56ef1b:	b0 ff 
  56ef1d:	62 42 65 20 bc ed    	vfnmadd231ps %ymm13,%ymm19,%ymm29
  56ef23:	62 01 1c 20 58 f5    	vaddps %ymm29,%ymm28,%ymm30
  56ef29:	62 41 34 20 59 f9    	vmulps %ymm9,%ymm25,%ymm31
  56ef2f:	62 62 25 20 bc fc    	vfnmadd231ps %ymm4,%ymm27,%ymm31
  56ef35:	62 41 24 20 59 d9    	vmulps %ymm9,%ymm27,%ymm27
  56ef3b:	62 02 4d 28 b8 d9    	vfmadd231ps %ymm25,%ymm6,%ymm27
  56ef41:	62 03 c5 20 23 ce 03 	vshuff64x2 $0x3,%ymm30,%ymm23,%ymm25
  56ef48:	62 62 2d 20 bc fe    	vfnmadd231ps %ymm6,%ymm26,%ymm31
  56ef4e:	62 02 5d 28 b8 da    	vfmadd231ps %ymm26,%ymm4,%ymm27
  56ef54:	62 41 7c 28 28 d5    	vmovaps %ymm13,%ymm26
  56ef5a:	62 22 0d 28 ac d0    	vfnmadd213ps %ymm16,%ymm14,%ymm26
  56ef60:	62 42 6d 20 bc d4    	vfnmadd231ps %ymm12,%ymm18,%ymm26
  56ef66:	62 42 65 20 b8 d0    	vfmadd231ps %ymm8,%ymm19,%ymm26
  56ef6c:	62 32 3d 28 a8 f0    	vfmadd213ps %ymm16,%ymm8,%ymm14
  56ef72:	62 81 2c 20 5c c7    	vsubps %ymm31,%ymm26,%ymm16
  56ef78:	62 32 15 28 bc f2    	vfnmadd231ps %ymm18,%ymm13,%ymm14
  56ef7e:	62 32 1d 28 bc f3    	vfnmadd231ps %ymm19,%ymm12,%ymm14
  56ef84:	62 c1 24 20 58 d6    	vaddps %ymm14,%ymm27,%ymm18
  56ef8a:	62 a3 fd 20 23 da 03 	vshuff64x2 $0x3,%ymm18,%ymm16,%ymm19
  56ef91:	62 01 0c 28 5c db    	vsubps %ymm27,%ymm14,%ymm27
  56ef97:	62 31 b5 20 15 f3    	vunpckhpd %ymm19,%ymm25,%ymm14
  56ef9d:	62 01 04 20 58 d2    	vaddps %ymm26,%ymm31,%ymm26
  56efa3:	62 93 a5 20 23 ca 03 	vshuff64x2 $0x3,%ymm26,%ymm27,%ymm1
  56efaa:	62 01 14 20 5c e4    	vsubps %ymm28,%ymm29,%ymm28
  56efb0:	62 03 7d 28 19 e5 01 	vextractf32x4 $0x1,%ymm28,%xmm29
  56efb7:	62 91 f5 28 15 c5    	vunpckhpd %ymm29,%ymm1,%ymm0
  56efbd:	62 61 0c 28 c6 f8 dd 	vshufps $0xdd,%ymm0,%ymm14,%ymm31
  56efc4:	c5 0c c6 f0 88       	vshufps $0x88,%ymm0,%ymm14,%ymm14
  56efc9:	62 b1 b5 20 14 c3    	vunpcklpd %ymm19,%ymm25,%ymm0
  56efcf:	62 91 f5 28 14 cd    	vunpcklpd %ymm29,%ymm1,%ymm1
  56efd5:	62 61 7c 28 c6 e9 dd 	vshufps $0xdd,%ymm1,%ymm0,%ymm29
  56efdc:	62 e1 7c 28 c6 d9 88 	vshufps $0x88,%ymm1,%ymm0,%ymm19
  56efe3:	62 93 45 20 18 c6 01 	vinsertf32x4 $0x1,%xmm30,%ymm23,%ymm0
  56efea:	62 b3 7d 20 18 ca 01 	vinsertf32x4 $0x1,%xmm18,%ymm16,%ymm1
  56eff1:	62 e1 fd 28 15 c1    	vunpckhpd %ymm1,%ymm0,%ymm16
  56eff7:	62 83 25 20 18 d2 01 	vinsertf32x4 $0x1,%xmm26,%ymm27,%ymm18
  56effe:	62 01 7c 08 28 d4    	vmovaps %xmm28,%xmm26
  56f004:	62 01 ed 20 15 ca    	vunpckhpd %ymm26,%ymm18,%ymm25
  56f00a:	62 81 7c 20 c6 f9 dd 	vshufps $0xdd,%ymm25,%ymm16,%ymm23
  56f011:	62 01 7c 20 c6 c9 88 	vshufps $0x88,%ymm25,%ymm16,%ymm25
  56f018:	c5 fd 14 c1          	vunpcklpd %ymm1,%ymm0,%ymm0
  56f01c:	62 91 ed 20 14 ca    	vunpcklpd %ymm26,%ymm18,%ymm1
  56f022:	62 61 7c 28 c6 d1 dd 	vshufps $0xdd,%ymm1,%ymm0,%ymm26
  56f029:	62 61 7c 28 c6 d9 88 	vshufps $0x88,%ymm1,%ymm0,%ymm27
  56f030:	c4 c1 2c c6 c3 dd    	vshufps $0xdd,%ymm11,%ymm10,%ymm0
  56f036:	62 91 4c 20 58 c8    	vaddps %ymm24,%ymm22,%ymm1
  56f03c:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56f042:	62 31 5c 20 58 d5    	vaddps %ymm21,%ymm20,%ymm10
  56f048:	62 31 04 28 58 d9    	vaddps %ymm17,%ymm15,%ymm11
  56f04e:	c4 41 7c 28 fc       	vmovaps %ymm12,%ymm15
  56f053:	c4 62 75 ac f8       	vfnmadd213ps %ymm0,%ymm1,%ymm15
  56f058:	c4 42 2d b8 f8       	vfmadd231ps %ymm8,%ymm10,%ymm15
  56f05d:	62 c1 7c 28 28 c5    	vmovaps %ymm13,%ymm16
  56f063:	62 e2 75 28 ac c0    	vfnmadd213ps %ymm0,%ymm1,%ymm16
  56f069:	62 c2 2d 28 bc c4    	vfnmadd231ps %ymm12,%ymm10,%ymm16
  56f06f:	62 c2 25 28 b8 c0    	vfmadd231ps %ymm8,%ymm11,%ymm16
  56f075:	c4 62 75 a8 c0       	vfmadd213ps %ymm0,%ymm1,%ymm8
  56f07a:	c5 fc 58 c1          	vaddps %ymm1,%ymm0,%ymm0
  56f07e:	c5 d4 5c cf          	vsubps %ymm7,%ymm5,%ymm1
  56f082:	c5 ec 5c d3          	vsubps %ymm3,%ymm2,%ymm2
  56f086:	c5 fc 10 5c 24 b8    	vmovups -0x48(%rsp),%ymm3
  56f08c:	c5 e4 5c 5c 24 d8    	vsubps -0x28(%rsp),%ymm3,%ymm3
  56f092:	c5 ac 58 c0          	vaddps %ymm0,%ymm10,%ymm0
  56f096:	62 c1 7c 28 58 cb    	vaddps %ymm11,%ymm0,%ymm17
  56f09c:	c4 42 25 bc fd       	vfnmadd231ps %ymm13,%ymm11,%ymm15
  56f0a1:	c4 42 2d bc c5       	vfnmadd231ps %ymm13,%ymm10,%ymm8
  56f0a6:	c5 e4 59 c4          	vmulps %ymm4,%ymm3,%ymm0
  56f0aa:	c4 e2 6d bc c6       	vfnmadd231ps %ymm6,%ymm2,%ymm0
  56f0af:	c4 c2 75 b8 c1       	vfmadd231ps %ymm9,%ymm1,%ymm0
  56f0b4:	62 e1 04 28 5c d0    	vsubps %ymm0,%ymm15,%ymm18
  56f0ba:	c4 42 25 bc c4       	vfnmadd231ps %ymm12,%ymm11,%ymm8
  56f0bf:	62 b3 f5 20 23 ea 03 	vshuff64x2 $0x3,%ymm18,%ymm17,%ymm5
  56f0c6:	c5 b4 59 fb          	vmulps %ymm3,%ymm9,%ymm7
  56f0ca:	c4 e2 6d bc fc       	vfnmadd231ps %ymm4,%ymm2,%ymm7
  56f0cf:	c4 e2 75 bc fe       	vfnmadd231ps %ymm6,%ymm1,%ymm7
  56f0d4:	c5 b4 59 d2          	vmulps %ymm2,%ymm9,%ymm2
  56f0d8:	62 71 7c 20 58 df    	vaddps %ymm7,%ymm16,%ymm11
  56f0de:	c4 e2 65 b8 d6       	vfmadd231ps %ymm6,%ymm3,%ymm2
  56f0e3:	c4 e2 75 b8 d4       	vfmadd231ps %ymm4,%ymm1,%ymm2
  56f0e8:	c5 bc 5c f2          	vsubps %ymm2,%ymm8,%ymm6
  56f0ec:	c4 e3 25 06 ce 31    	vperm2f128 $0x31,%ymm6,%ymm11,%ymm1
  56f0f2:	c5 d5 15 d9          	vunpckhpd %ymm1,%ymm5,%ymm3
  56f0f6:	c5 3c 58 c2          	vaddps %ymm2,%ymm8,%ymm8
  56f0fa:	62 e1 7c 20 5c c7    	vsubps %ymm7,%ymm16,%ymm16
  56f100:	62 b3 bd 28 23 d0 03 	vshuff64x2 $0x3,%ymm16,%ymm8,%ymm2
  56f107:	62 e1 04 28 58 e0    	vaddps %ymm0,%ymm15,%ymm20
  56f10d:	62 e3 7d 28 19 e0 01 	vextractf32x4 $0x1,%ymm20,%xmm0
  56f114:	c5 ed 15 e0          	vunpckhpd %ymm0,%ymm2,%ymm4
  56f118:	c5 64 c6 d4 dd       	vshufps $0xdd,%ymm4,%ymm3,%ymm10
  56f11d:	c5 64 c6 fc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm15
  56f122:	c5 d5 14 c9          	vunpcklpd %ymm1,%ymm5,%ymm1
  56f126:	c5 ed 14 c0          	vunpcklpd %ymm0,%ymm2,%ymm0
  56f12a:	c5 f4 c6 e8 dd       	vshufps $0xdd,%ymm0,%ymm1,%ymm5
  56f12f:	62 e1 74 28 c6 e8 88 	vshufps $0x88,%ymm0,%ymm1,%ymm21
  56f136:	62 91 04 20 c6 cf d8 	vshufps $0xd8,%ymm31,%ymm31,%ymm1
  56f13d:	c4 41 0c c6 ce d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm9
  56f143:	62 91 14 20 c6 e5 d8 	vshufps $0xd8,%ymm29,%ymm29,%ymm4
  56f14a:	62 31 64 20 c6 eb d8 	vshufps $0xd8,%ymm19,%ymm19,%ymm13
  56f151:	62 b1 44 20 c6 df d8 	vshufps $0xd8,%ymm23,%ymm23,%ymm3
  56f158:	62 11 34 20 c6 e1 d8 	vshufps $0xd8,%ymm25,%ymm25,%ymm12
  56f15f:	62 91 2c 20 c6 fa d8 	vshufps $0xd8,%ymm26,%ymm26,%ymm7
  56f166:	62 91 24 20 c6 c3 d8 	vshufps $0xd8,%ymm27,%ymm27,%ymm0
  56f16d:	c4 c1 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm2
  56f173:	c4 41 04 c6 d7 d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm10
  56f179:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  56f17e:	62 31 54 20 c6 fd d8 	vshufps $0xd8,%ymm21,%ymm21,%ymm15
  56f185:	62 33 75 20 18 f2 01 	vinsertf32x4 $0x1,%xmm18,%ymm17,%ymm14
  56f18c:	c4 e3 25 18 f6 01    	vinsertf128 $0x1,%xmm6,%ymm11,%ymm6
  56f192:	c5 0d 15 de          	vunpckhpd %ymm6,%ymm14,%ymm11
  56f196:	62 a3 3d 28 18 c0 01 	vinsertf32x4 $0x1,%xmm16,%ymm8,%ymm16
  56f19d:	62 a1 7c 08 28 cc    	vmovaps %xmm20,%xmm17
  56f1a3:	62 a1 fd 20 15 d1    	vunpckhpd %ymm17,%ymm16,%ymm18
  56f1a9:	62 31 24 28 c6 c2 dd 	vshufps $0xdd,%ymm18,%ymm11,%ymm8
  56f1b0:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  56f1b6:	62 31 24 28 c6 da 88 	vshufps $0x88,%ymm18,%ymm11,%ymm11
  56f1bd:	62 c1 24 28 c6 d3 d8 	vshufps $0xd8,%ymm11,%ymm11,%ymm18
  56f1c4:	c5 8d 14 f6          	vunpcklpd %ymm6,%ymm14,%ymm6
  56f1c8:	62 31 fd 20 14 d9    	vunpcklpd %ymm17,%ymm16,%ymm11
  56f1ce:	c4 41 4c c6 f3 dd    	vshufps $0xdd,%ymm11,%ymm6,%ymm14
  56f1d4:	c4 41 0c c6 f6 d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm14
  56f1da:	c4 c1 4c c6 f3 88    	vshufps $0x88,%ymm11,%ymm6,%ymm6
  56f1e0:	c5 cc c6 f6 d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm6
  56f1e5:	62 e1 7c 28 10 42 08 	vmovups 0x100(%rdx),%ymm16
  56f1ec:	62 e1 7c 28 10 4a 09 	vmovups 0x120(%rdx),%ymm17
  56f1f3:	62 31 04 28 59 d8    	vmulps %ymm16,%ymm15,%ymm11
  56f1f9:	62 32 15 28 bc d9    	vfnmadd231ps %ymm17,%ymm13,%ymm11
  56f1ff:	62 31 14 28 59 e8    	vmulps %ymm16,%ymm13,%ymm13
  56f205:	62 e1 7c 28 10 42 04 	vmovups 0x80(%rdx),%ymm16
  56f20c:	62 32 05 28 b8 e9    	vfmadd231ps %ymm17,%ymm15,%ymm13
  56f212:	62 e1 7c 28 10 4a 05 	vmovups 0xa0(%rdx),%ymm17
  56f219:	62 31 6c 20 59 f8    	vmulps %ymm16,%ymm18,%ymm15
  56f21f:	62 32 1d 28 bc f9    	vfnmadd231ps %ymm17,%ymm12,%ymm15
  56f225:	62 31 1c 28 59 e0    	vmulps %ymm16,%ymm12,%ymm12
  56f22b:	62 e1 7c 28 10 42 0c 	vmovups 0x180(%rdx),%ymm16
  56f232:	62 32 6d 20 b8 e1    	vfmadd231ps %ymm17,%ymm18,%ymm12
  56f238:	62 e1 7c 28 10 4a 0d 	vmovups 0x1a0(%rdx),%ymm17
  56f23f:	62 a1 2c 28 59 d0    	vmulps %ymm16,%ymm10,%ymm18
  56f245:	62 a2 35 28 bc d1    	vfnmadd231ps %ymm17,%ymm9,%ymm18
  56f24b:	62 31 34 28 59 c8    	vmulps %ymm16,%ymm9,%ymm9
  56f251:	62 e1 7c 28 10 42 02 	vmovups 0x40(%rdx),%ymm16
  56f258:	62 32 2d 28 b8 c9    	vfmadd231ps %ymm17,%ymm10,%ymm9
  56f25e:	c5 7c 10 52 60       	vmovups 0x60(%rdx),%ymm10
  56f263:	62 a1 0c 28 59 c8    	vmulps %ymm16,%ymm14,%ymm17
  56f269:	62 c2 45 28 bc ca    	vfnmadd231ps %ymm10,%ymm7,%ymm17
  56f26f:	62 b1 44 28 59 f8    	vmulps %ymm16,%ymm7,%ymm7
  56f275:	62 e1 7c 28 10 42 0a 	vmovups 0x140(%rdx),%ymm16
  56f27c:	c4 c2 0d b8 fa       	vfmadd231ps %ymm10,%ymm14,%ymm7
  56f281:	c5 7c 10 92 60 01 00 	vmovups 0x160(%rdx),%ymm10
  56f288:	00 
  56f289:	62 31 54 28 59 f0    	vmulps %ymm16,%ymm5,%ymm14
  56f28f:	c4 42 5d bc f2       	vfnmadd231ps %ymm10,%ymm4,%ymm14
  56f294:	62 b1 5c 28 59 e0    	vmulps %ymm16,%ymm4,%ymm4
  56f29a:	62 e1 7c 28 10 42 06 	vmovups 0xc0(%rdx),%ymm16
  56f2a1:	c4 c2 55 b8 e2       	vfmadd231ps %ymm10,%ymm5,%ymm4
  56f2a6:	c5 fc 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm5
  56f2ad:	00 
  56f2ae:	62 31 3c 28 59 d0    	vmulps %ymm16,%ymm8,%ymm10
  56f2b4:	c4 62 65 bc d5       	vfnmadd231ps %ymm5,%ymm3,%ymm10
  56f2b9:	62 b1 64 28 59 d8    	vmulps %ymm16,%ymm3,%ymm3
  56f2bf:	62 e1 7c 28 10 42 0e 	vmovups 0x1c0(%rdx),%ymm16
  56f2c6:	c4 e2 3d b8 dd       	vfmadd231ps %ymm5,%ymm8,%ymm3
  56f2cb:	c5 fc 10 aa e0 01 00 	vmovups 0x1e0(%rdx),%ymm5
  56f2d2:	00 
  56f2d3:	62 31 6c 28 59 c0    	vmulps %ymm16,%ymm2,%ymm8
  56f2d9:	c4 62 75 bc c5       	vfnmadd231ps %ymm5,%ymm1,%ymm8
  56f2de:	62 b1 74 28 59 c8    	vmulps %ymm16,%ymm1,%ymm1
  56f2e4:	62 c1 4c 28 58 c3    	vaddps %ymm11,%ymm6,%ymm16
  56f2ea:	c4 e2 6d b8 cd       	vfmadd231ps %ymm5,%ymm2,%ymm1
  56f2ef:	62 b1 04 28 58 d2    	vaddps %ymm18,%ymm15,%ymm2
  56f2f5:	62 f1 7c 20 58 ea    	vaddps %ymm2,%ymm16,%ymm5
  56f2fb:	c4 c1 4c 5c f3       	vsubps %ymm11,%ymm6,%ymm6
  56f300:	c4 41 1c 58 d9       	vaddps %ymm9,%ymm12,%ymm11
  56f305:	c4 41 1c 5c c9       	vsubps %ymm9,%ymm12,%ymm9
  56f30a:	62 51 74 20 58 e6    	vaddps %ymm14,%ymm17,%ymm12
  56f310:	62 51 74 20 5c f6    	vsubps %ymm14,%ymm17,%ymm14
  56f316:	62 e1 44 28 58 cc    	vaddps %ymm4,%ymm7,%ymm17
  56f31c:	c5 c4 5c e4          	vsubps %ymm4,%ymm7,%ymm4
  56f320:	c5 e4 58 f9          	vaddps %ymm1,%ymm3,%ymm7
  56f324:	c5 e4 5c c9          	vsubps %ymm1,%ymm3,%ymm1
  56f328:	c4 c1 2c 58 d8       	vaddps %ymm8,%ymm10,%ymm3
  56f32d:	c4 41 2c 5c c0       	vsubps %ymm8,%ymm10,%ymm8
  56f332:	c5 14 58 d0          	vaddps %ymm0,%ymm13,%ymm10
  56f336:	c4 c1 7c 5c c5       	vsubps %ymm13,%ymm0,%ymm0
  56f33b:	c5 1c 58 eb          	vaddps %ymm3,%ymm12,%ymm13
  56f33f:	62 51 6c 20 5c ff    	vsubps %ymm15,%ymm18,%ymm15
  56f345:	62 e1 0c 28 58 d4    	vaddps %ymm4,%ymm14,%ymm18
  56f34b:	c4 c1 5c 5c e6       	vsubps %ymm14,%ymm4,%ymm4
  56f350:	c4 41 74 5c f0       	vsubps %ymm8,%ymm1,%ymm14
  56f355:	c5 bc 58 c9          	vaddps %ymm1,%ymm8,%ymm1
  56f359:	c4 62 7d 18 05 86 cf 	vbroadcastss -0x4f307a(%rip),%ymm8        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56f360:	b0 ff 
  56f362:	62 c1 6c 20 59 d0    	vmulps %ymm8,%ymm18,%ymm18
  56f368:	c4 41 0c 59 f0       	vmulps %ymm8,%ymm14,%ymm14
  56f36d:	c5 bc 59 e4          	vmulps %ymm4,%ymm8,%ymm4
  56f371:	c5 bc 59 c9          	vmulps %ymm1,%ymm8,%ymm1
  56f375:	c5 14 58 c5          	vaddps %ymm5,%ymm13,%ymm8
  56f379:	62 f1 7c 20 5c d2    	vsubps %ymm2,%ymm16,%ymm2
  56f37f:	62 e1 74 20 58 c7    	vaddps %ymm7,%ymm17,%ymm16
  56f385:	62 f1 74 20 5c ff    	vsubps %ymm7,%ymm17,%ymm7
  56f38b:	62 c1 24 28 58 ca    	vaddps %ymm10,%ymm11,%ymm17
  56f391:	c4 41 2c 5c d3       	vsubps %ymm11,%ymm10,%ymm10
  56f396:	62 31 74 20 58 d8    	vaddps %ymm16,%ymm17,%ymm11
  56f39c:	c4 41 64 5c e4       	vsubps %ymm12,%ymm3,%ymm12
  56f3a1:	c5 b4 58 de          	vaddps %ymm6,%ymm9,%ymm3
  56f3a5:	c4 41 4c 5c c9       	vsubps %ymm9,%ymm6,%ymm9
  56f3aa:	c5 dc 5c f1          	vsubps %ymm1,%ymm4,%ymm6
  56f3ae:	c5 dc 58 c9          	vaddps %ymm1,%ymm4,%ymm1
  56f3b2:	c5 84 58 e0          	vaddps %ymm0,%ymm15,%ymm4
  56f3b6:	c4 41 7c 5c ff       	vsubps %ymm15,%ymm0,%ymm15
  56f3bb:	62 d1 6c 20 58 c6    	vaddps %ymm14,%ymm18,%ymm0
  56f3c1:	62 31 0c 28 5c f2    	vsubps %ymm18,%ymm14,%ymm14
  56f3c7:	62 e1 64 28 58 d0    	vaddps %ymm0,%ymm3,%ymm18
  56f3cd:	c4 41 54 5c ed       	vsubps %ymm13,%ymm5,%ymm13
  56f3d2:	62 e1 5c 28 58 de    	vaddps %ymm6,%ymm4,%ymm19
  56f3d8:	62 a1 74 20 5c c0    	vsubps %ymm16,%ymm17,%ymm16
  56f3de:	62 e1 6c 28 58 cf    	vaddps %ymm7,%ymm2,%ymm17
  56f3e4:	c5 e4 5c e8          	vsubps %ymm0,%ymm3,%ymm5
  56f3e8:	62 c1 2c 28 58 e4    	vaddps %ymm12,%ymm10,%ymm20
  56f3ee:	c5 dc 5c f6          	vsubps %ymm6,%ymm4,%ymm6
  56f3f2:	62 e1 34 28 58 e9    	vaddps %ymm1,%ymm9,%ymm21
  56f3f8:	c5 ec 5c df          	vsubps %ymm7,%ymm2,%ymm3
  56f3fc:	c4 c1 04 58 fe       	vaddps %ymm14,%ymm15,%ymm7
  56f401:	c4 c1 2c 5c e4       	vsubps %ymm12,%ymm10,%ymm4
  56f406:	c5 b4 5c c1          	vsubps %ymm1,%ymm9,%ymm0
  56f40a:	c4 c1 04 5c ce       	vsubps %ymm14,%ymm15,%ymm1
  56f40f:	c5 fc 28 15 29 19 b1 	vmovaps -0x4ee6d7(%rip),%ymm2        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  56f416:	ff 
  56f417:	c4 41 24 15 c8       	vunpckhps %ymm8,%ymm11,%ymm9
  56f41c:	c4 41 24 14 d0       	vunpcklps %ymm8,%ymm11,%ymm10
  56f421:	62 52 6d 28 7f d8    	vpermt2ps %ymm8,%ymm2,%ymm11
  56f427:	c5 7c 11 1e          	vmovups %ymm11,(%rsi)
  56f42b:	c4 63 7d 19 56 20 01 	vextractf128 $0x1,%ymm10,0x20(%rsi)
  56f432:	c4 43 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm8
  56f438:	c5 78 13 46 30       	vmovlps %xmm8,0x30(%rsi)
  56f43d:	62 31 64 20 15 c2    	vunpckhps %ymm18,%ymm19,%ymm8
  56f443:	62 31 64 20 14 ca    	vunpcklps %ymm18,%ymm19,%ymm9
  56f449:	62 a2 6d 28 7f da    	vpermt2ps %ymm18,%ymm2,%ymm19
  56f44f:	62 e1 7c 28 11 9e 38 	vmovups %ymm19,0x38(%rsi)
  56f456:	00 00 00 
  56f459:	c4 63 7d 19 4e 58 01 	vextractf128 $0x1,%ymm9,0x58(%rsi)
  56f460:	c4 43 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm8
  56f466:	c5 78 13 46 68       	vmovlps %xmm8,0x68(%rsi)
  56f46b:	62 31 5c 20 15 c1    	vunpckhps %ymm17,%ymm20,%ymm8
  56f471:	62 31 5c 20 14 c9    	vunpcklps %ymm17,%ymm20,%ymm9
  56f477:	62 a2 6d 28 7f e1    	vpermt2ps %ymm17,%ymm2,%ymm20
  56f47d:	62 e1 7c 28 11 a6 70 	vmovups %ymm20,0x70(%rsi)
  56f484:	00 00 00 
  56f487:	c4 63 7d 19 8e 90 00 	vextractf128 $0x1,%ymm9,0x90(%rsi)
  56f48e:	00 00 01 
  56f491:	c4 43 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm8
  56f497:	c5 78 13 86 a0 00 00 	vmovlps %xmm8,0xa0(%rsi)
  56f49e:	00 
  56f49f:	62 31 44 28 15 c5    	vunpckhps %ymm21,%ymm7,%ymm8
  56f4a5:	62 31 44 28 14 cd    	vunpcklps %ymm21,%ymm7,%ymm9
  56f4ab:	62 b2 6d 28 7f fd    	vpermt2ps %ymm21,%ymm2,%ymm7
  56f4b1:	c5 fc 11 be a8 00 00 	vmovups %ymm7,0xa8(%rsi)
  56f4b8:	00 
  56f4b9:	c4 63 7d 19 8e c8 00 	vextractf128 $0x1,%ymm9,0xc8(%rsi)
  56f4c0:	00 00 01 
  56f4c3:	c4 63 7d 19 c7 01    	vextractf128 $0x1,%ymm8,%xmm7
  56f4c9:	c5 f8 13 be d8 00 00 	vmovlps %xmm7,0xd8(%rsi)
  56f4d0:	00 
  56f4d1:	62 d1 7c 20 15 fd    	vunpckhps %ymm13,%ymm16,%ymm7
  56f4d7:	62 51 7c 20 14 c5    	vunpcklps %ymm13,%ymm16,%ymm8
  56f4dd:	62 c2 6d 28 7f c5    	vpermt2ps %ymm13,%ymm2,%ymm16
  56f4e3:	62 e1 7c 28 11 46 07 	vmovups %ymm16,0xe0(%rsi)
  56f4ea:	c4 63 7d 19 86 00 01 	vextractf128 $0x1,%ymm8,0x100(%rsi)
  56f4f1:	00 00 01 
  56f4f4:	c4 e3 7d 19 ff 01    	vextractf128 $0x1,%ymm7,%xmm7
  56f4fa:	c5 f8 13 be 10 01 00 	vmovlps %xmm7,0x110(%rsi)
  56f501:	00 
  56f502:	c5 cc 15 fd          	vunpckhps %ymm5,%ymm6,%ymm7
  56f506:	c5 4c 14 c5          	vunpcklps %ymm5,%ymm6,%ymm8
  56f50a:	62 f2 6d 28 7f f5    	vpermt2ps %ymm5,%ymm2,%ymm6
  56f510:	c5 fc 11 b6 18 01 00 	vmovups %ymm6,0x118(%rsi)
  56f517:	00 
  56f518:	c4 63 7d 19 86 38 01 	vextractf128 $0x1,%ymm8,0x138(%rsi)
  56f51f:	00 00 01 
  56f522:	c4 e3 7d 19 fd 01    	vextractf128 $0x1,%ymm7,%xmm5
  56f528:	c5 f8 13 ae 48 01 00 	vmovlps %xmm5,0x148(%rsi)
  56f52f:	00 
  56f530:	c5 dc 15 eb          	vunpckhps %ymm3,%ymm4,%ymm5
  56f534:	c5 dc 14 f3          	vunpcklps %ymm3,%ymm4,%ymm6
  56f538:	62 f2 6d 28 7f e3    	vpermt2ps %ymm3,%ymm2,%ymm4
  56f53e:	c5 fc 11 a6 50 01 00 	vmovups %ymm4,0x150(%rsi)
  56f545:	00 
  56f546:	c4 e3 7d 19 b6 70 01 	vextractf128 $0x1,%ymm6,0x170(%rsi)
  56f54d:	00 00 01 
  56f550:	c4 e3 7d 19 eb 01    	vextractf128 $0x1,%ymm5,%xmm3
  56f556:	c5 f8 13 9e 80 01 00 	vmovlps %xmm3,0x180(%rsi)
  56f55d:	00 
  56f55e:	62 f2 75 28 77 d0    	vpermi2ps %ymm0,%ymm1,%ymm2
  56f564:	c5 fc 11 96 88 01 00 	vmovups %ymm2,0x188(%rsi)
  56f56b:	00 
  56f56c:	c5 f4 15 d0          	vunpckhps %ymm0,%ymm1,%ymm2
  56f570:	c5 f4 14 c0          	vunpcklps %ymm0,%ymm1,%ymm0
  56f574:	c4 e3 7d 19 86 a8 01 	vextractf128 $0x1,%ymm0,0x1a8(%rsi)
  56f57b:	00 00 01 
  56f57e:	c4 e3 7d 19 d0 01    	vextractf128 $0x1,%ymm2,%xmm0
  56f584:	c5 f8 13 86 b8 01 00 	vmovlps %xmm0,0x1b8(%rsi)
  56f58b:	00 
  56f58c:	c5 f8 77             	vzeroupper
  56f58f:	c3                   	ret


000000000056f590 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56f590:	c5 fc 10 17          	vmovups (%rdi),%ymm2
  56f594:	c5 fc 11 54 24 d8    	vmovups %ymm2,-0x28(%rsp)
  56f59a:	c5 fc 10 5f 20       	vmovups 0x20(%rdi),%ymm3
  56f59f:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  56f5a4:	c5 fc 10 4f 60       	vmovups 0x60(%rdi),%ymm1
  56f5a9:	c5 7c 10 a7 80 00 00 	vmovups 0x80(%rdi),%ymm12
  56f5b0:	00 
  56f5b1:	c5 7c 10 af a0 00 00 	vmovups 0xa0(%rdi),%ymm13
  56f5b8:	00 
  56f5b9:	c5 7c 10 97 c0 00 00 	vmovups 0xc0(%rdi),%ymm10
  56f5c0:	00 
  56f5c1:	c5 7c 10 9f e0 00 00 	vmovups 0xe0(%rdi),%ymm11
  56f5c8:	00 
  56f5c9:	c5 fc 10 af 00 01 00 	vmovups 0x100(%rdi),%ymm5
  56f5d0:	00 
  56f5d1:	c5 fc 10 bf 20 01 00 	vmovups 0x120(%rdi),%ymm7
  56f5d8:	00 
  56f5d9:	c5 7c 10 b7 40 01 00 	vmovups 0x140(%rdi),%ymm14
  56f5e0:	00 
  56f5e1:	c5 7c 10 bf 60 01 00 	vmovups 0x160(%rdi),%ymm15
  56f5e8:	00 
  56f5e9:	62 e1 7c 28 10 47 0c 	vmovups 0x180(%rdi),%ymm16
  56f5f0:	62 e1 7c 28 10 4f 0d 	vmovups 0x1a0(%rdi),%ymm17
  56f5f7:	62 e1 7c 28 10 57 0e 	vmovups 0x1c0(%rdi),%ymm18
  56f5fe:	62 e1 7c 28 10 5f 0f 	vmovups 0x1e0(%rdi),%ymm19
  56f605:	c5 ec c6 e3 88       	vshufps $0x88,%ymm3,%ymm2,%ymm4
  56f60a:	62 e3 fd 28 01 e4 d8 	vpermpd $0xd8,%ymm4,%ymm20
  56f611:	c5 d4 c6 e7 88       	vshufps $0x88,%ymm7,%ymm5,%ymm4
  56f616:	62 e3 fd 28 01 ec d8 	vpermpd $0xd8,%ymm4,%ymm21
  56f61d:	62 a1 5c 20 58 f5    	vaddps %ymm21,%ymm20,%ymm22
  56f623:	c4 c1 1c c6 e5 88    	vshufps $0x88,%ymm13,%ymm12,%ymm4
  56f629:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  56f62f:	62 b1 7c 20 c6 f1 88 	vshufps $0x88,%ymm17,%ymm16,%ymm6
  56f636:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  56f63c:	62 e1 5c 28 58 fe    	vaddps %ymm6,%ymm4,%ymm23
  56f642:	62 21 4c 20 58 c7    	vaddps %ymm23,%ymm22,%ymm24
  56f648:	c5 7c c6 c1 88       	vshufps $0x88,%ymm1,%ymm0,%ymm8
  56f64d:	62 43 fd 28 01 c8 d8 	vpermpd $0xd8,%ymm8,%ymm25
  56f654:	c4 41 0c c6 c7 88    	vshufps $0x88,%ymm15,%ymm14,%ymm8
  56f65a:	62 43 fd 28 01 d0 d8 	vpermpd $0xd8,%ymm8,%ymm26
  56f661:	62 11 34 20 58 c2    	vaddps %ymm26,%ymm25,%ymm8
  56f667:	c4 41 2c c6 cb 88    	vshufps $0x88,%ymm11,%ymm10,%ymm9
  56f66d:	62 43 fd 28 01 d9 d8 	vpermpd $0xd8,%ymm9,%ymm27
  56f674:	62 31 6c 20 c6 cb 88 	vshufps $0x88,%ymm19,%ymm18,%ymm9
  56f67b:	62 43 fd 28 01 e1 d8 	vpermpd $0xd8,%ymm9,%ymm28
  56f682:	62 11 24 20 58 cc    	vaddps %ymm28,%ymm27,%ymm9
  56f688:	62 41 3c 28 58 e9    	vaddps %ymm9,%ymm8,%ymm29
  56f68e:	62 01 3c 20 58 f5    	vaddps %ymm29,%ymm24,%ymm30
  56f694:	62 01 3c 20 5c c5    	vsubps %ymm29,%ymm24,%ymm24
  56f69a:	62 03 8d 20 23 e8 03 	vshuff64x2 $0x3,%ymm24,%ymm30,%ymm29
  56f6a1:	c4 41 2c c6 d3 dd    	vshufps $0xdd,%ymm11,%ymm10,%ymm10
  56f6a7:	62 43 fd 28 01 fa d8 	vpermpd $0xd8,%ymm10,%ymm31
  56f6ae:	62 31 6c 20 c6 d3 dd 	vshufps $0xdd,%ymm19,%ymm18,%ymm10
  56f6b5:	62 c3 fd 28 01 d2 d8 	vpermpd $0xd8,%ymm10,%ymm18
  56f6bc:	62 31 04 20 58 d2    	vaddps %ymm18,%ymm31,%ymm10
  56f6c2:	c5 fc c6 c1 dd       	vshufps $0xdd,%ymm1,%ymm0,%ymm0
  56f6c7:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56f6cd:	c4 c1 0c c6 cf dd    	vshufps $0xdd,%ymm15,%ymm14,%ymm1
  56f6d3:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  56f6d9:	c5 7c 58 d9          	vaddps %ymm1,%ymm0,%ymm11
  56f6dd:	c4 41 2c 5c f3       	vsubps %ymm11,%ymm10,%ymm14
  56f6e2:	62 31 4c 20 5c ff    	vsubps %ymm23,%ymm22,%ymm15
  56f6e8:	62 c1 0c 28 58 df    	vaddps %ymm15,%ymm14,%ymm19
  56f6ee:	62 c1 04 28 5c f6    	vsubps %ymm14,%ymm15,%ymm22
  56f6f4:	62 a3 e5 20 23 fe 03 	vshuff64x2 $0x3,%ymm22,%ymm19,%ymm23
  56f6fb:	62 31 95 20 15 f7    	vunpckhpd %ymm23,%ymm29,%ymm14
  56f701:	62 31 7c 20 c6 f9 dd 	vshufps $0xdd,%ymm17,%ymm16,%ymm15
  56f708:	c4 c3 fd 01 d7 d8    	vpermpd $0xd8,%ymm15,%ymm2
  56f70e:	c4 41 1c c6 e5 dd    	vshufps $0xdd,%ymm13,%ymm12,%ymm12
  56f714:	c4 43 fd 01 ec d8    	vpermpd $0xd8,%ymm12,%ymm13
  56f71a:	62 c1 6c 28 5c c5    	vsubps %ymm13,%ymm2,%ymm16
  56f720:	62 a1 5c 20 5c cd    	vsubps %ymm21,%ymm20,%ymm17
  56f726:	62 a1 7c 20 58 e1    	vaddps %ymm17,%ymm16,%ymm20
  56f72c:	62 81 34 20 5c ea    	vsubps %ymm26,%ymm25,%ymm21
  56f732:	c5 fc 5c c9          	vsubps %ymm1,%ymm0,%ymm1
  56f736:	62 71 54 20 5c e1    	vsubps %ymm1,%ymm21,%ymm12
  56f73c:	c4 e2 7d 18 05 a3 cb 	vbroadcastss -0x4f345d(%rip),%ymm0        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56f743:	b0 ff 
  56f745:	c5 1c 59 e0          	vmulps %ymm0,%ymm12,%ymm12
  56f749:	62 a1 04 20 5c d2    	vsubps %ymm18,%ymm31,%ymm18
  56f74f:	62 01 24 20 5c cc    	vsubps %ymm28,%ymm27,%ymm25
  56f755:	62 11 6c 20 58 f9    	vaddps %ymm25,%ymm18,%ymm15
  56f75b:	c5 04 59 f8          	vmulps %ymm0,%ymm15,%ymm15
  56f75f:	62 41 1c 28 5c d7    	vsubps %ymm15,%ymm12,%ymm26
  56f765:	62 01 5c 20 58 da    	vaddps %ymm26,%ymm20,%ymm27
  56f76b:	62 81 5c 20 5c e2    	vsubps %ymm26,%ymm20,%ymm20
  56f771:	62 23 a5 20 23 d4 03 	vshuff64x2 $0x3,%ymm20,%ymm27,%ymm26
  56f778:	62 a1 74 20 5c c0    	vsubps %ymm16,%ymm17,%ymm16
  56f77e:	62 a1 34 20 5c ca    	vsubps %ymm18,%ymm25,%ymm17
  56f784:	62 61 74 20 59 c8    	vmulps %ymm0,%ymm17,%ymm25
  56f78a:	62 b1 74 28 58 cd    	vaddps %ymm21,%ymm1,%ymm1
  56f790:	62 e1 74 28 59 e8    	vmulps %ymm0,%ymm1,%ymm21
  56f796:	62 b1 34 20 5c cd    	vsubps %ymm21,%ymm25,%ymm1
  56f79c:	62 61 7c 20 58 e1    	vaddps %ymm1,%ymm16,%ymm28
  56f7a2:	62 f1 7c 20 5c c9    	vsubps %ymm1,%ymm16,%ymm1
  56f7a8:	62 e3 9d 20 23 c1 03 	vshuff64x2 $0x3,%ymm1,%ymm28,%ymm16
  56f7af:	62 a1 ad 20 15 c8    	vunpckhpd %ymm16,%ymm26,%ymm17
  56f7b5:	62 a1 0c 28 c6 d1 dd 	vshufps $0xdd,%ymm17,%ymm14,%ymm18
  56f7bc:	62 31 0c 28 c6 f1 88 	vshufps $0x88,%ymm17,%ymm14,%ymm14
  56f7c3:	62 a1 95 20 14 cf    	vunpcklpd %ymm23,%ymm29,%ymm17
  56f7c9:	62 a1 ad 20 14 f8    	vunpcklpd %ymm16,%ymm26,%ymm23
  56f7cf:	62 a1 74 20 c6 c7 dd 	vshufps $0xdd,%ymm23,%ymm17,%ymm16
  56f7d6:	62 a1 74 20 c6 cf 88 	vshufps $0x88,%ymm23,%ymm17,%ymm17
  56f7dd:	62 83 0d 20 18 f8 01 	vinsertf32x4 $0x1,%xmm24,%ymm30,%ymm23
  56f7e4:	62 a3 65 20 18 de 01 	vinsertf32x4 $0x1,%xmm22,%ymm19,%ymm19
  56f7eb:	62 a1 c5 20 15 f3    	vunpckhpd %ymm19,%ymm23,%ymm22
  56f7f1:	62 a3 25 20 18 e4 01 	vinsertf32x4 $0x1,%xmm20,%ymm27,%ymm20
  56f7f8:	62 f3 1d 20 18 c9 01 	vinsertf32x4 $0x1,%xmm1,%ymm28,%ymm1
  56f7ff:	62 61 dd 20 15 c1    	vunpckhpd %ymm1,%ymm20,%ymm24
  56f805:	62 01 4c 20 c6 d0 dd 	vshufps $0xdd,%ymm24,%ymm22,%ymm26
  56f80c:	62 81 4c 20 c6 f0 88 	vshufps $0x88,%ymm24,%ymm22,%ymm22
  56f813:	62 a1 c5 20 14 db    	vunpcklpd %ymm19,%ymm23,%ymm19
  56f819:	62 f1 dd 20 14 c9    	vunpcklpd %ymm1,%ymm20,%ymm1
  56f81f:	62 e1 64 20 c6 e1 dd 	vshufps $0xdd,%ymm1,%ymm19,%ymm20
  56f826:	62 f1 64 20 c6 c9 88 	vshufps $0x88,%ymm1,%ymm19,%ymm1
  56f82d:	62 e1 7c 28 10 9c 24 	vmovups -0x28(%rsp),%ymm19
  56f834:	d8 ff ff ff 
  56f838:	62 f1 64 20 c6 db dd 	vshufps $0xdd,%ymm3,%ymm19,%ymm3
  56f83f:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  56f845:	c5 d4 c6 ef dd       	vshufps $0xdd,%ymm7,%ymm5,%ymm5
  56f84a:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  56f850:	c5 e4 58 fd          	vaddps %ymm5,%ymm3,%ymm7
  56f854:	c5 94 58 d2          	vaddps %ymm2,%ymm13,%ymm2
  56f858:	c5 44 58 ea          	vaddps %ymm2,%ymm7,%ymm13
  56f85c:	c4 41 24 58 d2       	vaddps %ymm10,%ymm11,%ymm10
  56f861:	c4 41 14 58 da       	vaddps %ymm10,%ymm13,%ymm11
  56f866:	c4 41 14 5c d2       	vsubps %ymm10,%ymm13,%ymm10
  56f86b:	c4 43 25 06 ea 31    	vperm2f128 $0x31,%ymm10,%ymm11,%ymm13
  56f871:	c5 c4 5c d2          	vsubps %ymm2,%ymm7,%ymm2
  56f875:	c4 c1 3c 5c f9       	vsubps %ymm9,%ymm8,%ymm7
  56f87a:	c5 6c 58 c7          	vaddps %ymm7,%ymm2,%ymm8
  56f87e:	c5 ec 5c ff          	vsubps %ymm7,%ymm2,%ymm7
  56f882:	c4 e3 3d 06 d7 31    	vperm2f128 $0x31,%ymm7,%ymm8,%ymm2
  56f888:	c5 15 15 ca          	vunpckhpd %ymm2,%ymm13,%ymm9
  56f88c:	c5 e4 5c dd          	vsubps %ymm5,%ymm3,%ymm3
  56f890:	c5 dc 5c e6          	vsubps %ymm6,%ymm4,%ymm4
  56f894:	c5 e4 58 ec          	vaddps %ymm4,%ymm3,%ymm5
  56f898:	62 91 54 20 58 f1    	vaddps %ymm25,%ymm21,%ymm6
  56f89e:	62 e1 54 28 58 de    	vaddps %ymm6,%ymm5,%ymm19
  56f8a4:	62 e1 54 28 5c ee    	vsubps %ymm6,%ymm5,%ymm21
  56f8aa:	62 b3 e5 20 23 ed 03 	vshuff64x2 $0x3,%ymm21,%ymm19,%ymm5
  56f8b1:	c5 e4 5c dc          	vsubps %ymm4,%ymm3,%ymm3
  56f8b5:	c4 c1 1c 58 e7       	vaddps %ymm15,%ymm12,%ymm4
  56f8ba:	c5 64 58 fc          	vaddps %ymm4,%ymm3,%ymm15
  56f8be:	62 e1 64 28 5c fc    	vsubps %ymm4,%ymm3,%ymm23
  56f8c4:	62 b3 85 28 23 df 03 	vshuff64x2 $0x3,%ymm23,%ymm15,%ymm3
  56f8cb:	c5 d5 15 e3          	vunpckhpd %ymm3,%ymm5,%ymm4
  56f8cf:	c5 b4 c6 f4 dd       	vshufps $0xdd,%ymm4,%ymm9,%ymm6
  56f8d4:	c5 34 c6 e4 88       	vshufps $0x88,%ymm4,%ymm9,%ymm12
  56f8d9:	c5 95 14 d2          	vunpcklpd %ymm2,%ymm13,%ymm2
  56f8dd:	c5 d5 14 db          	vunpcklpd %ymm3,%ymm5,%ymm3
  56f8e1:	62 61 6c 28 c6 c3 dd 	vshufps $0xdd,%ymm3,%ymm2,%ymm24
  56f8e8:	62 61 6c 28 c6 cb 88 	vshufps $0x88,%ymm3,%ymm2,%ymm25
  56f8ef:	c4 43 25 18 da 01    	vinsertf128 $0x1,%xmm10,%ymm11,%ymm11
  56f8f5:	62 b1 6c 20 c6 d2 d8 	vshufps $0xd8,%ymm18,%ymm18,%ymm2
  56f8fc:	c4 41 0c c6 d6 d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm10
  56f902:	62 b1 7c 20 c6 e8 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm5
  56f909:	62 31 74 20 c6 e9 d8 	vshufps $0xd8,%ymm17,%ymm17,%ymm13
  56f910:	62 91 2c 20 c6 e2 d8 	vshufps $0xd8,%ymm26,%ymm26,%ymm4
  56f917:	62 31 4c 20 c6 f6 d8 	vshufps $0xd8,%ymm22,%ymm22,%ymm14
  56f91e:	62 31 5c 20 c6 cc d8 	vshufps $0xd8,%ymm20,%ymm20,%ymm9
  56f925:	c5 cc c6 de d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm3
  56f92a:	c4 41 1c c6 e4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm12
  56f930:	62 91 3c 20 c6 f0 d8 	vshufps $0xd8,%ymm24,%ymm24,%ymm6
  56f937:	62 81 34 20 c6 c1 d8 	vshufps $0xd8,%ymm25,%ymm25,%ymm16
  56f93e:	c4 63 3d 18 c7 01    	vinsertf128 $0x1,%xmm7,%ymm8,%ymm8
  56f944:	62 c1 a5 28 15 c8    	vunpckhpd %ymm8,%ymm11,%ymm17
  56f94a:	62 a3 65 20 18 d5 01 	vinsertf32x4 $0x1,%xmm21,%ymm19,%ymm18
  56f951:	62 33 05 28 18 ff 01 	vinsertf32x4 $0x1,%xmm23,%ymm15,%ymm15
  56f958:	62 c1 ed 20 15 df    	vunpckhpd %ymm15,%ymm18,%ymm19
  56f95e:	62 b1 74 20 c6 fb dd 	vshufps $0xdd,%ymm19,%ymm17,%ymm7
  56f965:	c5 c4 c6 ff d8       	vshufps $0xd8,%ymm7,%ymm7,%ymm7
  56f96a:	62 a1 74 20 c6 cb 88 	vshufps $0x88,%ymm19,%ymm17,%ymm17
  56f971:	62 a1 74 20 c6 c9 d8 	vshufps $0xd8,%ymm17,%ymm17,%ymm17
  56f978:	c4 41 25 14 c0       	vunpcklpd %ymm8,%ymm11,%ymm8
  56f97d:	62 51 ed 20 14 df    	vunpcklpd %ymm15,%ymm18,%ymm11
  56f983:	c4 41 3c c6 fb dd    	vshufps $0xdd,%ymm11,%ymm8,%ymm15
  56f989:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  56f98f:	c4 41 3c c6 c3 88    	vshufps $0x88,%ymm11,%ymm8,%ymm8
  56f995:	62 e1 7c 28 10 52 08 	vmovups 0x100(%rdx),%ymm18
  56f99c:	62 e1 7c 28 10 5a 09 	vmovups 0x120(%rdx),%ymm19
  56f9a3:	62 31 7c 20 59 da    	vmulps %ymm18,%ymm16,%ymm11
  56f9a9:	62 32 15 28 bc db    	vfnmadd231ps %ymm19,%ymm13,%ymm11
  56f9af:	62 31 14 28 59 ea    	vmulps %ymm18,%ymm13,%ymm13
  56f9b5:	62 e1 7c 28 10 52 04 	vmovups 0x80(%rdx),%ymm18
  56f9bc:	62 32 7d 20 b8 eb    	vfmadd231ps %ymm19,%ymm16,%ymm13
  56f9c2:	62 e1 7c 28 10 5a 05 	vmovups 0xa0(%rdx),%ymm19
  56f9c9:	62 a1 74 20 59 c2    	vmulps %ymm18,%ymm17,%ymm16
  56f9cf:	62 a2 0d 28 bc c3    	vfnmadd231ps %ymm19,%ymm14,%ymm16
  56f9d5:	62 31 0c 28 59 f2    	vmulps %ymm18,%ymm14,%ymm14
  56f9db:	62 e1 7c 28 10 52 0c 	vmovups 0x180(%rdx),%ymm18
  56f9e2:	62 32 75 20 b8 f3    	vfmadd231ps %ymm19,%ymm17,%ymm14
  56f9e8:	62 e1 7c 28 10 4a 0d 	vmovups 0x1a0(%rdx),%ymm17
  56f9ef:	62 a1 1c 28 59 da    	vmulps %ymm18,%ymm12,%ymm19
  56f9f5:	62 a2 2d 28 bc d9    	vfnmadd231ps %ymm17,%ymm10,%ymm19
  56f9fb:	62 31 2c 28 59 d2    	vmulps %ymm18,%ymm10,%ymm10
  56fa01:	62 e1 7c 28 10 52 02 	vmovups 0x40(%rdx),%ymm18
  56fa08:	62 32 1d 28 b8 d1    	vfmadd231ps %ymm17,%ymm12,%ymm10
  56fa0e:	c5 7c 10 62 60       	vmovups 0x60(%rdx),%ymm12
  56fa13:	62 a1 04 28 59 ca    	vmulps %ymm18,%ymm15,%ymm17
  56fa19:	62 c2 35 28 bc cc    	vfnmadd231ps %ymm12,%ymm9,%ymm17
  56fa1f:	62 31 34 28 59 ca    	vmulps %ymm18,%ymm9,%ymm9
  56fa25:	62 e1 7c 28 10 52 0a 	vmovups 0x140(%rdx),%ymm18
  56fa2c:	c4 42 05 b8 cc       	vfmadd231ps %ymm12,%ymm15,%ymm9
  56fa31:	c5 7c 10 a2 60 01 00 	vmovups 0x160(%rdx),%ymm12
  56fa38:	00 
  56fa39:	62 31 4c 28 59 fa    	vmulps %ymm18,%ymm6,%ymm15
  56fa3f:	c4 42 55 bc fc       	vfnmadd231ps %ymm12,%ymm5,%ymm15
  56fa44:	62 b1 54 28 59 ea    	vmulps %ymm18,%ymm5,%ymm5
  56fa4a:	62 e1 7c 28 10 52 06 	vmovups 0xc0(%rdx),%ymm18
  56fa51:	c4 c2 4d b8 ec       	vfmadd231ps %ymm12,%ymm6,%ymm5
  56fa56:	c5 fc 10 b2 e0 00 00 	vmovups 0xe0(%rdx),%ymm6
  56fa5d:	00 
  56fa5e:	62 31 44 28 59 e2    	vmulps %ymm18,%ymm7,%ymm12
  56fa64:	c4 62 5d bc e6       	vfnmadd231ps %ymm6,%ymm4,%ymm12
  56fa69:	62 b1 5c 28 59 e2    	vmulps %ymm18,%ymm4,%ymm4
  56fa6f:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  56fa76:	c4 e2 45 b8 e6       	vfmadd231ps %ymm6,%ymm7,%ymm4
  56fa7b:	c5 fc 10 b2 e0 01 00 	vmovups 0x1e0(%rdx),%ymm6
  56fa82:	00 
  56fa83:	62 b1 64 28 59 fa    	vmulps %ymm18,%ymm3,%ymm7
  56fa89:	c4 e2 6d bc fe       	vfnmadd231ps %ymm6,%ymm2,%ymm7
  56fa8e:	62 b1 6c 28 59 d2    	vmulps %ymm18,%ymm2,%ymm2
  56fa94:	c5 f4 c6 c9 d8       	vshufps $0xd8,%ymm1,%ymm1,%ymm1
  56fa99:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  56fa9f:	c4 e2 65 b8 d6       	vfmadd231ps %ymm6,%ymm3,%ymm2
  56faa4:	c4 c1 3c 58 db       	vaddps %ymm11,%ymm8,%ymm3
  56faa9:	62 b1 7c 20 58 f3    	vaddps %ymm19,%ymm16,%ymm6
  56faaf:	c4 41 3c 5c c3       	vsubps %ymm11,%ymm8,%ymm8
  56fab4:	c4 41 0c 58 da       	vaddps %ymm10,%ymm14,%ymm11
  56fab9:	c4 41 0c 5c d2       	vsubps %ymm10,%ymm14,%ymm10
  56fabe:	62 51 74 20 58 f7    	vaddps %ymm15,%ymm17,%ymm14
  56fac4:	62 51 74 20 5c ff    	vsubps %ymm15,%ymm17,%ymm15
  56faca:	62 e1 34 28 58 cd    	vaddps %ymm5,%ymm9,%ymm17
  56fad0:	c5 b4 5c ed          	vsubps %ymm5,%ymm9,%ymm5
  56fad4:	c5 5c 58 ca          	vaddps %ymm2,%ymm4,%ymm9
  56fad8:	c5 dc 5c d2          	vsubps %ymm2,%ymm4,%ymm2
  56fadc:	c5 9c 58 e7          	vaddps %ymm7,%ymm12,%ymm4
  56fae0:	c5 9c 5c ff          	vsubps %ymm7,%ymm12,%ymm7
  56fae4:	c5 14 58 e1          	vaddps %ymm1,%ymm13,%ymm12
  56fae8:	c4 c1 74 5c cd       	vsubps %ymm13,%ymm1,%ymm1
  56faed:	c5 64 58 ee          	vaddps %ymm6,%ymm3,%ymm13
  56faf1:	62 a1 64 20 5c c0    	vsubps %ymm16,%ymm19,%ymm16
  56faf7:	62 e1 04 28 58 d5    	vaddps %ymm5,%ymm15,%ymm18
  56fafd:	c4 c1 54 5c ef       	vsubps %ymm15,%ymm5,%ymm5
  56fb02:	c5 6c 5c ff          	vsubps %ymm7,%ymm2,%ymm15
  56fb06:	c5 c4 58 d2          	vaddps %ymm2,%ymm7,%ymm2
  56fb0a:	c5 8c 58 fc          	vaddps %ymm4,%ymm14,%ymm7
  56fb0e:	62 e1 6c 20 59 d0    	vmulps %ymm0,%ymm18,%ymm18
  56fb14:	c5 04 59 f8          	vmulps %ymm0,%ymm15,%ymm15
  56fb18:	c5 d4 59 e8          	vmulps %ymm0,%ymm5,%ymm5
  56fb1c:	c5 ec 59 d0          	vmulps %ymm0,%ymm2,%ymm2
  56fb20:	62 e1 14 28 58 df    	vaddps %ymm7,%ymm13,%ymm19
  56fb26:	c5 e4 5c de          	vsubps %ymm6,%ymm3,%ymm3
  56fb2a:	62 d1 74 20 58 f1    	vaddps %ymm9,%ymm17,%ymm6
  56fb30:	62 51 74 20 5c c9    	vsubps %ymm9,%ymm17,%ymm9
  56fb36:	62 c1 24 28 58 cc    	vaddps %ymm12,%ymm11,%ymm17
  56fb3c:	c4 41 1c 5c db       	vsubps %ymm11,%ymm12,%ymm11
  56fb41:	62 f1 74 20 58 c6    	vaddps %ymm6,%ymm17,%ymm0
  56fb47:	c4 c1 5c 5c e6       	vsubps %ymm14,%ymm4,%ymm4
  56fb4c:	c4 41 3c 58 e2       	vaddps %ymm10,%ymm8,%ymm12
  56fb51:	c4 41 3c 5c c2       	vsubps %ymm10,%ymm8,%ymm8
  56fb56:	c5 54 5c d2          	vsubps %ymm2,%ymm5,%ymm10
  56fb5a:	c5 d4 58 ea          	vaddps %ymm2,%ymm5,%ymm5
  56fb5e:	62 f1 7c 20 58 d1    	vaddps %ymm1,%ymm16,%ymm2
  56fb64:	62 31 74 28 5c f0    	vsubps %ymm16,%ymm1,%ymm14
  56fb6a:	62 c1 6c 20 58 c7    	vaddps %ymm15,%ymm18,%ymm16
  56fb70:	62 31 04 28 5c fa    	vsubps %ymm18,%ymm15,%ymm15
  56fb76:	62 a1 1c 28 58 d0    	vaddps %ymm16,%ymm12,%ymm18
  56fb7c:	c5 94 5c ff          	vsubps %ymm7,%ymm13,%ymm7
  56fb80:	c5 2c 58 ea          	vaddps %ymm2,%ymm10,%ymm13
  56fb84:	62 f1 74 20 5c ce    	vsubps %ymm6,%ymm17,%ymm1
  56fb8a:	c5 b4 58 f3          	vaddps %ymm3,%ymm9,%ymm6
  56fb8e:	62 31 1c 28 5c e0    	vsubps %ymm16,%ymm12,%ymm12
  56fb94:	62 e1 24 28 58 c4    	vaddps %ymm4,%ymm11,%ymm16
  56fb9a:	c4 c1 6c 5c d2       	vsubps %ymm10,%ymm2,%ymm2
  56fb9f:	c5 3c 58 d5          	vaddps %ymm5,%ymm8,%ymm10
  56fba3:	c4 c1 64 5c d9       	vsubps %ymm9,%ymm3,%ymm3
  56fba8:	c4 41 0c 58 cf       	vaddps %ymm15,%ymm14,%ymm9
  56fbad:	c5 a4 5c e4          	vsubps %ymm4,%ymm11,%ymm4
  56fbb1:	c5 bc 5c ed          	vsubps %ymm5,%ymm8,%ymm5
  56fbb5:	c4 41 0c 5c c7       	vsubps %ymm15,%ymm14,%ymm8
  56fbba:	c5 7c 28 1d 7e 11 b1 	vmovaps -0x4eee82(%rip),%ymm11        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  56fbc1:	ff 
  56fbc2:	c5 7c 28 f0          	vmovaps %ymm0,%ymm14
  56fbc6:	62 32 25 28 7f f3    	vpermt2ps %ymm19,%ymm11,%ymm14
  56fbcc:	c5 7c 28 3d ec ec b0 	vmovaps -0x4f1314(%rip),%ymm15        # 7e8c0 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x4fd0>
  56fbd3:	ff 
  56fbd4:	62 b2 05 28 7f c3    	vpermt2ps %ymm19,%ymm15,%ymm0
  56fbda:	62 c1 7c 28 28 cd    	vmovaps %ymm13,%ymm17
  56fbe0:	62 a2 25 28 7f ca    	vpermt2ps %ymm18,%ymm11,%ymm17
  56fbe6:	62 32 05 28 7f ea    	vpermt2ps %ymm18,%ymm15,%ymm13
  56fbec:	62 a1 7c 28 28 d0    	vmovaps %ymm16,%ymm18
  56fbf2:	62 e2 25 28 7f d6    	vpermt2ps %ymm6,%ymm11,%ymm18
  56fbf8:	62 e2 05 28 7f c6    	vpermt2ps %ymm6,%ymm15,%ymm16
  56fbfe:	c5 7c 29 ce          	vmovaps %ymm9,%ymm6
  56fc02:	62 d2 25 28 7f f2    	vpermt2ps %ymm10,%ymm11,%ymm6
  56fc08:	62 52 05 28 7f ca    	vpermt2ps %ymm10,%ymm15,%ymm9
  56fc0e:	c5 7c 28 d1          	vmovaps %ymm1,%ymm10
  56fc12:	62 72 25 28 7f d7    	vpermt2ps %ymm7,%ymm11,%ymm10
  56fc18:	62 f2 05 28 7f cf    	vpermt2ps %ymm7,%ymm15,%ymm1
  56fc1e:	c5 fc 28 fa          	vmovaps %ymm2,%ymm7
  56fc22:	62 d2 25 28 7f fc    	vpermt2ps %ymm12,%ymm11,%ymm7
  56fc28:	62 d2 05 28 7f d4    	vpermt2ps %ymm12,%ymm15,%ymm2
  56fc2e:	c5 7c 28 e4          	vmovaps %ymm4,%ymm12
  56fc32:	62 72 25 28 7f e3    	vpermt2ps %ymm3,%ymm11,%ymm12
  56fc38:	62 f2 05 28 7f e3    	vpermt2ps %ymm3,%ymm15,%ymm4
  56fc3e:	62 72 3d 28 77 dd    	vpermi2ps %ymm5,%ymm8,%ymm11
  56fc44:	62 72 05 28 7f c5    	vpermt2ps %ymm5,%ymm15,%ymm8
  56fc4a:	c5 7c 11 36          	vmovups %ymm14,(%rsi)
  56fc4e:	c5 fc 11 46 20       	vmovups %ymm0,0x20(%rsi)
  56fc53:	62 e1 7c 28 11 4e 02 	vmovups %ymm17,0x40(%rsi)
  56fc5a:	c5 7c 11 6e 60       	vmovups %ymm13,0x60(%rsi)
  56fc5f:	62 e1 7c 28 11 56 04 	vmovups %ymm18,0x80(%rsi)
  56fc66:	62 e1 7c 28 11 46 05 	vmovups %ymm16,0xa0(%rsi)
  56fc6d:	c5 fc 11 b6 c0 00 00 	vmovups %ymm6,0xc0(%rsi)
  56fc74:	00 
  56fc75:	c5 7c 11 8e e0 00 00 	vmovups %ymm9,0xe0(%rsi)
  56fc7c:	00 
  56fc7d:	c5 7c 11 96 00 01 00 	vmovups %ymm10,0x100(%rsi)
  56fc84:	00 
  56fc85:	c5 fc 11 8e 20 01 00 	vmovups %ymm1,0x120(%rsi)
  56fc8c:	00 
  56fc8d:	c5 fc 11 be 40 01 00 	vmovups %ymm7,0x140(%rsi)
  56fc94:	00 
  56fc95:	c5 fc 11 96 60 01 00 	vmovups %ymm2,0x160(%rsi)
  56fc9c:	00 
  56fc9d:	c5 7c 11 a6 80 01 00 	vmovups %ymm12,0x180(%rsi)
  56fca4:	00 
  56fca5:	c5 fc 11 a6 a0 01 00 	vmovups %ymm4,0x1a0(%rsi)
  56fcac:	00 
  56fcad:	c5 7c 11 9e c0 01 00 	vmovups %ymm11,0x1c0(%rsi)
  56fcb4:	00 
  56fcb5:	c5 7c 11 86 e0 01 00 	vmovups %ymm8,0x1e0(%rsi)
  56fcbc:	00 
  56fcbd:	c5 f8 77             	vzeroupper
  56fcc0:	c3                   	ret
  56fcc1:	cc                   	int3
  56fcc2:	cc                   	int3
  56fcc3:	cc                   	int3
  56fcc4:	cc                   	int3
  56fcc5:	cc                   	int3
  56fcc6:	cc                   	int3
  56fcc7:	cc                   	int3
  56fcc8:	cc                   	int3
  56fcc9:	cc                   	int3
  56fcca:	cc                   	int3
  56fccb:	cc                   	int3
  56fccc:	cc                   	int3
  56fccd:	cc                   	int3
  56fcce:	cc                   	int3
  56fccf:	cc                   	int3


000000000056fcd0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  56fcd0:	c5 fc 10 17          	vmovups (%rdi),%ymm2
  56fcd4:	c5 fc 11 54 24 d8    	vmovups %ymm2,-0x28(%rsp)
  56fcda:	c5 fc 10 5f 20       	vmovups 0x20(%rdi),%ymm3
  56fcdf:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  56fce4:	c5 fc 10 4f 60       	vmovups 0x60(%rdi),%ymm1
  56fce9:	c5 7c 10 a7 80 00 00 	vmovups 0x80(%rdi),%ymm12
  56fcf0:	00 
  56fcf1:	c5 7c 10 af a0 00 00 	vmovups 0xa0(%rdi),%ymm13
  56fcf8:	00 
  56fcf9:	c5 7c 10 97 c0 00 00 	vmovups 0xc0(%rdi),%ymm10
  56fd00:	00 
  56fd01:	c5 7c 10 9f e0 00 00 	vmovups 0xe0(%rdi),%ymm11
  56fd08:	00 
  56fd09:	c5 fc 10 af 00 01 00 	vmovups 0x100(%rdi),%ymm5
  56fd10:	00 
  56fd11:	c5 fc 10 bf 20 01 00 	vmovups 0x120(%rdi),%ymm7
  56fd18:	00 
  56fd19:	c5 7c 10 b7 40 01 00 	vmovups 0x140(%rdi),%ymm14
  56fd20:	00 
  56fd21:	c5 7c 10 bf 60 01 00 	vmovups 0x160(%rdi),%ymm15
  56fd28:	00 
  56fd29:	62 e1 7c 28 10 47 0c 	vmovups 0x180(%rdi),%ymm16
  56fd30:	62 e1 7c 28 10 4f 0d 	vmovups 0x1a0(%rdi),%ymm17
  56fd37:	62 e1 7c 28 10 57 0e 	vmovups 0x1c0(%rdi),%ymm18
  56fd3e:	62 e1 7c 28 10 5f 0f 	vmovups 0x1e0(%rdi),%ymm19
  56fd45:	c5 ec c6 e3 dd       	vshufps $0xdd,%ymm3,%ymm2,%ymm4
  56fd4a:	62 e3 fd 28 01 e4 d8 	vpermpd $0xd8,%ymm4,%ymm20
  56fd51:	c5 d4 c6 e7 dd       	vshufps $0xdd,%ymm7,%ymm5,%ymm4
  56fd56:	62 e3 fd 28 01 ec d8 	vpermpd $0xd8,%ymm4,%ymm21
  56fd5d:	62 a1 5c 20 58 f5    	vaddps %ymm21,%ymm20,%ymm22
  56fd63:	c4 c1 1c c6 e5 dd    	vshufps $0xdd,%ymm13,%ymm12,%ymm4
  56fd69:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  56fd6f:	62 b1 7c 20 c6 f1 dd 	vshufps $0xdd,%ymm17,%ymm16,%ymm6
  56fd76:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  56fd7c:	62 e1 5c 28 58 fe    	vaddps %ymm6,%ymm4,%ymm23
  56fd82:	62 21 4c 20 58 c7    	vaddps %ymm23,%ymm22,%ymm24
  56fd88:	c5 7c c6 c1 dd       	vshufps $0xdd,%ymm1,%ymm0,%ymm8
  56fd8d:	62 43 fd 28 01 c8 d8 	vpermpd $0xd8,%ymm8,%ymm25
  56fd94:	c4 41 0c c6 c7 dd    	vshufps $0xdd,%ymm15,%ymm14,%ymm8
  56fd9a:	62 43 fd 28 01 d0 d8 	vpermpd $0xd8,%ymm8,%ymm26
  56fda1:	62 11 34 20 58 c2    	vaddps %ymm26,%ymm25,%ymm8
  56fda7:	c4 41 2c c6 cb dd    	vshufps $0xdd,%ymm11,%ymm10,%ymm9
  56fdad:	62 43 fd 28 01 d9 d8 	vpermpd $0xd8,%ymm9,%ymm27
  56fdb4:	62 31 6c 20 c6 cb dd 	vshufps $0xdd,%ymm19,%ymm18,%ymm9
  56fdbb:	62 43 fd 28 01 e1 d8 	vpermpd $0xd8,%ymm9,%ymm28
  56fdc2:	62 11 24 20 58 cc    	vaddps %ymm28,%ymm27,%ymm9
  56fdc8:	62 41 3c 28 58 e9    	vaddps %ymm9,%ymm8,%ymm29
  56fdce:	62 01 3c 20 58 f5    	vaddps %ymm29,%ymm24,%ymm30
  56fdd4:	62 01 3c 20 5c c5    	vsubps %ymm29,%ymm24,%ymm24
  56fdda:	62 03 8d 20 23 e8 03 	vshuff64x2 $0x3,%ymm24,%ymm30,%ymm29
  56fde1:	c4 41 2c c6 d3 88    	vshufps $0x88,%ymm11,%ymm10,%ymm10
  56fde7:	62 43 fd 28 01 fa d8 	vpermpd $0xd8,%ymm10,%ymm31
  56fdee:	62 31 6c 20 c6 d3 88 	vshufps $0x88,%ymm19,%ymm18,%ymm10
  56fdf5:	62 c3 fd 28 01 d2 d8 	vpermpd $0xd8,%ymm10,%ymm18
  56fdfc:	62 31 04 20 58 d2    	vaddps %ymm18,%ymm31,%ymm10
  56fe02:	c5 fc c6 c1 88       	vshufps $0x88,%ymm1,%ymm0,%ymm0
  56fe07:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  56fe0d:	c4 c1 0c c6 cf 88    	vshufps $0x88,%ymm15,%ymm14,%ymm1
  56fe13:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  56fe19:	c5 7c 58 d9          	vaddps %ymm1,%ymm0,%ymm11
  56fe1d:	c4 41 2c 5c f3       	vsubps %ymm11,%ymm10,%ymm14
  56fe22:	62 31 4c 20 5c ff    	vsubps %ymm23,%ymm22,%ymm15
  56fe28:	62 c1 0c 28 58 df    	vaddps %ymm15,%ymm14,%ymm19
  56fe2e:	62 c1 04 28 5c f6    	vsubps %ymm14,%ymm15,%ymm22
  56fe34:	62 a3 e5 20 23 fe 03 	vshuff64x2 $0x3,%ymm22,%ymm19,%ymm23
  56fe3b:	62 31 95 20 15 f7    	vunpckhpd %ymm23,%ymm29,%ymm14
  56fe41:	62 31 7c 20 c6 f9 88 	vshufps $0x88,%ymm17,%ymm16,%ymm15
  56fe48:	c4 c3 fd 01 d7 d8    	vpermpd $0xd8,%ymm15,%ymm2
  56fe4e:	c4 41 1c c6 e5 88    	vshufps $0x88,%ymm13,%ymm12,%ymm12
  56fe54:	c4 43 fd 01 ec d8    	vpermpd $0xd8,%ymm12,%ymm13
  56fe5a:	62 c1 6c 28 5c c5    	vsubps %ymm13,%ymm2,%ymm16
  56fe60:	62 a1 5c 20 5c cd    	vsubps %ymm21,%ymm20,%ymm17
  56fe66:	62 a1 7c 20 58 e1    	vaddps %ymm17,%ymm16,%ymm20
  56fe6c:	62 81 34 20 5c ea    	vsubps %ymm26,%ymm25,%ymm21
  56fe72:	c5 fc 5c c9          	vsubps %ymm1,%ymm0,%ymm1
  56fe76:	62 71 54 20 5c e1    	vsubps %ymm1,%ymm21,%ymm12
  56fe7c:	c4 e2 7d 18 05 63 c4 	vbroadcastss -0x4f3b9d(%rip),%ymm0        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  56fe83:	b0 ff 
  56fe85:	c5 1c 59 e0          	vmulps %ymm0,%ymm12,%ymm12
  56fe89:	62 a1 04 20 5c d2    	vsubps %ymm18,%ymm31,%ymm18
  56fe8f:	62 01 24 20 5c cc    	vsubps %ymm28,%ymm27,%ymm25
  56fe95:	62 11 6c 20 58 f9    	vaddps %ymm25,%ymm18,%ymm15
  56fe9b:	c5 04 59 f8          	vmulps %ymm0,%ymm15,%ymm15
  56fe9f:	62 41 1c 28 5c d7    	vsubps %ymm15,%ymm12,%ymm26
  56fea5:	62 01 5c 20 58 da    	vaddps %ymm26,%ymm20,%ymm27
  56feab:	62 81 5c 20 5c e2    	vsubps %ymm26,%ymm20,%ymm20
  56feb1:	62 23 a5 20 23 d4 03 	vshuff64x2 $0x3,%ymm20,%ymm27,%ymm26
  56feb8:	62 a1 74 20 5c c0    	vsubps %ymm16,%ymm17,%ymm16
  56febe:	62 a1 34 20 5c ca    	vsubps %ymm18,%ymm25,%ymm17
  56fec4:	62 61 74 20 59 c8    	vmulps %ymm0,%ymm17,%ymm25
  56feca:	62 b1 74 28 58 cd    	vaddps %ymm21,%ymm1,%ymm1
  56fed0:	62 e1 74 28 59 e8    	vmulps %ymm0,%ymm1,%ymm21
  56fed6:	62 b1 34 20 5c cd    	vsubps %ymm21,%ymm25,%ymm1
  56fedc:	62 61 7c 20 58 e1    	vaddps %ymm1,%ymm16,%ymm28
  56fee2:	62 f1 7c 20 5c c9    	vsubps %ymm1,%ymm16,%ymm1
  56fee8:	62 e3 9d 20 23 c1 03 	vshuff64x2 $0x3,%ymm1,%ymm28,%ymm16
  56feef:	62 a1 ad 20 15 c8    	vunpckhpd %ymm16,%ymm26,%ymm17
  56fef5:	62 a1 0c 28 c6 d1 dd 	vshufps $0xdd,%ymm17,%ymm14,%ymm18
  56fefc:	62 31 0c 28 c6 f1 88 	vshufps $0x88,%ymm17,%ymm14,%ymm14
  56ff03:	62 a1 95 20 14 cf    	vunpcklpd %ymm23,%ymm29,%ymm17
  56ff09:	62 a1 ad 20 14 f8    	vunpcklpd %ymm16,%ymm26,%ymm23
  56ff0f:	62 a1 74 20 c6 c7 dd 	vshufps $0xdd,%ymm23,%ymm17,%ymm16
  56ff16:	62 a1 74 20 c6 cf 88 	vshufps $0x88,%ymm23,%ymm17,%ymm17
  56ff1d:	62 83 0d 20 18 f8 01 	vinsertf32x4 $0x1,%xmm24,%ymm30,%ymm23
  56ff24:	62 a3 65 20 18 de 01 	vinsertf32x4 $0x1,%xmm22,%ymm19,%ymm19
  56ff2b:	62 a1 c5 20 15 f3    	vunpckhpd %ymm19,%ymm23,%ymm22
  56ff31:	62 a3 25 20 18 e4 01 	vinsertf32x4 $0x1,%xmm20,%ymm27,%ymm20
  56ff38:	62 f3 1d 20 18 c9 01 	vinsertf32x4 $0x1,%xmm1,%ymm28,%ymm1
  56ff3f:	62 61 dd 20 15 c1    	vunpckhpd %ymm1,%ymm20,%ymm24
  56ff45:	62 01 4c 20 c6 d0 dd 	vshufps $0xdd,%ymm24,%ymm22,%ymm26
  56ff4c:	62 81 4c 20 c6 f0 88 	vshufps $0x88,%ymm24,%ymm22,%ymm22
  56ff53:	62 a1 c5 20 14 db    	vunpcklpd %ymm19,%ymm23,%ymm19
  56ff59:	62 f1 dd 20 14 c9    	vunpcklpd %ymm1,%ymm20,%ymm1
  56ff5f:	62 e1 64 20 c6 e1 dd 	vshufps $0xdd,%ymm1,%ymm19,%ymm20
  56ff66:	62 f1 64 20 c6 c9 88 	vshufps $0x88,%ymm1,%ymm19,%ymm1
  56ff6d:	62 e1 7c 28 10 9c 24 	vmovups -0x28(%rsp),%ymm19
  56ff74:	d8 ff ff ff 
  56ff78:	62 f1 64 20 c6 db 88 	vshufps $0x88,%ymm3,%ymm19,%ymm3
  56ff7f:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  56ff85:	c5 d4 c6 ef 88       	vshufps $0x88,%ymm7,%ymm5,%ymm5
  56ff8a:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  56ff90:	c5 e4 58 fd          	vaddps %ymm5,%ymm3,%ymm7
  56ff94:	c5 94 58 d2          	vaddps %ymm2,%ymm13,%ymm2
  56ff98:	c5 44 58 ea          	vaddps %ymm2,%ymm7,%ymm13
  56ff9c:	c4 41 24 58 d2       	vaddps %ymm10,%ymm11,%ymm10
  56ffa1:	c4 41 14 58 da       	vaddps %ymm10,%ymm13,%ymm11
  56ffa6:	c4 41 14 5c d2       	vsubps %ymm10,%ymm13,%ymm10
  56ffab:	c4 43 25 06 ea 31    	vperm2f128 $0x31,%ymm10,%ymm11,%ymm13
  56ffb1:	c5 c4 5c d2          	vsubps %ymm2,%ymm7,%ymm2
  56ffb5:	c4 c1 3c 5c f9       	vsubps %ymm9,%ymm8,%ymm7
  56ffba:	c5 6c 58 c7          	vaddps %ymm7,%ymm2,%ymm8
  56ffbe:	c5 ec 5c ff          	vsubps %ymm7,%ymm2,%ymm7
  56ffc2:	c4 e3 3d 06 d7 31    	vperm2f128 $0x31,%ymm7,%ymm8,%ymm2
  56ffc8:	c5 15 15 ca          	vunpckhpd %ymm2,%ymm13,%ymm9
  56ffcc:	c5 e4 5c dd          	vsubps %ymm5,%ymm3,%ymm3
  56ffd0:	c5 dc 5c e6          	vsubps %ymm6,%ymm4,%ymm4
  56ffd4:	c5 e4 58 ec          	vaddps %ymm4,%ymm3,%ymm5
  56ffd8:	62 91 54 20 58 f1    	vaddps %ymm25,%ymm21,%ymm6
  56ffde:	62 e1 54 28 58 de    	vaddps %ymm6,%ymm5,%ymm19
  56ffe4:	62 e1 54 28 5c ee    	vsubps %ymm6,%ymm5,%ymm21
  56ffea:	62 b3 e5 20 23 ed 03 	vshuff64x2 $0x3,%ymm21,%ymm19,%ymm5
  56fff1:	c5 e4 5c dc          	vsubps %ymm4,%ymm3,%ymm3
  56fff5:	c4 c1 1c 58 e7       	vaddps %ymm15,%ymm12,%ymm4
  56fffa:	c5 64 58 fc          	vaddps %ymm4,%ymm3,%ymm15
  56fffe:	62 e1 64 28 5c fc    	vsubps %ymm4,%ymm3,%ymm23
  570004:	62 b3 85 28 23 df 03 	vshuff64x2 $0x3,%ymm23,%ymm15,%ymm3
  57000b:	c5 d5 15 e3          	vunpckhpd %ymm3,%ymm5,%ymm4
  57000f:	c5 b4 c6 f4 dd       	vshufps $0xdd,%ymm4,%ymm9,%ymm6
  570014:	c5 34 c6 e4 88       	vshufps $0x88,%ymm4,%ymm9,%ymm12
  570019:	c5 95 14 d2          	vunpcklpd %ymm2,%ymm13,%ymm2
  57001d:	c5 d5 14 db          	vunpcklpd %ymm3,%ymm5,%ymm3
  570021:	62 61 6c 28 c6 c3 dd 	vshufps $0xdd,%ymm3,%ymm2,%ymm24
  570028:	62 61 6c 28 c6 cb 88 	vshufps $0x88,%ymm3,%ymm2,%ymm25
  57002f:	c4 43 25 18 da 01    	vinsertf128 $0x1,%xmm10,%ymm11,%ymm11
  570035:	62 b1 6c 20 c6 d2 d8 	vshufps $0xd8,%ymm18,%ymm18,%ymm2
  57003c:	c4 41 0c c6 d6 d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm10
  570042:	62 b1 7c 20 c6 e8 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm5
  570049:	62 31 74 20 c6 e9 d8 	vshufps $0xd8,%ymm17,%ymm17,%ymm13
  570050:	62 91 2c 20 c6 e2 d8 	vshufps $0xd8,%ymm26,%ymm26,%ymm4
  570057:	62 31 4c 20 c6 f6 d8 	vshufps $0xd8,%ymm22,%ymm22,%ymm14
  57005e:	62 31 5c 20 c6 cc d8 	vshufps $0xd8,%ymm20,%ymm20,%ymm9
  570065:	c5 cc c6 de d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm3
  57006a:	c4 41 1c c6 e4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm12
  570070:	62 91 3c 20 c6 f0 d8 	vshufps $0xd8,%ymm24,%ymm24,%ymm6
  570077:	62 81 34 20 c6 c1 d8 	vshufps $0xd8,%ymm25,%ymm25,%ymm16
  57007e:	c4 63 3d 18 c7 01    	vinsertf128 $0x1,%xmm7,%ymm8,%ymm8
  570084:	62 c1 a5 28 15 c8    	vunpckhpd %ymm8,%ymm11,%ymm17
  57008a:	62 a3 65 20 18 d5 01 	vinsertf32x4 $0x1,%xmm21,%ymm19,%ymm18
  570091:	62 33 05 28 18 ff 01 	vinsertf32x4 $0x1,%xmm23,%ymm15,%ymm15
  570098:	62 c1 ed 20 15 df    	vunpckhpd %ymm15,%ymm18,%ymm19
  57009e:	62 b1 74 20 c6 fb dd 	vshufps $0xdd,%ymm19,%ymm17,%ymm7
  5700a5:	c5 c4 c6 ff d8       	vshufps $0xd8,%ymm7,%ymm7,%ymm7
  5700aa:	62 a1 74 20 c6 cb 88 	vshufps $0x88,%ymm19,%ymm17,%ymm17
  5700b1:	62 a1 74 20 c6 c9 d8 	vshufps $0xd8,%ymm17,%ymm17,%ymm17
  5700b8:	c4 41 25 14 c0       	vunpcklpd %ymm8,%ymm11,%ymm8
  5700bd:	62 51 ed 20 14 df    	vunpcklpd %ymm15,%ymm18,%ymm11
  5700c3:	c4 41 3c c6 fb dd    	vshufps $0xdd,%ymm11,%ymm8,%ymm15
  5700c9:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  5700cf:	c4 41 3c c6 c3 88    	vshufps $0x88,%ymm11,%ymm8,%ymm8
  5700d5:	62 e1 7c 28 10 52 08 	vmovups 0x100(%rdx),%ymm18
  5700dc:	62 e1 7c 28 10 5a 09 	vmovups 0x120(%rdx),%ymm19
  5700e3:	62 31 7c 20 59 da    	vmulps %ymm18,%ymm16,%ymm11
  5700e9:	62 32 15 28 bc db    	vfnmadd231ps %ymm19,%ymm13,%ymm11
  5700ef:	62 31 14 28 59 ea    	vmulps %ymm18,%ymm13,%ymm13
  5700f5:	62 e1 7c 28 10 52 04 	vmovups 0x80(%rdx),%ymm18
  5700fc:	62 32 7d 20 b8 eb    	vfmadd231ps %ymm19,%ymm16,%ymm13
  570102:	62 e1 7c 28 10 5a 05 	vmovups 0xa0(%rdx),%ymm19
  570109:	62 a1 74 20 59 c2    	vmulps %ymm18,%ymm17,%ymm16
  57010f:	62 a2 0d 28 bc c3    	vfnmadd231ps %ymm19,%ymm14,%ymm16
  570115:	62 31 0c 28 59 f2    	vmulps %ymm18,%ymm14,%ymm14
  57011b:	62 e1 7c 28 10 52 0c 	vmovups 0x180(%rdx),%ymm18
  570122:	62 32 75 20 b8 f3    	vfmadd231ps %ymm19,%ymm17,%ymm14
  570128:	62 e1 7c 28 10 4a 0d 	vmovups 0x1a0(%rdx),%ymm17
  57012f:	62 a1 1c 28 59 da    	vmulps %ymm18,%ymm12,%ymm19
  570135:	62 a2 2d 28 bc d9    	vfnmadd231ps %ymm17,%ymm10,%ymm19
  57013b:	62 31 2c 28 59 d2    	vmulps %ymm18,%ymm10,%ymm10
  570141:	62 e1 7c 28 10 52 02 	vmovups 0x40(%rdx),%ymm18
  570148:	62 32 1d 28 b8 d1    	vfmadd231ps %ymm17,%ymm12,%ymm10
  57014e:	c5 7c 10 62 60       	vmovups 0x60(%rdx),%ymm12
  570153:	62 a1 04 28 59 ca    	vmulps %ymm18,%ymm15,%ymm17
  570159:	62 c2 35 28 bc cc    	vfnmadd231ps %ymm12,%ymm9,%ymm17
  57015f:	62 31 34 28 59 ca    	vmulps %ymm18,%ymm9,%ymm9
  570165:	62 e1 7c 28 10 52 0a 	vmovups 0x140(%rdx),%ymm18
  57016c:	c4 42 05 b8 cc       	vfmadd231ps %ymm12,%ymm15,%ymm9
  570171:	c5 7c 10 a2 60 01 00 	vmovups 0x160(%rdx),%ymm12
  570178:	00 
  570179:	62 31 4c 28 59 fa    	vmulps %ymm18,%ymm6,%ymm15
  57017f:	c4 42 55 bc fc       	vfnmadd231ps %ymm12,%ymm5,%ymm15
  570184:	62 b1 54 28 59 ea    	vmulps %ymm18,%ymm5,%ymm5
  57018a:	62 e1 7c 28 10 52 06 	vmovups 0xc0(%rdx),%ymm18
  570191:	c4 c2 4d b8 ec       	vfmadd231ps %ymm12,%ymm6,%ymm5
  570196:	c5 fc 10 b2 e0 00 00 	vmovups 0xe0(%rdx),%ymm6
  57019d:	00 
  57019e:	62 31 44 28 59 e2    	vmulps %ymm18,%ymm7,%ymm12
  5701a4:	c4 62 5d bc e6       	vfnmadd231ps %ymm6,%ymm4,%ymm12
  5701a9:	62 b1 5c 28 59 e2    	vmulps %ymm18,%ymm4,%ymm4
  5701af:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  5701b6:	c4 e2 45 b8 e6       	vfmadd231ps %ymm6,%ymm7,%ymm4
  5701bb:	c5 fc 10 b2 e0 01 00 	vmovups 0x1e0(%rdx),%ymm6
  5701c2:	00 
  5701c3:	62 b1 64 28 59 fa    	vmulps %ymm18,%ymm3,%ymm7
  5701c9:	c4 e2 6d bc fe       	vfnmadd231ps %ymm6,%ymm2,%ymm7
  5701ce:	62 b1 6c 28 59 d2    	vmulps %ymm18,%ymm2,%ymm2
  5701d4:	c5 f4 c6 c9 d8       	vshufps $0xd8,%ymm1,%ymm1,%ymm1
  5701d9:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  5701df:	c4 e2 65 b8 d6       	vfmadd231ps %ymm6,%ymm3,%ymm2
  5701e4:	c4 c1 3c 58 db       	vaddps %ymm11,%ymm8,%ymm3
  5701e9:	62 b1 7c 20 58 f3    	vaddps %ymm19,%ymm16,%ymm6
  5701ef:	c4 41 3c 5c c3       	vsubps %ymm11,%ymm8,%ymm8
  5701f4:	c4 41 0c 58 da       	vaddps %ymm10,%ymm14,%ymm11
  5701f9:	c4 41 0c 5c d2       	vsubps %ymm10,%ymm14,%ymm10
  5701fe:	62 51 74 20 58 f7    	vaddps %ymm15,%ymm17,%ymm14
  570204:	62 51 74 20 5c ff    	vsubps %ymm15,%ymm17,%ymm15
  57020a:	62 e1 34 28 58 cd    	vaddps %ymm5,%ymm9,%ymm17
  570210:	c5 b4 5c ed          	vsubps %ymm5,%ymm9,%ymm5
  570214:	c5 5c 58 ca          	vaddps %ymm2,%ymm4,%ymm9
  570218:	c5 dc 5c d2          	vsubps %ymm2,%ymm4,%ymm2
  57021c:	c5 9c 58 e7          	vaddps %ymm7,%ymm12,%ymm4
  570220:	c5 9c 5c ff          	vsubps %ymm7,%ymm12,%ymm7
  570224:	c5 14 58 e1          	vaddps %ymm1,%ymm13,%ymm12
  570228:	c4 c1 74 5c cd       	vsubps %ymm13,%ymm1,%ymm1
  57022d:	c5 64 58 ee          	vaddps %ymm6,%ymm3,%ymm13
  570231:	62 a1 64 20 5c c0    	vsubps %ymm16,%ymm19,%ymm16
  570237:	62 e1 04 28 58 d5    	vaddps %ymm5,%ymm15,%ymm18
  57023d:	c4 c1 54 5c ef       	vsubps %ymm15,%ymm5,%ymm5
  570242:	c5 6c 5c ff          	vsubps %ymm7,%ymm2,%ymm15
  570246:	c5 c4 58 d2          	vaddps %ymm2,%ymm7,%ymm2
  57024a:	c5 8c 58 fc          	vaddps %ymm4,%ymm14,%ymm7
  57024e:	62 e1 6c 20 59 d0    	vmulps %ymm0,%ymm18,%ymm18
  570254:	c5 04 59 f8          	vmulps %ymm0,%ymm15,%ymm15
  570258:	c5 d4 59 e8          	vmulps %ymm0,%ymm5,%ymm5
  57025c:	c5 ec 59 d0          	vmulps %ymm0,%ymm2,%ymm2
  570260:	c5 94 58 c7          	vaddps %ymm7,%ymm13,%ymm0
  570264:	c5 e4 5c f6          	vsubps %ymm6,%ymm3,%ymm6
  570268:	62 c1 74 20 58 d9    	vaddps %ymm9,%ymm17,%ymm19
  57026e:	62 51 74 20 5c c9    	vsubps %ymm9,%ymm17,%ymm9
  570274:	62 c1 24 28 58 cc    	vaddps %ymm12,%ymm11,%ymm17
  57027a:	c4 41 1c 5c db       	vsubps %ymm11,%ymm12,%ymm11
  57027f:	62 31 74 20 58 e3    	vaddps %ymm19,%ymm17,%ymm12
  570285:	c4 41 5c 5c f6       	vsubps %ymm14,%ymm4,%ymm14
  57028a:	c4 c1 3c 58 e2       	vaddps %ymm10,%ymm8,%ymm4
  57028f:	c4 41 3c 5c c2       	vsubps %ymm10,%ymm8,%ymm8
  570294:	c5 54 5c d2          	vsubps %ymm2,%ymm5,%ymm10
  570298:	c5 d4 58 ea          	vaddps %ymm2,%ymm5,%ymm5
  57029c:	62 e1 7c 20 58 e1    	vaddps %ymm1,%ymm16,%ymm20
  5702a2:	62 a1 74 28 5c c0    	vsubps %ymm16,%ymm1,%ymm16
  5702a8:	62 d1 6c 20 58 d7    	vaddps %ymm15,%ymm18,%ymm2
  5702ae:	62 31 04 28 5c fa    	vsubps %ymm18,%ymm15,%ymm15
  5702b4:	c5 dc 58 da          	vaddps %ymm2,%ymm4,%ymm3
  5702b8:	c5 94 5c cf          	vsubps %ymm7,%ymm13,%ymm1
  5702bc:	62 d1 5c 20 58 fa    	vaddps %ymm10,%ymm20,%ymm7
  5702c2:	62 31 74 20 5c eb    	vsubps %ymm19,%ymm17,%ymm13
  5702c8:	62 c1 4c 28 58 c9    	vaddps %ymm9,%ymm6,%ymm17
  5702ce:	c5 dc 5c d2          	vsubps %ymm2,%ymm4,%ymm2
  5702d2:	62 c1 24 28 58 d6    	vaddps %ymm14,%ymm11,%ymm18
  5702d8:	62 51 5c 20 5c d2    	vsubps %ymm10,%ymm20,%ymm10
  5702de:	62 e1 3c 28 58 dd    	vaddps %ymm5,%ymm8,%ymm19
  5702e4:	c4 c1 4c 5c e1       	vsubps %ymm9,%ymm6,%ymm4
  5702e9:	62 d1 7c 20 58 f7    	vaddps %ymm15,%ymm16,%ymm6
  5702ef:	c4 41 24 5c ce       	vsubps %ymm14,%ymm11,%ymm9
  5702f4:	c5 bc 5c ed          	vsubps %ymm5,%ymm8,%ymm5
  5702f8:	62 51 7c 20 5c c7    	vsubps %ymm15,%ymm16,%ymm8
  5702fe:	c5 7c 28 1d 3a 0a b1 	vmovaps -0x4ef5c6(%rip),%ymm11        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  570305:	ff 
  570306:	c5 7c 28 f0          	vmovaps %ymm0,%ymm14
  57030a:	62 52 25 28 7f f4    	vpermt2ps %ymm12,%ymm11,%ymm14
  570310:	c5 7c 28 3d a8 e5 b0 	vmovaps -0x4f1a58(%rip),%ymm15        # 7e8c0 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x4fd0>
  570317:	ff 
  570318:	62 d2 05 28 7f c4    	vpermt2ps %ymm12,%ymm15,%ymm0
  57031e:	c5 7c 28 e3          	vmovaps %ymm3,%ymm12
  570322:	62 72 25 28 7f e7    	vpermt2ps %ymm7,%ymm11,%ymm12
  570328:	62 f2 05 28 7f df    	vpermt2ps %ymm7,%ymm15,%ymm3
  57032e:	62 b1 7c 28 28 f9    	vmovaps %ymm17,%ymm7
  570334:	62 b2 25 28 7f fa    	vpermt2ps %ymm18,%ymm11,%ymm7
  57033a:	62 a2 05 28 7f ca    	vpermt2ps %ymm18,%ymm15,%ymm17
  570340:	62 a1 7c 28 28 c3    	vmovaps %ymm19,%ymm16
  570346:	62 e2 25 28 7f c6    	vpermt2ps %ymm6,%ymm11,%ymm16
  57034c:	62 e2 05 28 7f de    	vpermt2ps %ymm6,%ymm15,%ymm19
  570352:	c5 fc 28 f1          	vmovaps %ymm1,%ymm6
  570356:	62 d2 25 28 7f f5    	vpermt2ps %ymm13,%ymm11,%ymm6
  57035c:	62 d2 05 28 7f cd    	vpermt2ps %ymm13,%ymm15,%ymm1
  570362:	c5 7c 28 ea          	vmovaps %ymm2,%ymm13
  570366:	62 52 25 28 7f ea    	vpermt2ps %ymm10,%ymm11,%ymm13
  57036c:	62 d2 05 28 7f d2    	vpermt2ps %ymm10,%ymm15,%ymm2
  570372:	c5 7c 28 d4          	vmovaps %ymm4,%ymm10
  570376:	62 52 25 28 7f d1    	vpermt2ps %ymm9,%ymm11,%ymm10
  57037c:	62 d2 05 28 7f e1    	vpermt2ps %ymm9,%ymm15,%ymm4
  570382:	62 52 55 28 77 d8    	vpermi2ps %ymm8,%ymm5,%ymm11
  570388:	62 d2 05 28 7f e8    	vpermt2ps %ymm8,%ymm15,%ymm5
  57038e:	c5 7c 11 36          	vmovups %ymm14,(%rsi)
  570392:	c5 fc 11 46 20       	vmovups %ymm0,0x20(%rsi)
  570397:	c5 7c 11 66 40       	vmovups %ymm12,0x40(%rsi)
  57039c:	c5 fc 11 5e 60       	vmovups %ymm3,0x60(%rsi)
  5703a1:	c5 fc 11 be 80 00 00 	vmovups %ymm7,0x80(%rsi)
  5703a8:	00 
  5703a9:	62 e1 7c 28 11 4e 05 	vmovups %ymm17,0xa0(%rsi)
  5703b0:	62 e1 7c 28 11 46 06 	vmovups %ymm16,0xc0(%rsi)
  5703b7:	62 e1 7c 28 11 5e 07 	vmovups %ymm19,0xe0(%rsi)
  5703be:	c5 fc 11 b6 00 01 00 	vmovups %ymm6,0x100(%rsi)
  5703c5:	00 
  5703c6:	c5 fc 11 8e 20 01 00 	vmovups %ymm1,0x120(%rsi)
  5703cd:	00 
  5703ce:	c5 7c 11 ae 40 01 00 	vmovups %ymm13,0x140(%rsi)
  5703d5:	00 
  5703d6:	c5 fc 11 96 60 01 00 	vmovups %ymm2,0x160(%rsi)
  5703dd:	00 
  5703de:	c5 7c 11 96 80 01 00 	vmovups %ymm10,0x180(%rsi)
  5703e5:	00 
  5703e6:	c5 fc 11 a6 a0 01 00 	vmovups %ymm4,0x1a0(%rsi)
  5703ed:	00 
  5703ee:	c5 7c 11 9e c0 01 00 	vmovups %ymm11,0x1c0(%rsi)
  5703f5:	00 
  5703f6:	c5 fc 11 ae e0 01 00 	vmovups %ymm5,0x1e0(%rsi)
  5703fd:	00 
  5703fe:	c5 f8 77             	vzeroupper
  570401:	c3                   	ret
  570402:	cc                   	int3
  570403:	cc                   	int3
  570404:	cc                   	int3
  570405:	cc                   	int3
  570406:	cc                   	int3
  570407:	cc                   	int3
  570408:	cc                   	int3
  570409:	cc                   	int3
  57040a:	cc                   	int3
  57040b:	cc                   	int3
  57040c:	cc                   	int3
  57040d:	cc                   	int3
  57040e:	cc                   	int3
  57040f:	cc                   	int3


0000000000570410 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  570410:	c5 fc 10 0f          	vmovups (%rdi),%ymm1
  570414:	c5 fc 10 57 20       	vmovups 0x20(%rdi),%ymm2
  570419:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  57041e:	c5 7c 10 5f 60       	vmovups 0x60(%rdi),%ymm11
  570423:	c5 7c 10 97 80 00 00 	vmovups 0x80(%rdi),%ymm10
  57042a:	00 
  57042b:	c5 7c 10 a7 a0 00 00 	vmovups 0xa0(%rdi),%ymm12
  570432:	00 
  570433:	c5 fc 10 9f c0 00 00 	vmovups 0xc0(%rdi),%ymm3
  57043a:	00 
  57043b:	c5 fc 10 a7 e0 00 00 	vmovups 0xe0(%rdi),%ymm4
  570442:	00 
  570443:	c5 7c 10 af 00 01 00 	vmovups 0x100(%rdi),%ymm13
  57044a:	00 
  57044b:	c5 7c 10 b7 20 01 00 	vmovups 0x120(%rdi),%ymm14
  570452:	00 
  570453:	62 e1 7c 28 10 47 0a 	vmovups 0x140(%rdi),%ymm16
  57045a:	62 e1 7c 28 10 4f 0b 	vmovups 0x160(%rdi),%ymm17
  570461:	c5 f4 c6 ea 88       	vshufps $0x88,%ymm2,%ymm1,%ymm5
  570466:	c4 63 fd 01 fd d8    	vpermpd $0xd8,%ymm5,%ymm15
  57046c:	c4 c1 2c c6 ec 88    	vshufps $0x88,%ymm12,%ymm10,%ymm5
  570472:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  570478:	c4 c1 14 c6 f6 88    	vshufps $0x88,%ymm14,%ymm13,%ymm6
  57047e:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  570484:	62 e1 54 28 58 d6    	vaddps %ymm6,%ymm5,%ymm18
  57048a:	62 a1 04 28 58 da    	vaddps %ymm18,%ymm15,%ymm19
  570490:	c5 e4 c6 fc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm7
  570495:	62 e3 fd 28 01 e7 d8 	vpermpd $0xd8,%ymm7,%ymm20
  57049c:	62 b1 7c 20 c6 f9 88 	vshufps $0x88,%ymm17,%ymm16,%ymm7
  5704a3:	c4 e3 fd 01 ff d8    	vpermpd $0xd8,%ymm7,%ymm7
  5704a9:	c4 41 7c c6 c3 88    	vshufps $0x88,%ymm11,%ymm0,%ymm8
  5704af:	c4 43 fd 01 c8 d8    	vpermpd $0xd8,%ymm8,%ymm9
  5704b5:	62 c1 44 28 58 e9    	vaddps %ymm9,%ymm7,%ymm21
  5704bb:	62 a1 5c 20 58 f5    	vaddps %ymm21,%ymm20,%ymm22
  5704c1:	62 a1 64 20 58 fe    	vaddps %ymm22,%ymm19,%ymm23
  5704c7:	c4 62 7d 18 05 54 bf 	vbroadcastss -0x4f40ac(%rip),%ymm8        # 7c424 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2b34>
  5704ce:	b0 ff 
  5704d0:	62 c2 3d 28 ac d7    	vfnmadd213ps %ymm15,%ymm8,%ymm18
  5704d6:	c4 41 2c c6 d4 dd    	vshufps $0xdd,%ymm12,%ymm10,%ymm10
  5704dc:	c4 43 fd 01 fa d8    	vpermpd $0xd8,%ymm10,%ymm15
  5704e2:	c4 41 14 c6 d6 dd    	vshufps $0xdd,%ymm14,%ymm13,%ymm10
  5704e8:	62 43 fd 28 01 c2 d8 	vpermpd $0xd8,%ymm10,%ymm24
  5704ef:	62 11 04 28 5c e0    	vsubps %ymm24,%ymm15,%ymm12
  5704f5:	c4 62 7d 18 15 66 bc 	vbroadcastss -0x4f439a(%rip),%ymm10        # 7c164 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2874>
  5704fc:	b0 ff 
  5704fe:	c4 41 1c 59 e2       	vmulps %ymm10,%ymm12,%ymm12
  570503:	62 51 6c 20 5c ec    	vsubps %ymm12,%ymm18,%ymm13
  570509:	62 a2 3d 28 ac ec    	vfnmadd213ps %ymm20,%ymm8,%ymm21
  57050f:	62 31 7c 20 c6 f1 dd 	vshufps $0xdd,%ymm17,%ymm16,%ymm14
  570516:	62 c3 fd 28 01 c6 d8 	vpermpd $0xd8,%ymm14,%ymm16
  57051d:	c4 c1 7c c6 c3 dd    	vshufps $0xdd,%ymm11,%ymm0,%ymm0
  570523:	62 e3 fd 28 01 c8 d8 	vpermpd $0xd8,%ymm0,%ymm17
  57052a:	62 b1 7c 20 5c c1    	vsubps %ymm17,%ymm16,%ymm0
  570530:	c5 ac 59 c0          	vmulps %ymm0,%ymm10,%ymm0
  570534:	62 71 54 20 5c d8    	vsubps %ymm0,%ymm21,%ymm11
  57053a:	62 c1 14 28 58 e3    	vaddps %ymm11,%ymm13,%ymm20
  570540:	62 33 c5 20 23 f4 03 	vshuff64x2 $0x3,%ymm20,%ymm23,%ymm14
  570547:	62 31 1c 28 58 e2    	vaddps %ymm18,%ymm12,%ymm12
  57054d:	62 b1 7c 28 58 c5    	vaddps %ymm21,%ymm0,%ymm0
  570553:	62 e1 1c 28 58 d0    	vaddps %ymm0,%ymm12,%ymm18
  570559:	62 a3 7d 28 19 d5 01 	vextractf32x4 $0x1,%ymm18,%xmm21
  570560:	62 21 8d 28 15 cd    	vunpckhpd %ymm21,%ymm14,%ymm25
  570566:	62 41 14 28 5c d3    	vsubps %ymm11,%ymm13,%ymm26
  57056c:	c5 9c 5c c0          	vsubps %ymm0,%ymm12,%ymm0
  570570:	62 73 ad 20 23 e8 03 	vshuff64x2 $0x3,%ymm0,%ymm26,%ymm13
  570577:	62 a1 64 20 5c de    	vsubps %ymm22,%ymm19,%ymm19
  57057d:	62 a3 7d 28 19 de 01 	vextractf32x4 $0x1,%ymm19,%xmm22
  570584:	62 31 95 28 15 e6    	vunpckhpd %ymm22,%ymm13,%ymm12
  57058a:	62 51 34 20 c6 dc dd 	vshufps $0xdd,%ymm12,%ymm25,%ymm11
  570591:	62 51 34 20 c6 e4 88 	vshufps $0x88,%ymm12,%ymm25,%ymm12
  570598:	62 31 8d 28 14 f5    	vunpcklpd %ymm21,%ymm14,%ymm14
  57059e:	62 a1 95 28 14 ee    	vunpcklpd %ymm22,%ymm13,%ymm21
  5705a4:	62 31 0c 28 c6 ed dd 	vshufps $0xdd,%ymm21,%ymm14,%ymm13
  5705ab:	62 31 0c 28 c6 f5 88 	vshufps $0x88,%ymm21,%ymm14,%ymm14
  5705b2:	62 a3 45 20 18 e4 01 	vinsertf32x4 $0x1,%xmm20,%ymm23,%ymm20
  5705b9:	62 a1 7c 08 28 d2    	vmovaps %xmm18,%xmm18
  5705bf:	62 a1 dd 20 15 ea    	vunpckhpd %ymm18,%ymm20,%ymm21
  5705c5:	62 f3 2d 20 18 c0 01 	vinsertf32x4 $0x1,%xmm0,%ymm26,%ymm0
  5705cc:	62 a1 7c 08 28 db    	vmovaps %xmm19,%xmm19
  5705d2:	62 a1 fd 28 15 f3    	vunpckhpd %ymm19,%ymm0,%ymm22
  5705d8:	62 a1 54 20 c6 fe dd 	vshufps $0xdd,%ymm22,%ymm21,%ymm23
  5705df:	62 a1 54 20 c6 ee 88 	vshufps $0x88,%ymm22,%ymm21,%ymm21
  5705e6:	62 a1 dd 20 14 d2    	vunpcklpd %ymm18,%ymm20,%ymm18
  5705ec:	62 b1 fd 28 14 c3    	vunpcklpd %ymm19,%ymm0,%ymm0
  5705f2:	62 e1 6c 20 c6 d8 dd 	vshufps $0xdd,%ymm0,%ymm18,%ymm19
  5705f9:	62 f1 6c 20 c6 c0 88 	vshufps $0x88,%ymm0,%ymm18,%ymm0
  570600:	c5 f4 c6 ca dd       	vshufps $0xdd,%ymm2,%ymm1,%ymm1
  570605:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  57060b:	62 91 04 28 58 d0    	vaddps %ymm24,%ymm15,%ymm2
  570611:	c5 74 58 fa          	vaddps %ymm2,%ymm1,%ymm15
  570615:	c5 e4 c6 dc dd       	vshufps $0xdd,%ymm4,%ymm3,%ymm3
  57061a:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  570620:	62 b1 7c 20 58 e1    	vaddps %ymm17,%ymm16,%ymm4
  570626:	62 e1 64 28 58 c4    	vaddps %ymm4,%ymm3,%ymm16
  57062c:	62 a1 04 28 58 c8    	vaddps %ymm16,%ymm15,%ymm17
  570632:	c4 e2 3d ac d1       	vfnmadd213ps %ymm1,%ymm8,%ymm2
  570637:	c5 d4 5c ce          	vsubps %ymm6,%ymm5,%ymm1
  57063b:	c5 ac 59 c9          	vmulps %ymm1,%ymm10,%ymm1
  57063f:	c5 ec 58 e9          	vaddps %ymm1,%ymm2,%ymm5
  570643:	c4 62 5d ac c3       	vfnmadd213ps %ymm3,%ymm4,%ymm8
  570648:	c4 c1 44 5c d9       	vsubps %ymm9,%ymm7,%ymm3
  57064d:	c5 ac 59 db          	vmulps %ymm3,%ymm10,%ymm3
  570651:	c5 bc 58 e3          	vaddps %ymm3,%ymm8,%ymm4
  570655:	c5 d4 58 fc          	vaddps %ymm4,%ymm5,%ymm7
  570659:	62 f3 f5 20 23 f7 03 	vshuff64x2 $0x3,%ymm7,%ymm17,%ymm6
  570660:	c5 ec 5c c9          	vsubps %ymm1,%ymm2,%ymm1
  570664:	c5 bc 5c d3          	vsubps %ymm3,%ymm8,%ymm2
  570668:	c5 74 58 ca          	vaddps %ymm2,%ymm1,%ymm9
  57066c:	c4 63 7d 19 cb 01    	vextractf128 $0x1,%ymm9,%xmm3
  570672:	c5 4d 15 c3          	vunpckhpd %ymm3,%ymm6,%ymm8
  570676:	62 e1 54 28 5c d4    	vsubps %ymm4,%ymm5,%ymm18
  57067c:	62 e1 74 28 5c e2    	vsubps %ymm2,%ymm1,%ymm20
  570682:	62 b3 ed 20 23 ec 03 	vshuff64x2 $0x3,%ymm20,%ymm18,%ymm5
  570689:	62 31 04 28 5c f8    	vsubps %ymm16,%ymm15,%ymm15
  57068f:	62 33 7d 28 19 f8 01 	vextractf32x4 $0x1,%ymm15,%xmm16
  570696:	62 b1 d5 28 15 c8    	vunpckhpd %ymm16,%ymm5,%ymm1
  57069c:	c5 bc c6 d1 dd       	vshufps $0xdd,%ymm1,%ymm8,%ymm2
  5706a1:	c5 3c c6 d1 88       	vshufps $0x88,%ymm1,%ymm8,%ymm10
  5706a6:	62 e1 cd 28 14 f3    	vunpcklpd %ymm3,%ymm6,%ymm22
  5706ac:	c4 c1 24 c6 cb d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm1
  5706b2:	c4 41 1c c6 c4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm8
  5706b8:	c4 c1 14 c6 e5 d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm4
  5706be:	c4 41 0c c6 ee d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm13
  5706c4:	62 b1 44 20 c6 df d8 	vshufps $0xd8,%ymm23,%ymm23,%ymm3
  5706cb:	62 31 54 20 c6 e5 d8 	vshufps $0xd8,%ymm21,%ymm21,%ymm12
  5706d2:	62 b1 64 20 c6 f3 d8 	vshufps $0xd8,%ymm19,%ymm19,%ymm6
  5706d9:	c5 ec c6 d2 d8       	vshufps $0xd8,%ymm2,%ymm2,%ymm2
  5706de:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  5706e4:	62 31 d5 28 14 d8    	vunpcklpd %ymm16,%ymm5,%ymm11
  5706ea:	62 d1 4c 20 c6 eb dd 	vshufps $0xdd,%ymm11,%ymm22,%ymm5
  5706f1:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  5706f6:	62 51 4c 20 c6 db 88 	vshufps $0x88,%ymm11,%ymm22,%ymm11
  5706fd:	c4 41 24 c6 f3 d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm14
  570703:	62 73 75 20 18 df 01 	vinsertf32x4 $0x1,%xmm7,%ymm17,%ymm11
  57070a:	c4 41 78 28 c9       	vmovaps %xmm9,%xmm9
  57070f:	62 c1 a5 28 15 c1    	vunpckhpd %ymm9,%ymm11,%ymm16
  570715:	62 a3 6d 20 18 cc 01 	vinsertf32x4 $0x1,%xmm20,%ymm18,%ymm17
  57071c:	c4 41 78 28 ff       	vmovaps %xmm15,%xmm15
  570721:	62 c1 f5 20 15 d7    	vunpckhpd %ymm15,%ymm17,%ymm18
  570727:	62 b1 7c 20 c6 fa dd 	vshufps $0xdd,%ymm18,%ymm16,%ymm7
  57072e:	c5 c4 c6 ff d8       	vshufps $0xd8,%ymm7,%ymm7,%ymm7
  570733:	62 a1 7c 20 c6 c2 88 	vshufps $0x88,%ymm18,%ymm16,%ymm16
  57073a:	62 a1 7c 20 c6 c0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm16
  570741:	c4 41 25 14 c9       	vunpcklpd %ymm9,%ymm11,%ymm9
  570746:	62 51 f5 20 14 df    	vunpcklpd %ymm15,%ymm17,%ymm11
  57074c:	c4 41 34 c6 fb dd    	vshufps $0xdd,%ymm11,%ymm9,%ymm15
  570752:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  570758:	c4 41 34 c6 cb 88    	vshufps $0x88,%ymm11,%ymm9,%ymm9
  57075e:	62 e1 7c 28 10 4a 08 	vmovups 0x100(%rdx),%ymm17
  570765:	62 e1 7c 28 10 52 09 	vmovups 0x120(%rdx),%ymm18
  57076c:	62 31 0c 28 59 d9    	vmulps %ymm17,%ymm14,%ymm11
  570772:	62 32 15 28 bc da    	vfnmadd231ps %ymm18,%ymm13,%ymm11
  570778:	62 31 14 28 59 e9    	vmulps %ymm17,%ymm13,%ymm13
  57077e:	62 e1 7c 28 10 4a 04 	vmovups 0x80(%rdx),%ymm17
  570785:	62 32 0d 28 b8 ea    	vfmadd231ps %ymm18,%ymm14,%ymm13
  57078b:	62 e1 7c 28 10 52 05 	vmovups 0xa0(%rdx),%ymm18
  570792:	62 31 7c 20 59 f1    	vmulps %ymm17,%ymm16,%ymm14
  570798:	62 32 1d 28 bc f2    	vfnmadd231ps %ymm18,%ymm12,%ymm14
  57079e:	62 a1 1c 28 59 c9    	vmulps %ymm17,%ymm12,%ymm17
  5707a4:	62 e1 7c 28 10 5a 0c 	vmovups 0x180(%rdx),%ymm19
  5707ab:	62 a2 7d 20 b8 ca    	vfmadd231ps %ymm18,%ymm16,%ymm17
  5707b1:	62 e1 7c 28 10 42 0d 	vmovups 0x1a0(%rdx),%ymm16
  5707b8:	62 31 2c 28 59 e3    	vmulps %ymm19,%ymm10,%ymm12
  5707be:	62 32 3d 28 bc e0    	vfnmadd231ps %ymm16,%ymm8,%ymm12
  5707c4:	62 31 3c 28 59 c3    	vmulps %ymm19,%ymm8,%ymm8
  5707ca:	62 e1 7c 28 10 52 02 	vmovups 0x40(%rdx),%ymm18
  5707d1:	62 32 2d 28 b8 c0    	vfmadd231ps %ymm16,%ymm10,%ymm8
  5707d7:	c5 7c 10 52 60       	vmovups 0x60(%rdx),%ymm10
  5707dc:	62 a1 04 28 59 c2    	vmulps %ymm18,%ymm15,%ymm16
  5707e2:	62 c2 4d 28 bc c2    	vfnmadd231ps %ymm10,%ymm6,%ymm16
  5707e8:	62 b1 4c 28 59 f2    	vmulps %ymm18,%ymm6,%ymm6
  5707ee:	62 e1 7c 28 10 52 0a 	vmovups 0x140(%rdx),%ymm18
  5707f5:	c4 c2 05 b8 f2       	vfmadd231ps %ymm10,%ymm15,%ymm6
  5707fa:	c5 7c 10 92 60 01 00 	vmovups 0x160(%rdx),%ymm10
  570801:	00 
  570802:	62 31 54 28 59 fa    	vmulps %ymm18,%ymm5,%ymm15
  570808:	c4 42 5d bc fa       	vfnmadd231ps %ymm10,%ymm4,%ymm15
  57080d:	62 b1 5c 28 59 e2    	vmulps %ymm18,%ymm4,%ymm4
  570813:	62 e1 7c 28 10 52 06 	vmovups 0xc0(%rdx),%ymm18
  57081a:	c4 c2 55 b8 e2       	vfmadd231ps %ymm10,%ymm5,%ymm4
  57081f:	c5 fc 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm5
  570826:	00 
  570827:	62 31 44 28 59 d2    	vmulps %ymm18,%ymm7,%ymm10
  57082d:	c4 62 65 bc d5       	vfnmadd231ps %ymm5,%ymm3,%ymm10
  570832:	62 b1 64 28 59 da    	vmulps %ymm18,%ymm3,%ymm3
  570838:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  57083f:	c4 e2 45 b8 dd       	vfmadd231ps %ymm5,%ymm7,%ymm3
  570844:	c5 fc 10 aa e0 01 00 	vmovups 0x1e0(%rdx),%ymm5
  57084b:	00 
  57084c:	62 b1 6c 28 59 fa    	vmulps %ymm18,%ymm2,%ymm7
  570852:	c4 e2 75 bc fd       	vfnmadd231ps %ymm5,%ymm1,%ymm7
  570857:	62 b1 74 28 59 ca    	vmulps %ymm18,%ymm1,%ymm1
  57085d:	c5 fc c6 c0 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm0
  570862:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  570868:	c4 e2 6d b8 cd       	vfmadd231ps %ymm5,%ymm2,%ymm1
  57086d:	c4 c1 34 58 d3       	vaddps %ymm11,%ymm9,%ymm2
  570872:	c4 c1 0c 58 ec       	vaddps %ymm12,%ymm14,%ymm5
  570877:	c4 41 34 5c cb       	vsubps %ymm11,%ymm9,%ymm9
  57087c:	62 51 74 20 58 d8    	vaddps %ymm8,%ymm17,%ymm11
  570882:	62 51 74 20 5c c0    	vsubps %ymm8,%ymm17,%ymm8
  570888:	62 c1 7c 20 58 cf    	vaddps %ymm15,%ymm16,%ymm17
  57088e:	62 51 7c 20 5c ff    	vsubps %ymm15,%ymm16,%ymm15
  570894:	62 e1 4c 28 58 c4    	vaddps %ymm4,%ymm6,%ymm16
  57089a:	c5 cc 5c e4          	vsubps %ymm4,%ymm6,%ymm4
  57089e:	c5 e4 58 f1          	vaddps %ymm1,%ymm3,%ymm6
  5708a2:	c5 e4 5c c9          	vsubps %ymm1,%ymm3,%ymm1
  5708a6:	c5 ac 58 df          	vaddps %ymm7,%ymm10,%ymm3
  5708aa:	c5 ac 5c ff          	vsubps %ymm7,%ymm10,%ymm7
  5708ae:	c5 14 58 d0          	vaddps %ymm0,%ymm13,%ymm10
  5708b2:	c4 c1 7c 5c c5       	vsubps %ymm13,%ymm0,%ymm0
  5708b7:	c5 6c 58 ed          	vaddps %ymm5,%ymm2,%ymm13
  5708bb:	c4 41 1c 5c e6       	vsubps %ymm14,%ymm12,%ymm12
  5708c0:	c5 04 58 f4          	vaddps %ymm4,%ymm15,%ymm14
  5708c4:	c4 c1 5c 5c e7       	vsubps %ymm15,%ymm4,%ymm4
  5708c9:	c5 74 5c ff          	vsubps %ymm7,%ymm1,%ymm15
  5708cd:	c5 c4 58 c9          	vaddps %ymm1,%ymm7,%ymm1
  5708d1:	c4 e2 7d 18 3d 0e ba 	vbroadcastss -0x4f45f2(%rip),%ymm7        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  5708d8:	b0 ff 
  5708da:	c5 0c 59 f7          	vmulps %ymm7,%ymm14,%ymm14
  5708de:	c5 04 59 ff          	vmulps %ymm7,%ymm15,%ymm15
  5708e2:	c5 dc 59 e7          	vmulps %ymm7,%ymm4,%ymm4
  5708e6:	c5 f4 59 cf          	vmulps %ymm7,%ymm1,%ymm1
  5708ea:	62 f1 74 20 58 fb    	vaddps %ymm3,%ymm17,%ymm7
  5708f0:	c5 ec 5c d5          	vsubps %ymm5,%ymm2,%ymm2
  5708f4:	62 f1 7c 20 58 ee    	vaddps %ymm6,%ymm16,%ymm5
  5708fa:	62 f1 7c 20 5c f6    	vsubps %ymm6,%ymm16,%ymm6
  570900:	62 c1 24 28 58 c2    	vaddps %ymm10,%ymm11,%ymm16
  570906:	c4 41 2c 5c d3       	vsubps %ymm11,%ymm10,%ymm10
  57090b:	c5 14 58 df          	vaddps %ymm7,%ymm13,%ymm11
  57090f:	62 b1 64 28 5c d9    	vsubps %ymm17,%ymm3,%ymm3
  570915:	62 c1 34 28 58 c8    	vaddps %ymm8,%ymm9,%ymm17
  57091b:	c4 41 34 5c c0       	vsubps %ymm8,%ymm9,%ymm8
  570920:	c5 5c 5c c9          	vsubps %ymm1,%ymm4,%ymm9
  570924:	c5 dc 58 c9          	vaddps %ymm1,%ymm4,%ymm1
  570928:	c5 9c 58 e0          	vaddps %ymm0,%ymm12,%ymm4
  57092c:	c4 c1 7c 5c c4       	vsubps %ymm12,%ymm0,%ymm0
  570931:	c4 41 0c 58 e7       	vaddps %ymm15,%ymm14,%ymm12
  570936:	c4 41 04 5c f6       	vsubps %ymm14,%ymm15,%ymm14
  57093b:	62 71 7c 20 58 fd    	vaddps %ymm5,%ymm16,%ymm15
  570941:	c5 94 5c ff          	vsubps %ymm7,%ymm13,%ymm7
  570945:	62 51 74 20 58 ec    	vaddps %ymm12,%ymm17,%ymm13
  57094b:	62 f1 7c 20 5c ed    	vsubps %ymm5,%ymm16,%ymm5
  570951:	62 c1 5c 28 58 c1    	vaddps %ymm9,%ymm4,%ymm16
  570957:	62 51 74 20 5c e4    	vsubps %ymm12,%ymm17,%ymm12
  57095d:	62 e1 6c 28 58 ce    	vaddps %ymm6,%ymm2,%ymm17
  570963:	c4 c1 5c 5c e1       	vsubps %ymm9,%ymm4,%ymm4
  570968:	c5 2c 58 cb          	vaddps %ymm3,%ymm10,%ymm9
  57096c:	c5 ec 5c d6          	vsubps %ymm6,%ymm2,%ymm2
  570970:	c5 bc 58 f1          	vaddps %ymm1,%ymm8,%ymm6
  570974:	c5 ac 5c db          	vsubps %ymm3,%ymm10,%ymm3
  570978:	c5 0c 58 d0          	vaddps %ymm0,%ymm14,%ymm10
  57097c:	c5 bc 5c c9          	vsubps %ymm1,%ymm8,%ymm1
  570980:	c4 c1 7c 5c c6       	vsubps %ymm14,%ymm0,%ymm0
  570985:	c5 7c 28 05 b3 03 b1 	vmovaps -0x4efc4d(%rip),%ymm8        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  57098c:	ff 
  57098d:	c4 43 7d 19 fe 01    	vextractf128 $0x1,%ymm15,%xmm14
  570993:	62 52 3d 28 7f fb    	vpermt2ps %ymm11,%ymm8,%ymm15
  570999:	c5 7c 11 3e          	vmovups %ymm15,(%rsi)
  57099d:	c4 43 7d 19 db 01    	vextractf128 $0x1,%ymm11,%xmm11
  5709a3:	c4 41 08 14 db       	vunpcklps %xmm11,%xmm14,%xmm11
  5709a8:	c5 78 11 5e 20       	vmovups %xmm11,0x20(%rsi)
  5709ad:	62 c3 7d 28 19 c3 01 	vextractf32x4 $0x1,%ymm16,%xmm11
  5709b4:	62 c2 3d 28 7f c5    	vpermt2ps %ymm13,%ymm8,%ymm16
  5709ba:	62 e1 7c 28 11 86 30 	vmovups %ymm16,0x30(%rsi)
  5709c1:	00 00 00 
  5709c4:	c4 43 7d 19 ed 01    	vextractf128 $0x1,%ymm13,%xmm13
  5709ca:	c4 41 20 14 dd       	vunpcklps %xmm13,%xmm11,%xmm11
  5709cf:	c5 78 11 5e 50       	vmovups %xmm11,0x50(%rsi)
  5709d4:	c4 43 7d 19 cb 01    	vextractf128 $0x1,%ymm9,%xmm11
  5709da:	62 32 3d 28 7f c9    	vpermt2ps %ymm17,%ymm8,%ymm9
  5709e0:	c5 7c 11 4e 60       	vmovups %ymm9,0x60(%rsi)
  5709e5:	62 c3 7d 28 19 c9 01 	vextractf32x4 $0x1,%ymm17,%xmm9
  5709ec:	c4 41 20 14 c9       	vunpcklps %xmm9,%xmm11,%xmm9
  5709f1:	c5 78 11 8e 80 00 00 	vmovups %xmm9,0x80(%rsi)
  5709f8:	00 
  5709f9:	c4 43 7d 19 d1 01    	vextractf128 $0x1,%ymm10,%xmm9
  5709ff:	62 72 3d 28 7f d6    	vpermt2ps %ymm6,%ymm8,%ymm10
  570a05:	c5 7c 11 96 90 00 00 	vmovups %ymm10,0x90(%rsi)
  570a0c:	00 
  570a0d:	c4 e3 7d 19 f6 01    	vextractf128 $0x1,%ymm6,%xmm6
  570a13:	c5 b0 14 f6          	vunpcklps %xmm6,%xmm9,%xmm6
  570a17:	c5 f8 11 b6 b0 00 00 	vmovups %xmm6,0xb0(%rsi)
  570a1e:	00 
  570a1f:	c4 e3 7d 19 ee 01    	vextractf128 $0x1,%ymm5,%xmm6
  570a25:	62 f2 3d 28 7f ef    	vpermt2ps %ymm7,%ymm8,%ymm5
  570a2b:	c5 fc 11 ae c0 00 00 	vmovups %ymm5,0xc0(%rsi)
  570a32:	00 
  570a33:	c4 e3 7d 19 fd 01    	vextractf128 $0x1,%ymm7,%xmm5
  570a39:	c5 c8 14 ed          	vunpcklps %xmm5,%xmm6,%xmm5
  570a3d:	c5 f8 11 ae e0 00 00 	vmovups %xmm5,0xe0(%rsi)
  570a44:	00 
  570a45:	c4 e3 7d 19 e5 01    	vextractf128 $0x1,%ymm4,%xmm5
  570a4b:	62 d2 3d 28 7f e4    	vpermt2ps %ymm12,%ymm8,%ymm4
  570a51:	c5 fc 11 a6 f0 00 00 	vmovups %ymm4,0xf0(%rsi)
  570a58:	00 
  570a59:	c4 63 7d 19 e4 01    	vextractf128 $0x1,%ymm12,%xmm4
  570a5f:	c5 d0 14 e4          	vunpcklps %xmm4,%xmm5,%xmm4
  570a63:	c5 f8 11 a6 10 01 00 	vmovups %xmm4,0x110(%rsi)
  570a6a:	00 
  570a6b:	c4 e3 7d 19 dc 01    	vextractf128 $0x1,%ymm3,%xmm4
  570a71:	62 f2 3d 28 7f da    	vpermt2ps %ymm2,%ymm8,%ymm3
  570a77:	c5 fc 11 9e 20 01 00 	vmovups %ymm3,0x120(%rsi)
  570a7e:	00 
  570a7f:	c4 e3 7d 19 d2 01    	vextractf128 $0x1,%ymm2,%xmm2
  570a85:	c5 d8 14 d2          	vunpcklps %xmm2,%xmm4,%xmm2
  570a89:	c5 f8 11 96 40 01 00 	vmovups %xmm2,0x140(%rsi)
  570a90:	00 
  570a91:	62 72 7d 28 77 c1    	vpermi2ps %ymm1,%ymm0,%ymm8
  570a97:	c5 7c 11 86 50 01 00 	vmovups %ymm8,0x150(%rsi)
  570a9e:	00 
  570a9f:	c4 e3 7d 19 c9 01    	vextractf128 $0x1,%ymm1,%xmm1
  570aa5:	c4 e3 7d 19 c0 01    	vextractf128 $0x1,%ymm0,%xmm0
  570aab:	c5 f8 14 c1          	vunpcklps %xmm1,%xmm0,%xmm0
  570aaf:	c5 f8 11 86 70 01 00 	vmovups %xmm0,0x170(%rsi)
  570ab6:	00 
  570ab7:	c5 f8 77             	vzeroupper
  570aba:	c3                   	ret
  570abb:	cc                   	int3
  570abc:	cc                   	int3
  570abd:	cc                   	int3
  570abe:	cc                   	int3
  570abf:	cc                   	int3


0000000000570ac0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  570ac0:	c5 7c 10 17          	vmovups (%rdi),%ymm10
  570ac4:	c5 7c 10 5f 20       	vmovups 0x20(%rdi),%ymm11
  570ac9:	c5 fc 10 67 40       	vmovups 0x40(%rdi),%ymm4
  570ace:	c5 fc 10 77 60       	vmovups 0x60(%rdi),%ymm6
  570ad3:	c5 7c 10 87 80 00 00 	vmovups 0x80(%rdi),%ymm8
  570ada:	00 
  570adb:	c5 7c 10 8f a0 00 00 	vmovups 0xa0(%rdi),%ymm9
  570ae2:	00 
  570ae3:	c5 7c 10 a7 c0 00 00 	vmovups 0xc0(%rdi),%ymm12
  570aea:	00 
  570aeb:	c5 7c 10 af e0 00 00 	vmovups 0xe0(%rdi),%ymm13
  570af2:	00 
  570af3:	62 e1 7c 28 10 4f 08 	vmovups 0x100(%rdi),%ymm17
  570afa:	62 e1 7c 28 10 67 09 	vmovups 0x120(%rdi),%ymm20
  570b01:	62 e1 7c 28 10 6f 0a 	vmovups 0x140(%rdi),%ymm21
  570b08:	62 e1 7c 28 10 77 0b 	vmovups 0x160(%rdi),%ymm22
  570b0f:	62 61 7c 28 10 47 0c 	vmovups 0x180(%rdi),%ymm24
  570b16:	62 61 7c 28 10 4f 0d 	vmovups 0x1a0(%rdi),%ymm25
  570b1d:	c4 c1 2c c6 c3 dd    	vshufps $0xdd,%ymm11,%ymm10,%ymm0
  570b23:	62 e3 fd 28 01 c0 d8 	vpermpd $0xd8,%ymm0,%ymm16
  570b2a:	c5 dc c6 c6 dd       	vshufps $0xdd,%ymm6,%ymm4,%ymm0
  570b2f:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  570b35:	c5 fc 11 44 24 b8    	vmovups %ymm0,-0x48(%rsp)
  570b3b:	62 91 3c 20 c6 c9 dd 	vshufps $0xdd,%ymm25,%ymm24,%ymm1
  570b42:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  570b48:	c5 fc 11 4c 24 d8    	vmovups %ymm1,-0x28(%rsp)
  570b4e:	c5 7c 58 f1          	vaddps %ymm1,%ymm0,%ymm14
  570b52:	62 d1 7c 20 58 ee    	vaddps %ymm14,%ymm16,%ymm5
  570b58:	c4 c1 3c c6 d1 dd    	vshufps $0xdd,%ymm9,%ymm8,%ymm2
  570b5e:	c4 e3 fd 01 d2 d8    	vpermpd $0xd8,%ymm2,%ymm2
  570b64:	62 b1 54 20 c6 de dd 	vshufps $0xdd,%ymm22,%ymm21,%ymm3
  570b6b:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  570b71:	62 e1 6c 28 58 d3    	vaddps %ymm3,%ymm2,%ymm18
  570b77:	62 31 54 28 58 fa    	vaddps %ymm18,%ymm5,%ymm15
  570b7d:	c4 c1 1c c6 ed dd    	vshufps $0xdd,%ymm13,%ymm12,%ymm5
  570b83:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  570b89:	62 b1 74 20 c6 fc dd 	vshufps $0xdd,%ymm20,%ymm17,%ymm7
  570b90:	c4 e3 fd 01 ff d8    	vpermpd $0xd8,%ymm7,%ymm7
  570b96:	62 e1 54 28 58 df    	vaddps %ymm7,%ymm5,%ymm19
  570b9c:	62 a1 04 28 58 fb    	vaddps %ymm19,%ymm15,%ymm23
  570ba2:	c4 41 1c c6 e5 88    	vshufps $0x88,%ymm13,%ymm12,%ymm12
  570ba8:	c4 43 fd 01 fc d8    	vpermpd $0xd8,%ymm12,%ymm15
  570bae:	62 31 74 20 c6 e4 88 	vshufps $0x88,%ymm20,%ymm17,%ymm12
  570bb5:	62 c3 fd 28 01 cc d8 	vpermpd $0xd8,%ymm12,%ymm17
  570bbc:	62 21 04 28 5c d1    	vsubps %ymm17,%ymm15,%ymm26
  570bc2:	c4 41 3c c6 c1 88    	vshufps $0x88,%ymm9,%ymm8,%ymm8
  570bc8:	62 c3 fd 28 01 e0 d8 	vpermpd $0xd8,%ymm8,%ymm20
  570bcf:	62 31 54 20 c6 c6 88 	vshufps $0x88,%ymm22,%ymm21,%ymm8
  570bd6:	62 c3 fd 28 01 e8 d8 	vpermpd $0xd8,%ymm8,%ymm21
  570bdd:	62 21 5c 20 5c dd    	vsubps %ymm21,%ymm20,%ymm27
  570be3:	c5 dc c6 e6 88       	vshufps $0x88,%ymm6,%ymm4,%ymm4
  570be8:	62 e3 fd 28 01 f4 d8 	vpermpd $0xd8,%ymm4,%ymm22
  570bef:	62 91 3c 20 c6 e1 88 	vshufps $0x88,%ymm25,%ymm24,%ymm4
  570bf6:	62 63 fd 28 01 c4 d8 	vpermpd $0xd8,%ymm4,%ymm24
  570bfd:	62 01 4c 20 5c c8    	vsubps %ymm24,%ymm22,%ymm25
  570c03:	c4 e2 7d 18 25 bc ba 	vbroadcastss -0x4f4544(%rip),%ymm4        # 7c6c8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2dd8>
  570c0a:	b0 ff 
  570c0c:	62 61 34 20 59 e4    	vmulps %ymm4,%ymm25,%ymm28
  570c12:	c4 e2 7d 18 35 69 bb 	vbroadcastss -0x4f4497(%rip),%ymm6        # 7c784 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2e94>
  570c19:	b0 ff 
  570c1b:	c4 62 7d 18 0d 40 b8 	vbroadcastss -0x4f47c0(%rip),%ymm9        # 7c464 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2b74>
  570c22:	b0 ff 
  570c24:	62 62 25 20 bc e6    	vfnmadd231ps %ymm6,%ymm27,%ymm28
  570c2a:	62 42 2d 20 b8 e1    	vfmadd231ps %ymm9,%ymm26,%ymm28
  570c30:	c4 62 7d 18 25 7f ba 	vbroadcastss -0x4f4581(%rip),%ymm12        # 7c6b8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2dc8>
  570c37:	b0 ff 
  570c39:	62 41 7c 28 28 ec    	vmovaps %ymm12,%ymm29
  570c3f:	62 22 0d 28 ac e8    	vfnmadd213ps %ymm16,%ymm14,%ymm29
  570c45:	c4 62 7d 18 05 86 ba 	vbroadcastss -0x4f457a(%rip),%ymm8        # 7c6d4 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2de4>
  570c4c:	b0 ff 
  570c4e:	62 42 6d 20 b8 e8    	vfmadd231ps %ymm8,%ymm18,%ymm29
  570c54:	c4 62 7d 18 2d e7 b4 	vbroadcastss -0x4f4b19(%rip),%ymm13        # 7c144 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2854>
  570c5b:	b0 ff 
  570c5d:	62 42 65 20 bc ed    	vfnmadd231ps %ymm13,%ymm19,%ymm29
  570c63:	62 01 1c 20 58 f5    	vaddps %ymm29,%ymm28,%ymm30
  570c69:	62 41 34 20 59 f9    	vmulps %ymm9,%ymm25,%ymm31
  570c6f:	62 62 25 20 bc fc    	vfnmadd231ps %ymm4,%ymm27,%ymm31
  570c75:	62 41 24 20 59 d9    	vmulps %ymm9,%ymm27,%ymm27
  570c7b:	62 02 4d 28 b8 d9    	vfmadd231ps %ymm25,%ymm6,%ymm27
  570c81:	62 03 c5 20 23 ce 03 	vshuff64x2 $0x3,%ymm30,%ymm23,%ymm25
  570c88:	62 62 2d 20 bc fe    	vfnmadd231ps %ymm6,%ymm26,%ymm31
  570c8e:	62 02 5d 28 b8 da    	vfmadd231ps %ymm26,%ymm4,%ymm27
  570c94:	62 41 7c 28 28 d5    	vmovaps %ymm13,%ymm26
  570c9a:	62 22 0d 28 ac d0    	vfnmadd213ps %ymm16,%ymm14,%ymm26
  570ca0:	62 42 6d 20 bc d4    	vfnmadd231ps %ymm12,%ymm18,%ymm26
  570ca6:	62 42 65 20 b8 d0    	vfmadd231ps %ymm8,%ymm19,%ymm26
  570cac:	62 32 3d 28 a8 f0    	vfmadd213ps %ymm16,%ymm8,%ymm14
  570cb2:	62 81 2c 20 5c c7    	vsubps %ymm31,%ymm26,%ymm16
  570cb8:	62 32 15 28 bc f2    	vfnmadd231ps %ymm18,%ymm13,%ymm14
  570cbe:	62 32 1d 28 bc f3    	vfnmadd231ps %ymm19,%ymm12,%ymm14
  570cc4:	62 c1 24 20 58 d6    	vaddps %ymm14,%ymm27,%ymm18
  570cca:	62 a3 fd 20 23 da 03 	vshuff64x2 $0x3,%ymm18,%ymm16,%ymm19
  570cd1:	62 01 0c 28 5c db    	vsubps %ymm27,%ymm14,%ymm27
  570cd7:	62 31 b5 20 15 f3    	vunpckhpd %ymm19,%ymm25,%ymm14
  570cdd:	62 01 04 20 58 d2    	vaddps %ymm26,%ymm31,%ymm26
  570ce3:	62 93 a5 20 23 ca 03 	vshuff64x2 $0x3,%ymm26,%ymm27,%ymm1
  570cea:	62 01 14 20 5c e4    	vsubps %ymm28,%ymm29,%ymm28
  570cf0:	62 03 7d 28 19 e5 01 	vextractf32x4 $0x1,%ymm28,%xmm29
  570cf7:	62 91 f5 28 15 c5    	vunpckhpd %ymm29,%ymm1,%ymm0
  570cfd:	62 61 0c 28 c6 f8 dd 	vshufps $0xdd,%ymm0,%ymm14,%ymm31
  570d04:	c5 0c c6 f0 88       	vshufps $0x88,%ymm0,%ymm14,%ymm14
  570d09:	62 b1 b5 20 14 c3    	vunpcklpd %ymm19,%ymm25,%ymm0
  570d0f:	62 91 f5 28 14 cd    	vunpcklpd %ymm29,%ymm1,%ymm1
  570d15:	62 61 7c 28 c6 e9 dd 	vshufps $0xdd,%ymm1,%ymm0,%ymm29
  570d1c:	62 e1 7c 28 c6 d9 88 	vshufps $0x88,%ymm1,%ymm0,%ymm19
  570d23:	62 93 45 20 18 c6 01 	vinsertf32x4 $0x1,%xmm30,%ymm23,%ymm0
  570d2a:	62 b3 7d 20 18 ca 01 	vinsertf32x4 $0x1,%xmm18,%ymm16,%ymm1
  570d31:	62 e1 fd 28 15 c1    	vunpckhpd %ymm1,%ymm0,%ymm16
  570d37:	62 83 25 20 18 d2 01 	vinsertf32x4 $0x1,%xmm26,%ymm27,%ymm18
  570d3e:	62 01 7c 08 28 d4    	vmovaps %xmm28,%xmm26
  570d44:	62 01 ed 20 15 ca    	vunpckhpd %ymm26,%ymm18,%ymm25
  570d4a:	62 81 7c 20 c6 f9 dd 	vshufps $0xdd,%ymm25,%ymm16,%ymm23
  570d51:	62 01 7c 20 c6 c9 88 	vshufps $0x88,%ymm25,%ymm16,%ymm25
  570d58:	c5 fd 14 c1          	vunpcklpd %ymm1,%ymm0,%ymm0
  570d5c:	62 91 ed 20 14 ca    	vunpcklpd %ymm26,%ymm18,%ymm1
  570d62:	62 61 7c 28 c6 d1 dd 	vshufps $0xdd,%ymm1,%ymm0,%ymm26
  570d69:	62 61 7c 28 c6 d9 88 	vshufps $0x88,%ymm1,%ymm0,%ymm27
  570d70:	c4 c1 2c c6 c3 88    	vshufps $0x88,%ymm11,%ymm10,%ymm0
  570d76:	62 91 4c 20 58 c8    	vaddps %ymm24,%ymm22,%ymm1
  570d7c:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  570d82:	62 31 5c 20 58 d5    	vaddps %ymm21,%ymm20,%ymm10
  570d88:	62 31 04 28 58 d9    	vaddps %ymm17,%ymm15,%ymm11
  570d8e:	c4 41 7c 28 fc       	vmovaps %ymm12,%ymm15
  570d93:	c4 62 75 ac f8       	vfnmadd213ps %ymm0,%ymm1,%ymm15
  570d98:	c4 42 2d b8 f8       	vfmadd231ps %ymm8,%ymm10,%ymm15
  570d9d:	62 c1 7c 28 28 c5    	vmovaps %ymm13,%ymm16
  570da3:	62 e2 75 28 ac c0    	vfnmadd213ps %ymm0,%ymm1,%ymm16
  570da9:	62 c2 2d 28 bc c4    	vfnmadd231ps %ymm12,%ymm10,%ymm16
  570daf:	62 c2 25 28 b8 c0    	vfmadd231ps %ymm8,%ymm11,%ymm16
  570db5:	c4 62 75 a8 c0       	vfmadd213ps %ymm0,%ymm1,%ymm8
  570dba:	c5 fc 58 c1          	vaddps %ymm1,%ymm0,%ymm0
  570dbe:	c5 d4 5c cf          	vsubps %ymm7,%ymm5,%ymm1
  570dc2:	c5 ec 5c d3          	vsubps %ymm3,%ymm2,%ymm2
  570dc6:	c5 fc 10 5c 24 b8    	vmovups -0x48(%rsp),%ymm3
  570dcc:	c5 e4 5c 5c 24 d8    	vsubps -0x28(%rsp),%ymm3,%ymm3
  570dd2:	c5 ac 58 c0          	vaddps %ymm0,%ymm10,%ymm0
  570dd6:	62 c1 7c 28 58 cb    	vaddps %ymm11,%ymm0,%ymm17
  570ddc:	c4 42 25 bc fd       	vfnmadd231ps %ymm13,%ymm11,%ymm15
  570de1:	c4 42 2d bc c5       	vfnmadd231ps %ymm13,%ymm10,%ymm8
  570de6:	c5 e4 59 c4          	vmulps %ymm4,%ymm3,%ymm0
  570dea:	c4 e2 6d bc c6       	vfnmadd231ps %ymm6,%ymm2,%ymm0
  570def:	c4 c2 75 b8 c1       	vfmadd231ps %ymm9,%ymm1,%ymm0
  570df4:	62 e1 04 28 5c d0    	vsubps %ymm0,%ymm15,%ymm18
  570dfa:	c4 42 25 bc c4       	vfnmadd231ps %ymm12,%ymm11,%ymm8
  570dff:	62 b3 f5 20 23 ea 03 	vshuff64x2 $0x3,%ymm18,%ymm17,%ymm5
  570e06:	c5 b4 59 fb          	vmulps %ymm3,%ymm9,%ymm7
  570e0a:	c4 e2 6d bc fc       	vfnmadd231ps %ymm4,%ymm2,%ymm7
  570e0f:	c4 e2 75 bc fe       	vfnmadd231ps %ymm6,%ymm1,%ymm7
  570e14:	c5 b4 59 d2          	vmulps %ymm2,%ymm9,%ymm2
  570e18:	62 71 7c 20 58 df    	vaddps %ymm7,%ymm16,%ymm11
  570e1e:	c4 e2 65 b8 d6       	vfmadd231ps %ymm6,%ymm3,%ymm2
  570e23:	c4 e2 75 b8 d4       	vfmadd231ps %ymm4,%ymm1,%ymm2
  570e28:	c5 bc 5c f2          	vsubps %ymm2,%ymm8,%ymm6
  570e2c:	c4 e3 25 06 ce 31    	vperm2f128 $0x31,%ymm6,%ymm11,%ymm1
  570e32:	c5 d5 15 d9          	vunpckhpd %ymm1,%ymm5,%ymm3
  570e36:	c5 3c 58 c2          	vaddps %ymm2,%ymm8,%ymm8
  570e3a:	62 e1 7c 20 5c c7    	vsubps %ymm7,%ymm16,%ymm16
  570e40:	62 b3 bd 28 23 d0 03 	vshuff64x2 $0x3,%ymm16,%ymm8,%ymm2
  570e47:	62 e1 04 28 58 e0    	vaddps %ymm0,%ymm15,%ymm20
  570e4d:	62 e3 7d 28 19 e0 01 	vextractf32x4 $0x1,%ymm20,%xmm0
  570e54:	c5 ed 15 e0          	vunpckhpd %ymm0,%ymm2,%ymm4
  570e58:	c5 64 c6 d4 dd       	vshufps $0xdd,%ymm4,%ymm3,%ymm10
  570e5d:	c5 64 c6 fc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm15
  570e62:	c5 d5 14 c9          	vunpcklpd %ymm1,%ymm5,%ymm1
  570e66:	c5 ed 14 c0          	vunpcklpd %ymm0,%ymm2,%ymm0
  570e6a:	c5 f4 c6 e8 dd       	vshufps $0xdd,%ymm0,%ymm1,%ymm5
  570e6f:	62 e1 74 28 c6 e8 88 	vshufps $0x88,%ymm0,%ymm1,%ymm21
  570e76:	62 91 04 20 c6 cf d8 	vshufps $0xd8,%ymm31,%ymm31,%ymm1
  570e7d:	c4 41 0c c6 ce d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm9
  570e83:	62 91 14 20 c6 e5 d8 	vshufps $0xd8,%ymm29,%ymm29,%ymm4
  570e8a:	62 31 64 20 c6 eb d8 	vshufps $0xd8,%ymm19,%ymm19,%ymm13
  570e91:	62 b1 44 20 c6 df d8 	vshufps $0xd8,%ymm23,%ymm23,%ymm3
  570e98:	62 11 34 20 c6 e1 d8 	vshufps $0xd8,%ymm25,%ymm25,%ymm12
  570e9f:	62 91 2c 20 c6 fa d8 	vshufps $0xd8,%ymm26,%ymm26,%ymm7
  570ea6:	62 91 24 20 c6 c3 d8 	vshufps $0xd8,%ymm27,%ymm27,%ymm0
  570ead:	c4 c1 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm2
  570eb3:	c4 41 04 c6 d7 d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm10
  570eb9:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  570ebe:	62 31 54 20 c6 fd d8 	vshufps $0xd8,%ymm21,%ymm21,%ymm15
  570ec5:	62 33 75 20 18 f2 01 	vinsertf32x4 $0x1,%xmm18,%ymm17,%ymm14
  570ecc:	c4 e3 25 18 f6 01    	vinsertf128 $0x1,%xmm6,%ymm11,%ymm6
  570ed2:	c5 0d 15 de          	vunpckhpd %ymm6,%ymm14,%ymm11
  570ed6:	62 a3 3d 28 18 c0 01 	vinsertf32x4 $0x1,%xmm16,%ymm8,%ymm16
  570edd:	62 a1 7c 08 28 cc    	vmovaps %xmm20,%xmm17
  570ee3:	62 a1 fd 20 15 d1    	vunpckhpd %ymm17,%ymm16,%ymm18
  570ee9:	62 31 24 28 c6 c2 dd 	vshufps $0xdd,%ymm18,%ymm11,%ymm8
  570ef0:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  570ef6:	62 31 24 28 c6 da 88 	vshufps $0x88,%ymm18,%ymm11,%ymm11
  570efd:	62 c1 24 28 c6 d3 d8 	vshufps $0xd8,%ymm11,%ymm11,%ymm18
  570f04:	c5 8d 14 f6          	vunpcklpd %ymm6,%ymm14,%ymm6
  570f08:	62 31 fd 20 14 d9    	vunpcklpd %ymm17,%ymm16,%ymm11
  570f0e:	c4 41 4c c6 f3 dd    	vshufps $0xdd,%ymm11,%ymm6,%ymm14
  570f14:	c4 41 0c c6 f6 d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm14
  570f1a:	c4 c1 4c c6 f3 88    	vshufps $0x88,%ymm11,%ymm6,%ymm6
  570f20:	c5 cc c6 f6 d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm6
  570f25:	62 e1 7c 28 10 42 08 	vmovups 0x100(%rdx),%ymm16
  570f2c:	62 e1 7c 28 10 4a 09 	vmovups 0x120(%rdx),%ymm17
  570f33:	62 31 04 28 59 d8    	vmulps %ymm16,%ymm15,%ymm11
  570f39:	62 32 15 28 bc d9    	vfnmadd231ps %ymm17,%ymm13,%ymm11
  570f3f:	62 31 14 28 59 e8    	vmulps %ymm16,%ymm13,%ymm13
  570f45:	62 e1 7c 28 10 42 04 	vmovups 0x80(%rdx),%ymm16
  570f4c:	62 32 05 28 b8 e9    	vfmadd231ps %ymm17,%ymm15,%ymm13
  570f52:	62 e1 7c 28 10 4a 05 	vmovups 0xa0(%rdx),%ymm17
  570f59:	62 31 6c 20 59 f8    	vmulps %ymm16,%ymm18,%ymm15
  570f5f:	62 32 1d 28 bc f9    	vfnmadd231ps %ymm17,%ymm12,%ymm15
  570f65:	62 31 1c 28 59 e0    	vmulps %ymm16,%ymm12,%ymm12
  570f6b:	62 e1 7c 28 10 42 0c 	vmovups 0x180(%rdx),%ymm16
  570f72:	62 32 6d 20 b8 e1    	vfmadd231ps %ymm17,%ymm18,%ymm12
  570f78:	62 e1 7c 28 10 4a 0d 	vmovups 0x1a0(%rdx),%ymm17
  570f7f:	62 a1 2c 28 59 d0    	vmulps %ymm16,%ymm10,%ymm18
  570f85:	62 a2 35 28 bc d1    	vfnmadd231ps %ymm17,%ymm9,%ymm18
  570f8b:	62 31 34 28 59 c8    	vmulps %ymm16,%ymm9,%ymm9
  570f91:	62 e1 7c 28 10 42 02 	vmovups 0x40(%rdx),%ymm16
  570f98:	62 32 2d 28 b8 c9    	vfmadd231ps %ymm17,%ymm10,%ymm9
  570f9e:	c5 7c 10 52 60       	vmovups 0x60(%rdx),%ymm10
  570fa3:	62 a1 0c 28 59 c8    	vmulps %ymm16,%ymm14,%ymm17
  570fa9:	62 c2 45 28 bc ca    	vfnmadd231ps %ymm10,%ymm7,%ymm17
  570faf:	62 b1 44 28 59 f8    	vmulps %ymm16,%ymm7,%ymm7
  570fb5:	62 e1 7c 28 10 42 0a 	vmovups 0x140(%rdx),%ymm16
  570fbc:	c4 c2 0d b8 fa       	vfmadd231ps %ymm10,%ymm14,%ymm7
  570fc1:	c5 7c 10 92 60 01 00 	vmovups 0x160(%rdx),%ymm10
  570fc8:	00 
  570fc9:	62 31 54 28 59 f0    	vmulps %ymm16,%ymm5,%ymm14
  570fcf:	c4 42 5d bc f2       	vfnmadd231ps %ymm10,%ymm4,%ymm14
  570fd4:	62 b1 5c 28 59 e0    	vmulps %ymm16,%ymm4,%ymm4
  570fda:	62 e1 7c 28 10 42 06 	vmovups 0xc0(%rdx),%ymm16
  570fe1:	c4 c2 55 b8 e2       	vfmadd231ps %ymm10,%ymm5,%ymm4
  570fe6:	c5 fc 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm5
  570fed:	00 
  570fee:	62 31 3c 28 59 d0    	vmulps %ymm16,%ymm8,%ymm10
  570ff4:	c4 62 65 bc d5       	vfnmadd231ps %ymm5,%ymm3,%ymm10
  570ff9:	62 b1 64 28 59 d8    	vmulps %ymm16,%ymm3,%ymm3
  570fff:	62 e1 7c 28 10 42 0e 	vmovups 0x1c0(%rdx),%ymm16
  571006:	c4 e2 3d b8 dd       	vfmadd231ps %ymm5,%ymm8,%ymm3
  57100b:	c5 fc 10 aa e0 01 00 	vmovups 0x1e0(%rdx),%ymm5
  571012:	00 
  571013:	62 31 6c 28 59 c0    	vmulps %ymm16,%ymm2,%ymm8
  571019:	c4 62 75 bc c5       	vfnmadd231ps %ymm5,%ymm1,%ymm8
  57101e:	62 b1 74 28 59 c8    	vmulps %ymm16,%ymm1,%ymm1
  571024:	62 c1 4c 28 58 c3    	vaddps %ymm11,%ymm6,%ymm16
  57102a:	c4 e2 6d b8 cd       	vfmadd231ps %ymm5,%ymm2,%ymm1
  57102f:	62 b1 04 28 58 d2    	vaddps %ymm18,%ymm15,%ymm2
  571035:	62 f1 7c 20 58 ea    	vaddps %ymm2,%ymm16,%ymm5
  57103b:	c4 c1 4c 5c f3       	vsubps %ymm11,%ymm6,%ymm6
  571040:	c4 41 1c 58 d9       	vaddps %ymm9,%ymm12,%ymm11
  571045:	c4 41 1c 5c c9       	vsubps %ymm9,%ymm12,%ymm9
  57104a:	62 51 74 20 58 e6    	vaddps %ymm14,%ymm17,%ymm12
  571050:	62 51 74 20 5c f6    	vsubps %ymm14,%ymm17,%ymm14
  571056:	62 e1 44 28 58 cc    	vaddps %ymm4,%ymm7,%ymm17
  57105c:	c5 c4 5c e4          	vsubps %ymm4,%ymm7,%ymm4
  571060:	c5 e4 58 f9          	vaddps %ymm1,%ymm3,%ymm7
  571064:	c5 e4 5c c9          	vsubps %ymm1,%ymm3,%ymm1
  571068:	c4 c1 2c 58 d8       	vaddps %ymm8,%ymm10,%ymm3
  57106d:	c4 41 2c 5c c0       	vsubps %ymm8,%ymm10,%ymm8
  571072:	c5 14 58 d0          	vaddps %ymm0,%ymm13,%ymm10
  571076:	c4 c1 7c 5c c5       	vsubps %ymm13,%ymm0,%ymm0
  57107b:	c5 1c 58 eb          	vaddps %ymm3,%ymm12,%ymm13
  57107f:	62 51 6c 20 5c ff    	vsubps %ymm15,%ymm18,%ymm15
  571085:	62 e1 0c 28 58 d4    	vaddps %ymm4,%ymm14,%ymm18
  57108b:	c4 c1 5c 5c e6       	vsubps %ymm14,%ymm4,%ymm4
  571090:	c4 41 74 5c f0       	vsubps %ymm8,%ymm1,%ymm14
  571095:	c5 bc 58 c9          	vaddps %ymm1,%ymm8,%ymm1
  571099:	c4 62 7d 18 05 46 b2 	vbroadcastss -0x4f4dba(%rip),%ymm8        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  5710a0:	b0 ff 
  5710a2:	62 c1 6c 20 59 d0    	vmulps %ymm8,%ymm18,%ymm18
  5710a8:	c4 41 0c 59 f0       	vmulps %ymm8,%ymm14,%ymm14
  5710ad:	c5 bc 59 e4          	vmulps %ymm4,%ymm8,%ymm4
  5710b1:	c5 bc 59 c9          	vmulps %ymm1,%ymm8,%ymm1
  5710b5:	c5 14 58 c5          	vaddps %ymm5,%ymm13,%ymm8
  5710b9:	62 f1 7c 20 5c d2    	vsubps %ymm2,%ymm16,%ymm2
  5710bf:	62 e1 74 20 58 c7    	vaddps %ymm7,%ymm17,%ymm16
  5710c5:	62 f1 74 20 5c ff    	vsubps %ymm7,%ymm17,%ymm7
  5710cb:	62 c1 24 28 58 ca    	vaddps %ymm10,%ymm11,%ymm17
  5710d1:	c4 41 2c 5c d3       	vsubps %ymm11,%ymm10,%ymm10
  5710d6:	62 31 74 20 58 d8    	vaddps %ymm16,%ymm17,%ymm11
  5710dc:	c4 41 64 5c e4       	vsubps %ymm12,%ymm3,%ymm12
  5710e1:	c5 b4 58 de          	vaddps %ymm6,%ymm9,%ymm3
  5710e5:	c4 41 4c 5c c9       	vsubps %ymm9,%ymm6,%ymm9
  5710ea:	c5 dc 5c f1          	vsubps %ymm1,%ymm4,%ymm6
  5710ee:	c5 dc 58 c9          	vaddps %ymm1,%ymm4,%ymm1
  5710f2:	c5 84 58 e0          	vaddps %ymm0,%ymm15,%ymm4
  5710f6:	c4 41 7c 5c ff       	vsubps %ymm15,%ymm0,%ymm15
  5710fb:	62 d1 6c 20 58 c6    	vaddps %ymm14,%ymm18,%ymm0
  571101:	62 31 0c 28 5c f2    	vsubps %ymm18,%ymm14,%ymm14
  571107:	62 e1 64 28 58 d0    	vaddps %ymm0,%ymm3,%ymm18
  57110d:	c4 41 54 5c ed       	vsubps %ymm13,%ymm5,%ymm13
  571112:	62 e1 5c 28 58 de    	vaddps %ymm6,%ymm4,%ymm19
  571118:	62 a1 74 20 5c c0    	vsubps %ymm16,%ymm17,%ymm16
  57111e:	62 e1 6c 28 58 cf    	vaddps %ymm7,%ymm2,%ymm17
  571124:	c5 e4 5c e8          	vsubps %ymm0,%ymm3,%ymm5
  571128:	62 c1 2c 28 58 e4    	vaddps %ymm12,%ymm10,%ymm20
  57112e:	c5 dc 5c f6          	vsubps %ymm6,%ymm4,%ymm6
  571132:	62 e1 34 28 58 e9    	vaddps %ymm1,%ymm9,%ymm21
  571138:	c5 ec 5c df          	vsubps %ymm7,%ymm2,%ymm3
  57113c:	c4 c1 04 58 fe       	vaddps %ymm14,%ymm15,%ymm7
  571141:	c4 c1 2c 5c e4       	vsubps %ymm12,%ymm10,%ymm4
  571146:	c5 b4 5c c1          	vsubps %ymm1,%ymm9,%ymm0
  57114a:	c4 c1 04 5c ce       	vsubps %ymm14,%ymm15,%ymm1
  57114f:	c5 fc 28 15 e9 fb b0 	vmovaps -0x4f0417(%rip),%ymm2        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  571156:	ff 
  571157:	c4 41 3c 15 cb       	vunpckhps %ymm11,%ymm8,%ymm9
  57115c:	c4 41 3c 14 d3       	vunpcklps %ymm11,%ymm8,%ymm10
  571161:	62 52 6d 28 7f c3    	vpermt2ps %ymm11,%ymm2,%ymm8
  571167:	c5 7c 11 06          	vmovups %ymm8,(%rsi)
  57116b:	c4 63 7d 19 56 20 01 	vextractf128 $0x1,%ymm10,0x20(%rsi)
  571172:	c4 43 7d 19 c8 01    	vextractf128 $0x1,%ymm9,%xmm8
  571178:	c5 78 13 46 30       	vmovlps %xmm8,0x30(%rsi)
  57117d:	62 31 6c 20 15 c3    	vunpckhps %ymm19,%ymm18,%ymm8
  571183:	62 31 6c 20 14 cb    	vunpcklps %ymm19,%ymm18,%ymm9
  571189:	62 a2 6d 28 7f d3    	vpermt2ps %ymm19,%ymm2,%ymm18
  57118f:	62 e1 7c 28 11 96 38 	vmovups %ymm18,0x38(%rsi)
  571196:	00 00 00 
  571199:	c4 63 7d 19 4e 58 01 	vextractf128 $0x1,%ymm9,0x58(%rsi)
  5711a0:	c4 43 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm8
  5711a6:	c5 78 13 46 68       	vmovlps %xmm8,0x68(%rsi)
  5711ab:	62 31 74 20 15 c4    	vunpckhps %ymm20,%ymm17,%ymm8
  5711b1:	62 31 74 20 14 cc    	vunpcklps %ymm20,%ymm17,%ymm9
  5711b7:	62 a2 6d 28 7f cc    	vpermt2ps %ymm20,%ymm2,%ymm17
  5711bd:	62 e1 7c 28 11 8e 70 	vmovups %ymm17,0x70(%rsi)
  5711c4:	00 00 00 
  5711c7:	c4 63 7d 19 8e 90 00 	vextractf128 $0x1,%ymm9,0x90(%rsi)
  5711ce:	00 00 01 
  5711d1:	c4 43 7d 19 c0 01    	vextractf128 $0x1,%ymm8,%xmm8
  5711d7:	c5 78 13 86 a0 00 00 	vmovlps %xmm8,0xa0(%rsi)
  5711de:	00 
  5711df:	62 71 54 20 15 c7    	vunpckhps %ymm7,%ymm21,%ymm8
  5711e5:	62 71 54 20 14 cf    	vunpcklps %ymm7,%ymm21,%ymm9
  5711eb:	62 e2 6d 28 7f ef    	vpermt2ps %ymm7,%ymm2,%ymm21
  5711f1:	62 e1 7c 28 11 ae a8 	vmovups %ymm21,0xa8(%rsi)
  5711f8:	00 00 00 
  5711fb:	c4 63 7d 19 8e c8 00 	vextractf128 $0x1,%ymm9,0xc8(%rsi)
  571202:	00 00 01 
  571205:	c4 63 7d 19 c7 01    	vextractf128 $0x1,%ymm8,%xmm7
  57120b:	c5 f8 13 be d8 00 00 	vmovlps %xmm7,0xd8(%rsi)
  571212:	00 
  571213:	62 b1 14 28 15 f8    	vunpckhps %ymm16,%ymm13,%ymm7
  571219:	62 31 14 28 14 c0    	vunpcklps %ymm16,%ymm13,%ymm8
  57121f:	62 32 6d 28 7f e8    	vpermt2ps %ymm16,%ymm2,%ymm13
  571225:	c5 7c 11 ae e0 00 00 	vmovups %ymm13,0xe0(%rsi)
  57122c:	00 
  57122d:	c4 63 7d 19 86 00 01 	vextractf128 $0x1,%ymm8,0x100(%rsi)
  571234:	00 00 01 
  571237:	c4 e3 7d 19 ff 01    	vextractf128 $0x1,%ymm7,%xmm7
  57123d:	c5 f8 13 be 10 01 00 	vmovlps %xmm7,0x110(%rsi)
  571244:	00 
  571245:	c5 d4 15 fe          	vunpckhps %ymm6,%ymm5,%ymm7
  571249:	c5 54 14 c6          	vunpcklps %ymm6,%ymm5,%ymm8
  57124d:	62 f2 6d 28 7f ee    	vpermt2ps %ymm6,%ymm2,%ymm5
  571253:	c5 fc 11 ae 18 01 00 	vmovups %ymm5,0x118(%rsi)
  57125a:	00 
  57125b:	c4 63 7d 19 86 38 01 	vextractf128 $0x1,%ymm8,0x138(%rsi)
  571262:	00 00 01 
  571265:	c4 e3 7d 19 fd 01    	vextractf128 $0x1,%ymm7,%xmm5
  57126b:	c5 f8 13 ae 48 01 00 	vmovlps %xmm5,0x148(%rsi)
  571272:	00 
  571273:	c5 e4 15 ec          	vunpckhps %ymm4,%ymm3,%ymm5
  571277:	c5 e4 14 f4          	vunpcklps %ymm4,%ymm3,%ymm6
  57127b:	62 f2 6d 28 7f dc    	vpermt2ps %ymm4,%ymm2,%ymm3
  571281:	c5 fc 11 9e 50 01 00 	vmovups %ymm3,0x150(%rsi)
  571288:	00 
  571289:	c4 e3 7d 19 b6 70 01 	vextractf128 $0x1,%ymm6,0x170(%rsi)
  571290:	00 00 01 
  571293:	c4 e3 7d 19 eb 01    	vextractf128 $0x1,%ymm5,%xmm3
  571299:	c5 f8 13 9e 80 01 00 	vmovlps %xmm3,0x180(%rsi)
  5712a0:	00 
  5712a1:	62 f2 7d 28 77 d1    	vpermi2ps %ymm1,%ymm0,%ymm2
  5712a7:	c5 fc 11 96 88 01 00 	vmovups %ymm2,0x188(%rsi)
  5712ae:	00 
  5712af:	c5 fc 15 d1          	vunpckhps %ymm1,%ymm0,%ymm2
  5712b3:	c5 fc 14 c1          	vunpcklps %ymm1,%ymm0,%ymm0
  5712b7:	c4 e3 7d 19 86 a8 01 	vextractf128 $0x1,%ymm0,0x1a8(%rsi)
  5712be:	00 00 01 
  5712c1:	c4 e3 7d 19 d0 01    	vextractf128 $0x1,%ymm2,%xmm0
  5712c7:	c5 f8 13 86 b8 01 00 	vmovlps %xmm0,0x1b8(%rsi)
  5712ce:	00 
  5712cf:	c5 f8 77             	vzeroupper
  5712d2:	c3                   	ret
  5712d3:	cc                   	int3
  5712d4:	cc                   	int3
  5712d5:	cc                   	int3
  5712d6:	cc                   	int3
  5712d7:	cc                   	int3
  5712d8:	cc                   	int3
  5712d9:	cc                   	int3
  5712da:	cc                   	int3
  5712db:	cc                   	int3
  5712dc:	cc                   	int3
  5712dd:	cc                   	int3
  5712de:	cc                   	int3
  5712df:	cc                   	int3


00000000005712e0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  5712e0:	c5 fc 10 2f          	vmovups (%rdi),%ymm5
  5712e4:	c5 7c 10 4f 20       	vmovups 0x20(%rdi),%ymm9
  5712e9:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  5712ee:	c5 fc 10 4f 60       	vmovups 0x60(%rdi),%ymm1
  5712f3:	c5 fc 10 97 80 00 00 	vmovups 0x80(%rdi),%ymm2
  5712fa:	00 
  5712fb:	c5 fc 10 9f a0 00 00 	vmovups 0xa0(%rdi),%ymm3
  571302:	00 
  571303:	c4 c1 54 c6 e1 dd    	vshufps $0xdd,%ymm9,%ymm5,%ymm4
  571309:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  57130f:	c5 fc c6 f1 dd       	vshufps $0xdd,%ymm1,%ymm0,%ymm6
  571314:	c4 63 fd 01 d6 d8    	vpermpd $0xd8,%ymm6,%ymm10
  57131a:	c5 ec c6 f3 dd       	vshufps $0xdd,%ymm3,%ymm2,%ymm6
  57131f:	c4 63 fd 01 e6 d8    	vpermpd $0xd8,%ymm6,%ymm12
  571325:	c4 c1 2c 58 f4       	vaddps %ymm12,%ymm10,%ymm6
  57132a:	c5 5c 58 c6          	vaddps %ymm6,%ymm4,%ymm8
  57132e:	c4 63 7d 19 c7 01    	vextractf128 $0x1,%ymm8,%xmm7
  571334:	c5 fc c6 c1 88       	vshufps $0x88,%ymm1,%ymm0,%ymm0
  571339:	c4 63 fd 01 e8 d8    	vpermpd $0xd8,%ymm0,%ymm13
  57133f:	c5 ec c6 c3 88       	vshufps $0x88,%ymm3,%ymm2,%ymm0
  571344:	c4 63 fd 01 f0 d8    	vpermpd $0xd8,%ymm0,%ymm14
  57134a:	c4 c1 14 5c c6       	vsubps %ymm14,%ymm13,%ymm0
  57134f:	c4 62 7d 18 3d 0c ae 	vbroadcastss -0x4f51f4(%rip),%ymm15        # 7c164 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2874>
  571356:	b0 ff 
  571358:	c5 84 59 c0          	vmulps %ymm0,%ymm15,%ymm0
  57135c:	62 e2 7d 28 18 05 be 	vbroadcastss -0x4f4f42(%rip),%ymm16        # 7c424 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2b34>
  571363:	b0 b0 ff 
  571366:	62 f2 7d 20 ac f4    	vfnmadd213ps %ymm4,%ymm16,%ymm6
  57136c:	c5 fc 58 d6          	vaddps %ymm6,%ymm0,%ymm2
  571370:	c4 e3 7d 19 d1 01    	vextractf128 $0x1,%ymm2,%xmm1
  571376:	c5 c5 15 d9          	vunpckhpd %ymm1,%ymm7,%ymm3
  57137a:	c5 cc 5c f0          	vsubps %ymm0,%ymm6,%ymm6
  57137e:	c4 e3 7d 19 f0 01    	vextractf128 $0x1,%ymm6,%xmm0
  571384:	c4 41 20 57 db       	vxorps %xmm11,%xmm11,%xmm11
  571389:	c4 c1 7d 15 e3       	vunpckhpd %ymm11,%ymm0,%ymm4
  57138e:	62 e1 64 28 c6 cc dd 	vshufps $0xdd,%ymm4,%ymm3,%ymm17
  571395:	62 a1 74 20 c6 c9 d8 	vshufps $0xd8,%ymm17,%ymm17,%ymm17
  57139c:	c5 e4 c6 dc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm3
  5713a1:	c5 e4 c6 e3 d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm4
  5713a6:	c5 c5 14 d9          	vunpcklpd %ymm1,%ymm7,%ymm3
  5713aa:	c4 c3 7d 0c c3 cc    	vblendps $0xcc,%ymm11,%ymm0,%ymm0
  5713b0:	c5 e4 c6 c8 dd       	vshufps $0xdd,%ymm0,%ymm3,%ymm1
  5713b5:	c5 f4 c6 c9 d8       	vshufps $0xd8,%ymm1,%ymm1,%ymm1
  5713ba:	c5 e4 c6 c0 88       	vshufps $0x88,%ymm0,%ymm3,%ymm0
  5713bf:	c5 fc c6 f8 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm7
  5713c4:	c5 78 29 c0          	vmovaps %xmm8,%xmm0
  5713c8:	c5 f8 28 da          	vmovaps %xmm2,%xmm3
  5713cc:	c5 7d 15 c3          	vunpckhpd %ymm3,%ymm0,%ymm8
  5713d0:	c5 f8 28 d6          	vmovaps %xmm6,%xmm2
  5713d4:	62 f1 6d 20 73 da 08 	vpsrldq $0x8,%ymm2,%ymm18
  5713db:	62 b1 3c 28 c6 d2 dd 	vshufps $0xdd,%ymm18,%ymm8,%ymm2
  5713e2:	c5 ec c6 d2 d8       	vshufps $0xd8,%ymm2,%ymm2,%ymm2
  5713e7:	62 31 3c 28 c6 c2 88 	vshufps $0x88,%ymm18,%ymm8,%ymm8
  5713ee:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  5713f4:	c5 fd 14 c3          	vunpcklpd %ymm3,%ymm0,%ymm0
  5713f8:	c5 fa 7e de          	vmovq  %xmm6,%xmm3
  5713fc:	c5 fc c6 f3 dd       	vshufps $0xdd,%ymm3,%ymm0,%ymm6
  571401:	c5 cc c6 f6 d8       	vshufps $0xd8,%ymm6,%ymm6,%ymm6
  571406:	c5 fc c6 db 88       	vshufps $0x88,%ymm3,%ymm0,%ymm3
  57140b:	c4 c1 54 c6 c1 88    	vshufps $0x88,%ymm9,%ymm5,%ymm0
  571411:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  571417:	c4 c1 14 58 ee       	vaddps %ymm14,%ymm13,%ymm5
  57141c:	c5 7c 58 ed          	vaddps %ymm5,%ymm0,%ymm13
  571420:	c4 43 7d 19 e9 01    	vextractf128 $0x1,%ymm13,%xmm9
  571426:	62 e2 55 28 ac c0    	vfnmadd213ps %ymm0,%ymm5,%ymm16
  57142c:	c4 c1 2c 5c c4       	vsubps %ymm12,%ymm10,%ymm0
  571431:	c5 84 59 c0          	vmulps %ymm0,%ymm15,%ymm0
  571435:	62 71 7c 20 5c d0    	vsubps %ymm0,%ymm16,%ymm10
  57143b:	c4 43 7d 19 d6 01    	vextractf128 $0x1,%ymm10,%xmm14
  571441:	c4 41 35 15 e6       	vunpckhpd %ymm14,%ymm9,%ymm12
  571446:	62 f1 7c 20 58 c0    	vaddps %ymm0,%ymm16,%ymm0
  57144c:	c4 c3 7d 19 c7 01    	vextractf128 $0x1,%ymm0,%xmm15
  571452:	62 c1 85 28 15 c3    	vunpckhpd %ymm11,%ymm15,%ymm16
  571458:	62 b1 1c 28 c6 e8 dd 	vshufps $0xdd,%ymm16,%ymm12,%ymm5
  57145f:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  571464:	62 31 1c 28 c6 e0 88 	vshufps $0x88,%ymm16,%ymm12,%ymm12
  57146b:	c4 41 1c c6 e4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm12
  571471:	c4 41 35 14 f6       	vunpcklpd %ymm14,%ymm9,%ymm14
  571476:	c4 43 05 0c db cc    	vblendps $0xcc,%ymm11,%ymm15,%ymm11
  57147c:	c4 41 0c c6 cb dd    	vshufps $0xdd,%ymm11,%ymm14,%ymm9
  571482:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  571488:	c4 41 0c c6 db 88    	vshufps $0x88,%ymm11,%ymm14,%ymm11
  57148e:	c4 41 24 c6 f3 d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm14
  571494:	c4 41 78 28 dd       	vmovaps %xmm13,%xmm11
  571499:	c4 41 78 28 ea       	vmovaps %xmm10,%xmm13
  57149e:	c4 41 25 15 fd       	vunpckhpd %ymm13,%ymm11,%ymm15
  5714a3:	c5 78 28 d0          	vmovaps %xmm0,%xmm10
  5714a7:	62 d1 7d 20 73 da 08 	vpsrldq $0x8,%ymm10,%ymm16
  5714ae:	62 31 04 28 c6 d0 dd 	vshufps $0xdd,%ymm16,%ymm15,%ymm10
  5714b5:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  5714bb:	62 31 04 28 c6 f8 88 	vshufps $0x88,%ymm16,%ymm15,%ymm15
  5714c2:	62 c1 04 28 c6 c7 d8 	vshufps $0xd8,%ymm15,%ymm15,%ymm16
  5714c9:	c4 41 25 14 dd       	vunpcklpd %ymm13,%ymm11,%ymm11
  5714ce:	c5 fa 7e c0          	vmovq  %xmm0,%xmm0
  5714d2:	c5 24 c6 e8 dd       	vshufps $0xdd,%ymm0,%ymm11,%ymm13
  5714d7:	c4 41 14 c6 fd d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm15
  5714dd:	c5 24 c6 d8 88       	vshufps $0x88,%ymm0,%ymm11,%ymm11
  5714e2:	c5 fc 10 82 00 01 00 	vmovups 0x100(%rdx),%ymm0
  5714e9:	00 
  5714ea:	62 e1 7c 28 10 52 09 	vmovups 0x120(%rdx),%ymm18
  5714f1:	c5 0c 59 e8          	vmulps %ymm0,%ymm14,%ymm13
  5714f5:	62 32 45 28 bc ea    	vfnmadd231ps %ymm18,%ymm7,%ymm13
  5714fb:	c5 c4 59 f8          	vmulps %ymm0,%ymm7,%ymm7
  5714ff:	c5 fc 10 82 80 00 00 	vmovups 0x80(%rdx),%ymm0
  571506:	00 
  571507:	62 b2 0d 28 b8 fa    	vfmadd231ps %ymm18,%ymm14,%ymm7
  57150d:	62 e1 7c 28 10 52 05 	vmovups 0xa0(%rdx),%ymm18
  571514:	62 71 7c 20 59 f0    	vmulps %ymm0,%ymm16,%ymm14
  57151a:	62 32 3d 28 bc f2    	vfnmadd231ps %ymm18,%ymm8,%ymm14
  571520:	c5 bc 59 c0          	vmulps %ymm0,%ymm8,%ymm0
  571524:	c5 7c 10 82 80 01 00 	vmovups 0x180(%rdx),%ymm8
  57152b:	00 
  57152c:	62 b2 7d 20 b8 c2    	vfmadd231ps %ymm18,%ymm16,%ymm0
  571532:	62 e1 7c 28 10 42 0d 	vmovups 0x1a0(%rdx),%ymm16
  571539:	62 c1 1c 28 59 d0    	vmulps %ymm8,%ymm12,%ymm18
  57153f:	62 a2 5d 28 bc d0    	vfnmadd231ps %ymm16,%ymm4,%ymm18
  571545:	c5 bc 59 e4          	vmulps %ymm4,%ymm8,%ymm4
  571549:	c5 7c 10 42 40       	vmovups 0x40(%rdx),%ymm8
  57154e:	62 b2 1d 28 b8 e0    	vfmadd231ps %ymm16,%ymm12,%ymm4
  571554:	c5 7c 10 62 60       	vmovups 0x60(%rdx),%ymm12
  571559:	62 c1 04 28 59 c0    	vmulps %ymm8,%ymm15,%ymm16
  57155f:	62 c2 4d 28 bc c4    	vfnmadd231ps %ymm12,%ymm6,%ymm16
  571565:	c5 bc 59 f6          	vmulps %ymm6,%ymm8,%ymm6
  571569:	c5 7c 10 82 40 01 00 	vmovups 0x140(%rdx),%ymm8
  571570:	00 
  571571:	c4 c2 05 b8 f4       	vfmadd231ps %ymm12,%ymm15,%ymm6
  571576:	c5 7c 10 a2 60 01 00 	vmovups 0x160(%rdx),%ymm12
  57157d:	00 
  57157e:	c4 41 34 59 f8       	vmulps %ymm8,%ymm9,%ymm15
  571583:	c4 42 75 bc fc       	vfnmadd231ps %ymm12,%ymm1,%ymm15
  571588:	c5 bc 59 c9          	vmulps %ymm1,%ymm8,%ymm1
  57158c:	c5 7c 10 82 c0 00 00 	vmovups 0xc0(%rdx),%ymm8
  571593:	00 
  571594:	c4 c2 35 b8 cc       	vfmadd231ps %ymm12,%ymm9,%ymm1
  571599:	c5 7c 10 8a e0 00 00 	vmovups 0xe0(%rdx),%ymm9
  5715a0:	00 
  5715a1:	c4 41 2c 59 e0       	vmulps %ymm8,%ymm10,%ymm12
  5715a6:	c4 42 6d bc e1       	vfnmadd231ps %ymm9,%ymm2,%ymm12
  5715ab:	c5 bc 59 d2          	vmulps %ymm2,%ymm8,%ymm2
  5715af:	c5 7c 10 82 c0 01 00 	vmovups 0x1c0(%rdx),%ymm8
  5715b6:	00 
  5715b7:	c4 c2 2d b8 d1       	vfmadd231ps %ymm9,%ymm10,%ymm2
  5715bc:	c5 7c 10 8a e0 01 00 	vmovups 0x1e0(%rdx),%ymm9
  5715c3:	00 
  5715c4:	c5 3c 59 d5          	vmulps %ymm5,%ymm8,%ymm10
  5715c8:	62 52 75 20 bc d1    	vfnmadd231ps %ymm9,%ymm17,%ymm10
  5715ce:	62 51 74 20 59 c0    	vmulps %ymm8,%ymm17,%ymm8
  5715d4:	c5 e4 c6 db d8       	vshufps $0xd8,%ymm3,%ymm3,%ymm3
  5715d9:	c4 41 24 c6 db d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm11
  5715df:	c4 42 55 b8 c1       	vfmadd231ps %ymm9,%ymm5,%ymm8
  5715e4:	c4 c1 24 58 ed       	vaddps %ymm13,%ymm11,%ymm5
  5715e9:	62 31 0c 28 58 ca    	vaddps %ymm18,%ymm14,%ymm9
  5715ef:	c4 41 24 5c dd       	vsubps %ymm13,%ymm11,%ymm11
  5715f4:	c5 7c 58 ec          	vaddps %ymm4,%ymm0,%ymm13
  5715f8:	c5 fc 5c e4          	vsubps %ymm4,%ymm0,%ymm4
  5715fc:	62 c1 7c 20 58 cf    	vaddps %ymm15,%ymm16,%ymm17
  571602:	62 51 7c 20 5c ff    	vsubps %ymm15,%ymm16,%ymm15
  571608:	62 e1 4c 28 58 c1    	vaddps %ymm1,%ymm6,%ymm16
  57160e:	c5 cc 5c c9          	vsubps %ymm1,%ymm6,%ymm1
  571612:	c5 bc 58 f2          	vaddps %ymm2,%ymm8,%ymm6
  571616:	c4 c1 6c 5c d0       	vsubps %ymm8,%ymm2,%ymm2
  57161b:	c4 41 1c 58 c2       	vaddps %ymm10,%ymm12,%ymm8
  571620:	c4 41 1c 5c d2       	vsubps %ymm10,%ymm12,%ymm10
  571625:	c5 44 58 e3          	vaddps %ymm3,%ymm7,%ymm12
  571629:	62 e1 64 28 5c df    	vsubps %ymm7,%ymm3,%ymm19
  57162f:	c5 b4 58 c5          	vaddps %ymm5,%ymm9,%ymm0
  571633:	62 51 6c 20 5c f6    	vsubps %ymm14,%ymm18,%ymm14
  571639:	c5 84 58 d9          	vaddps %ymm1,%ymm15,%ymm3
  57163d:	c4 c1 74 5c cf       	vsubps %ymm15,%ymm1,%ymm1
  571642:	c4 c1 6c 5c fa       	vsubps %ymm10,%ymm2,%ymm7
  571647:	c5 ac 58 d2          	vaddps %ymm2,%ymm10,%ymm2
  57164b:	c4 62 7d 18 15 94 ac 	vbroadcastss -0x4f536c(%rip),%ymm10        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  571652:	b0 ff 
  571654:	c5 2c 59 fb          	vmulps %ymm3,%ymm10,%ymm15
  571658:	62 c1 44 28 59 d2    	vmulps %ymm10,%ymm7,%ymm18
  57165e:	62 c1 74 28 59 e2    	vmulps %ymm10,%ymm1,%ymm20
  571664:	c5 2c 59 d2          	vmulps %ymm2,%ymm10,%ymm10
  571668:	62 d1 74 20 58 f8    	vaddps %ymm8,%ymm17,%ymm7
  57166e:	c4 c1 54 5c c9       	vsubps %ymm9,%ymm5,%ymm1
  571673:	62 f1 7c 20 58 ee    	vaddps %ymm6,%ymm16,%ymm5
  571679:	62 f1 7c 20 5c de    	vsubps %ymm6,%ymm16,%ymm3
  57167f:	c4 c1 14 58 f4       	vaddps %ymm12,%ymm13,%ymm6
  571684:	c4 41 1c 5c cd       	vsubps %ymm13,%ymm12,%ymm9
  571689:	c5 4c 58 e5          	vaddps %ymm5,%ymm6,%ymm12
  57168d:	62 31 3c 28 5c e9    	vsubps %ymm17,%ymm8,%ymm13
  571693:	c5 24 58 c4          	vaddps %ymm4,%ymm11,%ymm8
  571697:	c5 a4 5c d4          	vsubps %ymm4,%ymm11,%ymm2
  57169b:	62 51 5c 20 5c da    	vsubps %ymm10,%ymm20,%ymm11
  5716a1:	62 d1 5c 20 58 e2    	vaddps %ymm10,%ymm20,%ymm4
  5716a7:	62 31 0c 28 58 d3    	vaddps %ymm19,%ymm14,%ymm10
  5716ad:	62 51 64 20 5c f6    	vsubps %ymm14,%ymm19,%ymm14
  5716b3:	62 a1 04 28 58 c2    	vaddps %ymm18,%ymm15,%ymm16
  5716b9:	62 51 6c 20 5c ff    	vsubps %ymm15,%ymm18,%ymm15
  5716bf:	62 c1 2c 28 58 cb    	vaddps %ymm11,%ymm10,%ymm17
  5716c5:	62 e1 4c 28 5c d5    	vsubps %ymm5,%ymm6,%ymm18
  5716cb:	62 c1 34 28 58 dd    	vaddps %ymm13,%ymm9,%ymm19
  5716d1:	c4 41 2c 5c d3       	vsubps %ymm11,%ymm10,%ymm10
  5716d6:	c4 41 0c 58 df       	vaddps %ymm15,%ymm14,%ymm11
  5716db:	c4 41 34 5c cd       	vsubps %ymm13,%ymm9,%ymm9
  5716e0:	c4 c1 0c 5c ef       	vsubps %ymm15,%ymm14,%ymm5
  5716e5:	c5 f8 58 f7          	vaddps %xmm7,%xmm0,%xmm6
  5716e9:	c5 7c 28 2d ef 0f b1 	vmovaps -0x4ef011(%rip),%ymm13        # 826e0 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x8df0>
  5716f0:	ff 
  5716f1:	62 d2 15 28 7f f4    	vpermt2ps %ymm12,%ymm13,%ymm6
  5716f7:	62 31 3c 08 58 e0    	vaddps %xmm16,%xmm8,%xmm12
  5716fd:	62 32 15 28 7f e1    	vpermt2ps %ymm17,%ymm13,%ymm12
  571703:	c5 70 58 f3          	vaddps %xmm3,%xmm1,%xmm14
  571707:	62 32 15 28 7f f3    	vpermt2ps %ymm19,%ymm13,%ymm14
  57170d:	c5 68 58 fc          	vaddps %xmm4,%xmm2,%xmm15
  571711:	62 52 15 28 7f fb    	vpermt2ps %ymm11,%ymm13,%ymm15
  571717:	c5 f8 5c c7          	vsubps %xmm7,%xmm0,%xmm0
  57171b:	62 b2 15 28 7f c2    	vpermt2ps %ymm18,%ymm13,%ymm0
  571721:	62 b1 3c 08 5c f8    	vsubps %xmm16,%xmm8,%xmm7
  571727:	62 d2 15 28 7f fa    	vpermt2ps %ymm10,%ymm13,%ymm7
  57172d:	c5 f0 5c cb          	vsubps %xmm3,%xmm1,%xmm1
  571731:	62 d2 15 28 7f c9    	vpermt2ps %ymm9,%ymm13,%ymm1
  571737:	c5 e8 5c d4          	vsubps %xmm4,%xmm2,%xmm2
  57173b:	62 f2 15 28 7f d5    	vpermt2ps %ymm5,%ymm13,%ymm2
  571741:	c4 e3 7d 19 f3 01    	vextractf128 $0x1,%ymm6,%xmm3
  571747:	c5 f8 13 5e 10       	vmovlps %xmm3,0x10(%rsi)
  57174c:	c5 f8 11 36          	vmovups %xmm6,(%rsi)
  571750:	c4 63 7d 19 e3 01    	vextractf128 $0x1,%ymm12,%xmm3
  571756:	c5 f8 13 5e 28       	vmovlps %xmm3,0x28(%rsi)
  57175b:	c5 78 11 66 18       	vmovups %xmm12,0x18(%rsi)
  571760:	c4 63 7d 19 f3 01    	vextractf128 $0x1,%ymm14,%xmm3
  571766:	c5 f8 13 5e 40       	vmovlps %xmm3,0x40(%rsi)
  57176b:	c5 78 11 76 30       	vmovups %xmm14,0x30(%rsi)
  571770:	c4 63 7d 19 fb 01    	vextractf128 $0x1,%ymm15,%xmm3
  571776:	c5 f8 13 5e 58       	vmovlps %xmm3,0x58(%rsi)
  57177b:	c5 78 11 7e 48       	vmovups %xmm15,0x48(%rsi)
  571780:	c4 e3 7d 19 c3 01    	vextractf128 $0x1,%ymm0,%xmm3
  571786:	c5 f8 13 5e 70       	vmovlps %xmm3,0x70(%rsi)
  57178b:	c5 f8 11 46 60       	vmovups %xmm0,0x60(%rsi)
  571790:	c4 e3 7d 19 f8 01    	vextractf128 $0x1,%ymm7,%xmm0
  571796:	c5 f8 13 86 88 00 00 	vmovlps %xmm0,0x88(%rsi)
  57179d:	00 
  57179e:	c5 f8 11 7e 78       	vmovups %xmm7,0x78(%rsi)
  5717a3:	c4 e3 7d 19 c8 01    	vextractf128 $0x1,%ymm1,%xmm0
  5717a9:	c5 f8 13 86 a0 00 00 	vmovlps %xmm0,0xa0(%rsi)
  5717b0:	00 
  5717b1:	c5 f8 11 8e 90 00 00 	vmovups %xmm1,0x90(%rsi)
  5717b8:	00 
  5717b9:	c4 e3 7d 19 d0 01    	vextractf128 $0x1,%ymm2,%xmm0
  5717bf:	c5 f8 13 86 b8 00 00 	vmovlps %xmm0,0xb8(%rsi)
  5717c6:	00 
  5717c7:	c5 f8 11 96 a8 00 00 	vmovups %xmm2,0xa8(%rsi)
  5717ce:	00 
  5717cf:	c5 f8 77             	vzeroupper
  5717d2:	c3                   	ret
  5717d3:	cc                   	int3
  5717d4:	cc                   	int3
  5717d5:	cc                   	int3
  5717d6:	cc                   	int3
  5717d7:	cc                   	int3
  5717d8:	cc                   	int3
  5717d9:	cc                   	int3
  5717da:	cc                   	int3
  5717db:	cc                   	int3
  5717dc:	cc                   	int3
  5717dd:	cc                   	int3
  5717de:	cc                   	int3
  5717df:	cc                   	int3


00000000005717e0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  5717e0:	c5 fc 10 2f          	vmovups (%rdi),%ymm5
  5717e4:	c5 fc 10 77 20       	vmovups 0x20(%rdi),%ymm6
  5717e9:	c5 d4 c6 de 88       	vshufps $0x88,%ymm6,%ymm5,%ymm3
  5717ee:	c4 e3 fd 01 e3 d8    	vpermpd $0xd8,%ymm3,%ymm4
  5717f4:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  5717fa:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  5717fe:	c5 fd 15 ca          	vunpckhpd %ymm2,%ymm0,%ymm1
  571802:	c5 f4 c6 fa dd       	vshufps $0xdd,%ymm2,%ymm1,%ymm7
  571807:	c5 c4 c6 ff d8       	vshufps $0xd8,%ymm7,%ymm7,%ymm7
  57180c:	c4 e3 75 0c ca aa    	vblendps $0xaa,%ymm2,%ymm1,%ymm1
  571812:	c4 e3 7d 0c c2 cc    	vblendps $0xcc,%ymm2,%ymm0,%ymm0
  571818:	c5 7c c6 c2 dd       	vshufps $0xdd,%ymm2,%ymm0,%ymm8
  57181d:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  571823:	c4 e3 7d 0c c2 aa    	vblendps $0xaa,%ymm2,%ymm0,%ymm0
  571829:	c5 f8 28 e4          	vmovaps %xmm4,%xmm4
  57182d:	c5 dd 73 dc 08       	vpsrldq $0x8,%ymm4,%ymm4
  571832:	c5 5c c6 ca dd       	vshufps $0xdd,%ymm2,%ymm4,%ymm9
  571837:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  57183d:	c4 e3 5d 0c e2 aa    	vblendps $0xaa,%ymm2,%ymm4,%ymm4
  571843:	c5 fa 7e db          	vmovq  %xmm3,%xmm3
  571847:	c5 64 c6 d2 dd       	vshufps $0xdd,%ymm2,%ymm3,%ymm10
  57184c:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  571852:	c4 e3 65 0c da aa    	vblendps $0xaa,%ymm2,%ymm3,%ymm3
  571858:	c5 d4 c6 f6 dd       	vshufps $0xdd,%ymm6,%ymm5,%ymm6
  57185d:	c4 63 fd 01 de d8    	vpermpd $0xd8,%ymm6,%ymm11
  571863:	c4 43 7d 19 dc 01    	vextractf128 $0x1,%ymm11,%xmm12
  571869:	c5 9d 15 ea          	vunpckhpd %ymm2,%ymm12,%ymm5
  57186d:	c5 54 c6 ea dd       	vshufps $0xdd,%ymm2,%ymm5,%ymm13
  571872:	c4 41 14 c6 ed d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm13
  571878:	c4 e3 55 0c ea aa    	vblendps $0xaa,%ymm2,%ymm5,%ymm5
  57187e:	c4 63 1d 0c e2 cc    	vblendps $0xcc,%ymm2,%ymm12,%ymm12
  571884:	c5 1c c6 f2 dd       	vshufps $0xdd,%ymm2,%ymm12,%ymm14
  571889:	c4 41 0c c6 f6 d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm14
  57188f:	c4 63 1d 0c e2 aa    	vblendps $0xaa,%ymm2,%ymm12,%ymm12
  571895:	c4 41 78 28 db       	vmovaps %xmm11,%xmm11
  57189a:	c4 c1 25 73 db 08    	vpsrldq $0x8,%ymm11,%ymm11
  5718a0:	c5 24 c6 fa dd       	vshufps $0xdd,%ymm2,%ymm11,%ymm15
  5718a5:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  5718ab:	c4 63 25 0c da aa    	vblendps $0xaa,%ymm2,%ymm11,%ymm11
  5718b1:	c5 fa 7e f6          	vmovq  %xmm6,%xmm6
  5718b5:	62 e1 4c 28 c6 c2 dd 	vshufps $0xdd,%ymm2,%ymm6,%ymm16
  5718bc:	62 a1 7c 20 c6 c0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm16
  5718c3:	c4 e3 4d 0c d2 aa    	vblendps $0xaa,%ymm2,%ymm6,%ymm2
  5718c9:	c5 9c 58 f2          	vaddps %ymm2,%ymm12,%ymm6
  5718cd:	62 e1 24 28 58 cd    	vaddps %ymm5,%ymm11,%ymm17
  5718d3:	62 c1 7c 20 58 d6    	vaddps %ymm14,%ymm16,%ymm18
  5718d9:	62 c1 04 28 58 dd    	vaddps %ymm13,%ymm15,%ymm19
  5718df:	62 e1 64 28 58 e0    	vaddps %ymm0,%ymm3,%ymm20
  5718e5:	62 e1 5c 28 58 e9    	vaddps %ymm1,%ymm4,%ymm21
  5718eb:	62 c1 2c 28 58 f0    	vaddps %ymm8,%ymm10,%ymm22
  5718f1:	62 e1 34 28 58 ff    	vaddps %ymm7,%ymm9,%ymm23
  5718f7:	c4 c1 6c 5c d4       	vsubps %ymm12,%ymm2,%ymm2
  5718fc:	c5 dc 5c c9          	vsubps %ymm1,%ymm4,%ymm1
  571900:	62 d1 7c 20 5c e6    	vsubps %ymm14,%ymm16,%ymm4
  571906:	c4 41 2c 5c c0       	vsubps %ymm8,%ymm10,%ymm8
  57190b:	c4 62 7d 18 15 d4 a9 	vbroadcastss -0x4f562c(%rip),%ymm10        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  571912:	b0 ff 
  571914:	c5 3c 58 e4          	vaddps %ymm4,%ymm8,%ymm12
  571918:	c4 41 1c 59 e2       	vmulps %ymm10,%ymm12,%ymm12
  57191d:	c5 b4 5c ff          	vsubps %ymm7,%ymm9,%ymm7
  571921:	c4 41 04 5c cd       	vsubps %ymm13,%ymm15,%ymm9
  571926:	c4 41 44 5c e9       	vsubps %ymm9,%ymm7,%ymm13
  57192b:	c4 41 14 59 ea       	vmulps %ymm10,%ymm13,%ymm13
  571930:	c5 e4 5c c0          	vsubps %ymm0,%ymm3,%ymm0
  571934:	c4 c1 54 5c db       	vsubps %ymm11,%ymm5,%ymm3
  571939:	c5 bc 5c e4          	vsubps %ymm4,%ymm8,%ymm4
  57193d:	c5 ac 59 e4          	vmulps %ymm4,%ymm10,%ymm4
  571941:	c5 b4 58 ef          	vaddps %ymm7,%ymm9,%ymm5
  571945:	c5 ac 59 ed          	vmulps %ymm5,%ymm10,%ymm5
  571949:	62 b1 4c 08 58 f9    	vaddps %xmm17,%xmm6,%xmm7
  57194f:	62 31 6c 00 58 c3    	vaddps %xmm19,%xmm18,%xmm8
  571955:	c5 38 58 cf          	vaddps %xmm7,%xmm8,%xmm9
  571959:	62 31 5c 00 58 d5    	vaddps %xmm21,%xmm20,%xmm10
  57195f:	62 31 4c 00 58 df    	vaddps %xmm23,%xmm22,%xmm11
  571965:	c4 41 28 58 f3       	vaddps %xmm11,%xmm10,%xmm14
  57196a:	c4 41 08 14 c9       	vunpcklps %xmm9,%xmm14,%xmm9
  57196f:	c4 41 18 58 f5       	vaddps %xmm13,%xmm12,%xmm14
  571974:	c5 68 58 f9          	vaddps %xmm1,%xmm2,%xmm15
  571978:	62 c1 04 08 58 c6    	vaddps %xmm14,%xmm15,%xmm16
  57197e:	62 61 5c 08 5c c5    	vsubps %xmm5,%xmm4,%xmm24
  571984:	62 61 64 08 58 c8    	vaddps %xmm0,%xmm3,%xmm25
  57198a:	62 01 34 00 58 d0    	vaddps %xmm24,%xmm25,%xmm26
  571990:	62 a1 2c 00 14 c0    	vunpcklps %xmm16,%xmm26,%xmm16
  571996:	62 31 34 08 16 c8    	vmovlhps %xmm16,%xmm9,%xmm9
  57199c:	c5 78 11 0e          	vmovups %xmm9,(%rsi)
  5719a0:	62 b1 4c 08 5c f1    	vsubps %xmm17,%xmm6,%xmm6
  5719a6:	62 31 4c 00 5c cf    	vsubps %xmm23,%xmm22,%xmm9
  5719ac:	62 c1 4c 08 58 c1    	vaddps %xmm9,%xmm6,%xmm16
  5719b2:	62 a1 5c 00 5c cd    	vsubps %xmm21,%xmm20,%xmm17
  5719b8:	62 a1 64 00 5c d2    	vsubps %xmm18,%xmm19,%xmm18
  5719be:	62 a1 6c 00 58 d9    	vaddps %xmm17,%xmm18,%xmm19
  5719c4:	62 a1 64 00 14 c0    	vunpcklps %xmm16,%xmm19,%xmm16
  5719ca:	c5 d8 58 e5          	vaddps %xmm5,%xmm4,%xmm4
  5719ce:	c5 e8 5c c9          	vsubps %xmm1,%xmm2,%xmm1
  5719d2:	c5 f0 58 d4          	vaddps %xmm4,%xmm1,%xmm2
  5719d6:	c4 c1 10 5c ec       	vsubps %xmm12,%xmm13,%xmm5
  5719db:	c5 f8 5c c3          	vsubps %xmm3,%xmm0,%xmm0
  5719df:	c5 f8 58 dd          	vaddps %xmm5,%xmm0,%xmm3
  5719e3:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  5719e7:	62 f1 7c 00 16 d2    	vmovlhps %xmm2,%xmm16,%xmm2
  5719ed:	c5 f8 11 56 10       	vmovups %xmm2,0x10(%rsi)
  5719f2:	c4 c1 40 5c d0       	vsubps %xmm8,%xmm7,%xmm2
  5719f7:	c4 c1 28 5c db       	vsubps %xmm11,%xmm10,%xmm3
  5719fc:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  571a00:	c4 c1 00 5c de       	vsubps %xmm14,%xmm15,%xmm3
  571a05:	62 91 34 00 5c f8    	vsubps %xmm24,%xmm25,%xmm7
  571a0b:	c5 c0 14 db          	vunpcklps %xmm3,%xmm7,%xmm3
  571a0f:	c5 e8 16 d3          	vmovlhps %xmm3,%xmm2,%xmm2
  571a13:	c5 f8 11 56 20       	vmovups %xmm2,0x20(%rsi)
  571a18:	c4 c1 48 5c d1       	vsubps %xmm9,%xmm6,%xmm2
  571a1d:	62 b1 74 00 5c da    	vsubps %xmm18,%xmm17,%xmm3
  571a23:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  571a27:	c5 f0 5c cc          	vsubps %xmm4,%xmm1,%xmm1
  571a2b:	c5 f8 5c c5          	vsubps %xmm5,%xmm0,%xmm0
  571a2f:	c5 f8 14 c1          	vunpcklps %xmm1,%xmm0,%xmm0
  571a33:	c5 e8 16 c0          	vmovlhps %xmm0,%xmm2,%xmm0
  571a37:	c5 f8 11 46 30       	vmovups %xmm0,0x30(%rsi)
  571a3c:	c5 f8 77             	vzeroupper
  571a3f:	c3                   	ret


0000000000571a40 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  571a40:	c5 fc 10 0f          	vmovups (%rdi),%ymm1
  571a44:	c5 fc 10 57 20       	vmovups 0x20(%rdi),%ymm2
  571a49:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  571a4e:	c5 fc 10 7f 60       	vmovups 0x60(%rdi),%ymm7
  571a53:	c5 7c 10 87 80 00 00 	vmovups 0x80(%rdi),%ymm8
  571a5a:	00 
  571a5b:	c5 7c 10 8f a0 00 00 	vmovups 0xa0(%rdi),%ymm9
  571a62:	00 
  571a63:	c5 7c 10 97 c0 00 00 	vmovups 0xc0(%rdi),%ymm10
  571a6a:	00 
  571a6b:	c5 7c 10 9f e0 00 00 	vmovups 0xe0(%rdi),%ymm11
  571a72:	00 
  571a73:	c5 7c 10 af 00 01 00 	vmovups 0x100(%rdi),%ymm13
  571a7a:	00 
  571a7b:	c5 7c 10 b7 20 01 00 	vmovups 0x120(%rdi),%ymm14
  571a82:	00 
  571a83:	c5 f4 c6 da dd       	vshufps $0xdd,%ymm2,%ymm1,%ymm3
  571a88:	62 e3 fd 28 01 c3 d8 	vpermpd $0xd8,%ymm3,%ymm16
  571a8f:	c5 fc c6 df dd       	vshufps $0xdd,%ymm7,%ymm0,%ymm3
  571a94:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  571a9a:	c4 c1 14 c6 e6 dd    	vshufps $0xdd,%ymm14,%ymm13,%ymm4
  571aa0:	c4 e3 fd 01 e4 d8    	vpermpd $0xd8,%ymm4,%ymm4
  571aa6:	62 e1 64 28 58 d4    	vaddps %ymm4,%ymm3,%ymm18
  571aac:	62 31 7c 20 58 e2    	vaddps %ymm18,%ymm16,%ymm12
  571ab2:	c4 c1 3c c6 e9 dd    	vshufps $0xdd,%ymm9,%ymm8,%ymm5
  571ab8:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  571abe:	c4 c1 2c c6 f3 dd    	vshufps $0xdd,%ymm11,%ymm10,%ymm6
  571ac4:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  571aca:	62 e1 54 28 58 de    	vaddps %ymm6,%ymm5,%ymm19
  571ad0:	62 a1 1c 28 58 e3    	vaddps %ymm19,%ymm12,%ymm20
  571ad6:	c5 fc c6 c7 88       	vshufps $0x88,%ymm7,%ymm0,%ymm0
  571adb:	c4 63 fd 01 e0 d8    	vpermpd $0xd8,%ymm0,%ymm12
  571ae1:	c4 c1 14 c6 c6 88    	vshufps $0x88,%ymm14,%ymm13,%ymm0
  571ae7:	c4 63 fd 01 f0 d8    	vpermpd $0xd8,%ymm0,%ymm14
  571aed:	c4 c1 1c 5c c6       	vsubps %ymm14,%ymm12,%ymm0
  571af2:	c4 c1 3c c6 f9 88    	vshufps $0x88,%ymm9,%ymm8,%ymm7
  571af8:	c4 63 fd 01 ff d8    	vpermpd $0xd8,%ymm7,%ymm15
  571afe:	c4 c1 2c c6 fb 88    	vshufps $0x88,%ymm11,%ymm10,%ymm7
  571b04:	62 e3 fd 28 01 cf d8 	vpermpd $0xd8,%ymm7,%ymm17
  571b0b:	62 31 04 28 5c d9    	vsubps %ymm17,%ymm15,%ymm11
  571b11:	c4 62 7d 18 05 7e ae 	vbroadcastss -0x4f5182(%rip),%ymm8        # 7c998 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x30a8>
  571b18:	b0 ff 
  571b1a:	c4 41 24 59 e8       	vmulps %ymm8,%ymm11,%ymm13
  571b1f:	c4 62 7d 18 0d b4 a7 	vbroadcastss -0x4f584c(%rip),%ymm9        # 7c2dc <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29ec>
  571b26:	b0 ff 
  571b28:	c4 62 7d 18 15 7b ad 	vbroadcastss -0x4f5285(%rip),%ymm10        # 7c8ac <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2fbc>
  571b2f:	b0 ff 
  571b31:	c4 42 7d b8 e9       	vfmadd231ps %ymm9,%ymm0,%ymm13
  571b36:	62 c1 7c 28 28 ea    	vmovaps %ymm10,%ymm21
  571b3c:	c4 e2 7d 18 3d 23 ac 	vbroadcastss -0x4f53dd(%rip),%ymm7        # 7c768 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2e78>
  571b43:	b0 ff 
  571b45:	62 a2 6d 20 a8 e8    	vfmadd213ps %ymm16,%ymm18,%ymm21
  571b4b:	62 e2 65 20 bc ef    	vfnmadd231ps %ymm7,%ymm19,%ymm21
  571b51:	62 a1 14 28 58 f5    	vaddps %ymm21,%ymm13,%ymm22
  571b57:	62 a3 dd 20 23 fe 03 	vshuff64x2 $0x3,%ymm22,%ymm20,%ymm23
  571b5e:	62 a2 45 28 ac d0    	vfnmadd213ps %ymm16,%ymm7,%ymm18
  571b64:	62 a2 2d 28 b8 d3    	vfmadd231ps %ymm19,%ymm10,%ymm18
  571b6a:	c5 bc 59 c0          	vmulps %ymm0,%ymm8,%ymm0
  571b6e:	c4 c2 35 bc c3       	vfnmadd231ps %ymm11,%ymm9,%ymm0
  571b73:	62 e1 6c 20 5c d8    	vsubps %ymm0,%ymm18,%ymm19
  571b79:	62 a3 7d 28 19 d8 01 	vextractf32x4 $0x1,%ymm19,%xmm16
  571b80:	62 21 c5 20 15 c0    	vunpckhpd %ymm16,%ymm23,%ymm24
  571b86:	62 c1 54 20 5c ed    	vsubps %ymm13,%ymm21,%ymm21
  571b8c:	62 83 7d 28 19 e9 01 	vextractf32x4 $0x1,%ymm21,%xmm25
  571b93:	62 b1 7c 28 58 c2    	vaddps %ymm18,%ymm0,%ymm0
  571b99:	62 b3 7d 28 19 c2 01 	vextractf32x4 $0x1,%ymm0,%xmm18
  571ba0:	62 31 b5 20 15 ea    	vunpckhpd %ymm18,%ymm25,%ymm13
  571ba6:	62 51 3c 20 c6 dd dd 	vshufps $0xdd,%ymm13,%ymm24,%ymm11
  571bad:	62 51 3c 20 c6 ed 88 	vshufps $0x88,%ymm13,%ymm24,%ymm13
  571bb4:	62 a1 c5 20 14 f8    	vunpcklpd %ymm16,%ymm23,%ymm23
  571bba:	62 a1 b5 20 14 d2    	vunpcklpd %ymm18,%ymm25,%ymm18
  571bc0:	62 a1 44 20 c6 c2 dd 	vshufps $0xdd,%ymm18,%ymm23,%ymm16
  571bc7:	62 a1 44 20 c6 d2 88 	vshufps $0x88,%ymm18,%ymm23,%ymm18
  571bce:	62 a3 5d 20 18 e6 01 	vinsertf32x4 $0x1,%xmm22,%ymm20,%ymm20
  571bd5:	62 a1 7c 08 28 db    	vmovaps %xmm19,%xmm19
  571bdb:	62 a1 dd 20 15 f3    	vunpckhpd %ymm19,%ymm20,%ymm22
  571be1:	62 a1 7c 08 28 ed    	vmovaps %xmm21,%xmm21
  571be7:	c5 f8 28 c0          	vmovaps %xmm0,%xmm0
  571beb:	62 e1 d5 20 15 f8    	vunpckhpd %ymm0,%ymm21,%ymm23
  571bf1:	62 21 4c 20 c6 c7 dd 	vshufps $0xdd,%ymm23,%ymm22,%ymm24
  571bf8:	62 a1 4c 20 c6 f7 88 	vshufps $0x88,%ymm23,%ymm22,%ymm22
  571bff:	62 a1 dd 20 14 db    	vunpcklpd %ymm19,%ymm20,%ymm19
  571c05:	62 f1 d5 20 14 c0    	vunpcklpd %ymm0,%ymm21,%ymm0
  571c0b:	62 e1 64 20 c6 e0 dd 	vshufps $0xdd,%ymm0,%ymm19,%ymm20
  571c12:	62 f1 64 20 c6 c0 88 	vshufps $0x88,%ymm0,%ymm19,%ymm0
  571c19:	c5 f4 c6 ca 88       	vshufps $0x88,%ymm2,%ymm1,%ymm1
  571c1e:	c4 c1 1c 58 d6       	vaddps %ymm14,%ymm12,%ymm2
  571c23:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  571c29:	62 31 04 28 58 e1    	vaddps %ymm17,%ymm15,%ymm12
  571c2f:	c5 74 58 f2          	vaddps %ymm2,%ymm1,%ymm14
  571c33:	c4 41 0c 58 fc       	vaddps %ymm12,%ymm14,%ymm15
  571c38:	c5 e4 5c dc          	vsubps %ymm4,%ymm3,%ymm3
  571c3c:	c5 7c 29 d4          	vmovaps %ymm10,%ymm4
  571c40:	c4 e2 6d a8 e1       	vfmadd213ps %ymm1,%ymm2,%ymm4
  571c45:	c4 e2 1d bc e7       	vfnmadd231ps %ymm7,%ymm12,%ymm4
  571c4a:	c5 d4 5c ee          	vsubps %ymm6,%ymm5,%ymm5
  571c4e:	c5 bc 59 f5          	vmulps %ymm5,%ymm8,%ymm6
  571c52:	c4 c2 65 b8 f1       	vfmadd231ps %ymm9,%ymm3,%ymm6
  571c57:	c4 e2 6d ac f9       	vfnmadd213ps %ymm1,%ymm2,%ymm7
  571c5c:	62 e1 5c 28 5c ce    	vsubps %ymm6,%ymm4,%ymm17
  571c62:	62 33 85 28 23 f1 03 	vshuff64x2 $0x3,%ymm17,%ymm15,%ymm14
  571c69:	c4 c2 1d b8 fa       	vfmadd231ps %ymm10,%ymm12,%ymm7
  571c6e:	c5 bc 59 cb          	vmulps %ymm3,%ymm8,%ymm1
  571c72:	c4 c2 55 bc c9       	vfnmadd231ps %ymm9,%ymm5,%ymm1
  571c77:	c5 44 58 c1          	vaddps %ymm1,%ymm7,%ymm8
  571c7b:	c4 63 7d 19 c5 01    	vextractf128 $0x1,%ymm8,%xmm5
  571c81:	c5 8d 15 d5          	vunpckhpd %ymm5,%ymm14,%ymm2
  571c85:	c5 5c 58 ce          	vaddps %ymm6,%ymm4,%ymm9
  571c89:	62 33 7d 28 19 cb 01 	vextractf32x4 $0x1,%ymm9,%xmm19
  571c90:	62 e1 44 28 5c e9    	vsubps %ymm1,%ymm7,%ymm21
  571c96:	62 a3 7d 28 19 ef 01 	vextractf32x4 $0x1,%ymm21,%xmm23
  571c9d:	62 b1 e5 20 15 cf    	vunpckhpd %ymm23,%ymm19,%ymm1
  571ca3:	c5 6c c6 d1 dd       	vshufps $0xdd,%ymm1,%ymm2,%ymm10
  571ca8:	62 61 6c 28 c6 c9 88 	vshufps $0x88,%ymm1,%ymm2,%ymm25
  571caf:	c4 c1 24 c6 cb d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm1
  571cb5:	c4 c1 14 c6 fd d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm7
  571cbb:	62 b1 7c 20 c6 e0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm4
  571cc2:	62 31 6c 20 c6 ea d8 	vshufps $0xd8,%ymm18,%ymm18,%ymm13
  571cc9:	62 91 3c 20 c6 d8 d8 	vshufps $0xd8,%ymm24,%ymm24,%ymm3
  571cd0:	62 31 4c 20 c6 e6 d8 	vshufps $0xd8,%ymm22,%ymm22,%ymm12
  571cd7:	62 b1 5c 20 c6 f4 d8 	vshufps $0xd8,%ymm20,%ymm20,%ymm6
  571cde:	c4 c1 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm2
  571ce4:	62 11 34 20 c6 d1 d8 	vshufps $0xd8,%ymm25,%ymm25,%ymm10
  571ceb:	c5 0d 14 dd          	vunpcklpd %ymm5,%ymm14,%ymm11
  571cef:	62 31 e5 20 14 f7    	vunpcklpd %ymm23,%ymm19,%ymm14
  571cf5:	c4 c1 24 c6 ee dd    	vshufps $0xdd,%ymm14,%ymm11,%ymm5
  571cfb:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  571d00:	c4 41 24 c6 de 88    	vshufps $0x88,%ymm14,%ymm11,%ymm11
  571d06:	c4 41 24 c6 f3 d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm14
  571d0c:	62 33 05 28 18 d9 01 	vinsertf32x4 $0x1,%xmm17,%ymm15,%ymm11
  571d13:	c4 41 78 28 f8       	vmovaps %xmm8,%xmm15
  571d18:	62 c1 a5 28 15 c7    	vunpckhpd %ymm15,%ymm11,%ymm16
  571d1e:	c4 41 78 28 c9       	vmovaps %xmm9,%xmm9
  571d23:	62 a1 7c 08 28 cd    	vmovaps %xmm21,%xmm17
  571d29:	62 a1 b5 28 15 d1    	vunpckhpd %ymm17,%ymm9,%ymm18
  571d2f:	62 31 7c 20 c6 c2 dd 	vshufps $0xdd,%ymm18,%ymm16,%ymm8
  571d36:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  571d3c:	62 a1 7c 20 c6 c2 88 	vshufps $0x88,%ymm18,%ymm16,%ymm16
  571d43:	62 a1 7c 20 c6 c0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm16
  571d4a:	c4 41 25 14 df       	vunpcklpd %ymm15,%ymm11,%ymm11
  571d4f:	62 31 b5 28 14 c9    	vunpcklpd %ymm17,%ymm9,%ymm9
  571d55:	c4 41 24 c6 f9 dd    	vshufps $0xdd,%ymm9,%ymm11,%ymm15
  571d5b:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  571d61:	c4 41 24 c6 c9 88    	vshufps $0x88,%ymm9,%ymm11,%ymm9
  571d67:	62 e1 7c 28 10 4a 08 	vmovups 0x100(%rdx),%ymm17
  571d6e:	62 e1 7c 28 10 52 09 	vmovups 0x120(%rdx),%ymm18
  571d75:	62 31 0c 28 59 d9    	vmulps %ymm17,%ymm14,%ymm11
  571d7b:	62 32 15 28 bc da    	vfnmadd231ps %ymm18,%ymm13,%ymm11
  571d81:	62 31 14 28 59 e9    	vmulps %ymm17,%ymm13,%ymm13
  571d87:	62 e1 7c 28 10 4a 04 	vmovups 0x80(%rdx),%ymm17
  571d8e:	62 32 0d 28 b8 ea    	vfmadd231ps %ymm18,%ymm14,%ymm13
  571d94:	62 e1 7c 28 10 52 05 	vmovups 0xa0(%rdx),%ymm18
  571d9b:	62 31 7c 20 59 f1    	vmulps %ymm17,%ymm16,%ymm14
  571da1:	62 32 1d 28 bc f2    	vfnmadd231ps %ymm18,%ymm12,%ymm14
  571da7:	62 a1 1c 28 59 c9    	vmulps %ymm17,%ymm12,%ymm17
  571dad:	62 e1 7c 28 10 5a 0c 	vmovups 0x180(%rdx),%ymm19
  571db4:	62 a2 7d 20 b8 ca    	vfmadd231ps %ymm18,%ymm16,%ymm17
  571dba:	62 e1 7c 28 10 42 0d 	vmovups 0x1a0(%rdx),%ymm16
  571dc1:	62 31 2c 28 59 e3    	vmulps %ymm19,%ymm10,%ymm12
  571dc7:	62 32 45 28 bc e0    	vfnmadd231ps %ymm16,%ymm7,%ymm12
  571dcd:	62 b1 44 28 59 fb    	vmulps %ymm19,%ymm7,%ymm7
  571dd3:	62 e1 7c 28 10 52 02 	vmovups 0x40(%rdx),%ymm18
  571dda:	62 b2 2d 28 b8 f8    	vfmadd231ps %ymm16,%ymm10,%ymm7
  571de0:	c5 7c 10 52 60       	vmovups 0x60(%rdx),%ymm10
  571de5:	62 a1 04 28 59 c2    	vmulps %ymm18,%ymm15,%ymm16
  571deb:	62 c2 4d 28 bc c2    	vfnmadd231ps %ymm10,%ymm6,%ymm16
  571df1:	62 b1 4c 28 59 f2    	vmulps %ymm18,%ymm6,%ymm6
  571df7:	62 e1 7c 28 10 52 0a 	vmovups 0x140(%rdx),%ymm18
  571dfe:	c4 c2 05 b8 f2       	vfmadd231ps %ymm10,%ymm15,%ymm6
  571e03:	c5 7c 10 92 60 01 00 	vmovups 0x160(%rdx),%ymm10
  571e0a:	00 
  571e0b:	62 31 54 28 59 fa    	vmulps %ymm18,%ymm5,%ymm15
  571e11:	c4 42 5d bc fa       	vfnmadd231ps %ymm10,%ymm4,%ymm15
  571e16:	62 b1 5c 28 59 e2    	vmulps %ymm18,%ymm4,%ymm4
  571e1c:	62 e1 7c 28 10 52 06 	vmovups 0xc0(%rdx),%ymm18
  571e23:	c4 c2 55 b8 e2       	vfmadd231ps %ymm10,%ymm5,%ymm4
  571e28:	c5 fc 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm5
  571e2f:	00 
  571e30:	62 31 3c 28 59 d2    	vmulps %ymm18,%ymm8,%ymm10
  571e36:	c4 62 65 bc d5       	vfnmadd231ps %ymm5,%ymm3,%ymm10
  571e3b:	62 b1 64 28 59 da    	vmulps %ymm18,%ymm3,%ymm3
  571e41:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  571e48:	c4 e2 3d b8 dd       	vfmadd231ps %ymm5,%ymm8,%ymm3
  571e4d:	c5 fc 10 aa e0 01 00 	vmovups 0x1e0(%rdx),%ymm5
  571e54:	00 
  571e55:	62 31 6c 28 59 c2    	vmulps %ymm18,%ymm2,%ymm8
  571e5b:	c4 62 75 bc c5       	vfnmadd231ps %ymm5,%ymm1,%ymm8
  571e60:	62 b1 74 28 59 ca    	vmulps %ymm18,%ymm1,%ymm1
  571e66:	c5 fc c6 c0 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm0
  571e6b:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  571e71:	c4 e2 6d b8 cd       	vfmadd231ps %ymm5,%ymm2,%ymm1
  571e76:	c4 c1 34 58 d3       	vaddps %ymm11,%ymm9,%ymm2
  571e7b:	c4 c1 0c 58 ec       	vaddps %ymm12,%ymm14,%ymm5
  571e80:	c4 41 34 5c cb       	vsubps %ymm11,%ymm9,%ymm9
  571e85:	62 71 74 20 58 df    	vaddps %ymm7,%ymm17,%ymm11
  571e8b:	62 f1 74 20 5c ff    	vsubps %ymm7,%ymm17,%ymm7
  571e91:	62 c1 7c 20 58 cf    	vaddps %ymm15,%ymm16,%ymm17
  571e97:	62 51 7c 20 5c ff    	vsubps %ymm15,%ymm16,%ymm15
  571e9d:	62 e1 4c 28 58 c4    	vaddps %ymm4,%ymm6,%ymm16
  571ea3:	c5 cc 5c e4          	vsubps %ymm4,%ymm6,%ymm4
  571ea7:	c5 e4 58 f1          	vaddps %ymm1,%ymm3,%ymm6
  571eab:	c5 e4 5c c9          	vsubps %ymm1,%ymm3,%ymm1
  571eaf:	c4 c1 2c 58 d8       	vaddps %ymm8,%ymm10,%ymm3
  571eb4:	c4 41 2c 5c c0       	vsubps %ymm8,%ymm10,%ymm8
  571eb9:	c5 14 58 d0          	vaddps %ymm0,%ymm13,%ymm10
  571ebd:	c4 c1 7c 5c c5       	vsubps %ymm13,%ymm0,%ymm0
  571ec2:	c5 6c 58 ed          	vaddps %ymm5,%ymm2,%ymm13
  571ec6:	c4 41 1c 5c e6       	vsubps %ymm14,%ymm12,%ymm12
  571ecb:	c5 04 58 f4          	vaddps %ymm4,%ymm15,%ymm14
  571ecf:	c4 c1 5c 5c e7       	vsubps %ymm15,%ymm4,%ymm4
  571ed4:	c4 41 74 5c f8       	vsubps %ymm8,%ymm1,%ymm15
  571ed9:	c5 bc 58 c9          	vaddps %ymm1,%ymm8,%ymm1
  571edd:	c4 62 7d 18 05 02 a4 	vbroadcastss -0x4f5bfe(%rip),%ymm8        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  571ee4:	b0 ff 
  571ee6:	c4 41 0c 59 f0       	vmulps %ymm8,%ymm14,%ymm14
  571eeb:	c4 41 04 59 f8       	vmulps %ymm8,%ymm15,%ymm15
  571ef0:	c5 bc 59 e4          	vmulps %ymm4,%ymm8,%ymm4
  571ef4:	c5 bc 59 c9          	vmulps %ymm1,%ymm8,%ymm1
  571ef8:	62 71 74 20 58 c3    	vaddps %ymm3,%ymm17,%ymm8
  571efe:	c5 ec 5c d5          	vsubps %ymm5,%ymm2,%ymm2
  571f02:	62 f1 7c 20 58 ee    	vaddps %ymm6,%ymm16,%ymm5
  571f08:	62 f1 7c 20 5c f6    	vsubps %ymm6,%ymm16,%ymm6
  571f0e:	62 c1 24 28 58 c2    	vaddps %ymm10,%ymm11,%ymm16
  571f14:	c4 41 2c 5c d3       	vsubps %ymm11,%ymm10,%ymm10
  571f19:	c4 41 14 58 d8       	vaddps %ymm8,%ymm13,%ymm11
  571f1e:	62 b1 64 28 5c d9    	vsubps %ymm17,%ymm3,%ymm3
  571f24:	62 e1 34 28 58 cf    	vaddps %ymm7,%ymm9,%ymm17
  571f2a:	c5 b4 5c ff          	vsubps %ymm7,%ymm9,%ymm7
  571f2e:	c5 5c 5c c9          	vsubps %ymm1,%ymm4,%ymm9
  571f32:	c5 dc 58 c9          	vaddps %ymm1,%ymm4,%ymm1
  571f36:	c5 9c 58 e0          	vaddps %ymm0,%ymm12,%ymm4
  571f3a:	c4 c1 7c 5c c4       	vsubps %ymm12,%ymm0,%ymm0
  571f3f:	c4 41 0c 58 e7       	vaddps %ymm15,%ymm14,%ymm12
  571f44:	c4 41 04 5c f6       	vsubps %ymm14,%ymm15,%ymm14
  571f49:	62 71 7c 20 58 fd    	vaddps %ymm5,%ymm16,%ymm15
  571f4f:	c4 41 14 5c c0       	vsubps %ymm8,%ymm13,%ymm8
  571f54:	62 51 74 20 58 ec    	vaddps %ymm12,%ymm17,%ymm13
  571f5a:	62 f1 7c 20 5c ed    	vsubps %ymm5,%ymm16,%ymm5
  571f60:	62 c1 5c 28 58 c1    	vaddps %ymm9,%ymm4,%ymm16
  571f66:	62 51 74 20 5c e4    	vsubps %ymm12,%ymm17,%ymm12
  571f6c:	62 e1 6c 28 58 ce    	vaddps %ymm6,%ymm2,%ymm17
  571f72:	c4 c1 5c 5c e1       	vsubps %ymm9,%ymm4,%ymm4
  571f77:	c5 2c 58 cb          	vaddps %ymm3,%ymm10,%ymm9
  571f7b:	c5 ec 5c d6          	vsubps %ymm6,%ymm2,%ymm2
  571f7f:	c5 c4 58 f1          	vaddps %ymm1,%ymm7,%ymm6
  571f83:	c5 ac 5c db          	vsubps %ymm3,%ymm10,%ymm3
  571f87:	c5 0c 58 d0          	vaddps %ymm0,%ymm14,%ymm10
  571f8b:	c5 c4 5c c9          	vsubps %ymm1,%ymm7,%ymm1
  571f8f:	c4 c1 7c 5c c6       	vsubps %ymm14,%ymm0,%ymm0
  571f94:	c5 fc 28 3d a4 ed b0 	vmovaps -0x4f125c(%rip),%ymm7        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  571f9b:	ff 
  571f9c:	c4 43 7d 19 de 01    	vextractf128 $0x1,%ymm11,%xmm14
  571fa2:	62 52 45 28 7f df    	vpermt2ps %ymm15,%ymm7,%ymm11
  571fa8:	c5 7c 11 1e          	vmovups %ymm11,(%rsi)
  571fac:	c4 43 7d 19 fb 01    	vextractf128 $0x1,%ymm15,%xmm11
  571fb2:	c4 41 08 14 db       	vunpcklps %xmm11,%xmm14,%xmm11
  571fb7:	c5 78 13 5e 20       	vmovlps %xmm11,0x20(%rsi)
  571fbc:	c4 43 7d 19 eb 01    	vextractf128 $0x1,%ymm13,%xmm11
  571fc2:	62 32 45 28 7f e8    	vpermt2ps %ymm16,%ymm7,%ymm13
  571fc8:	c5 7c 11 6e 28       	vmovups %ymm13,0x28(%rsi)
  571fcd:	62 c3 7d 28 19 c5 01 	vextractf32x4 $0x1,%ymm16,%xmm13
  571fd4:	c4 41 20 14 dd       	vunpcklps %xmm13,%xmm11,%xmm11
  571fd9:	c5 78 13 5e 48       	vmovlps %xmm11,0x48(%rsi)
  571fde:	62 c3 7d 28 19 cb 01 	vextractf32x4 $0x1,%ymm17,%xmm11
  571fe5:	62 c2 45 28 7f c9    	vpermt2ps %ymm9,%ymm7,%ymm17
  571feb:	62 e1 7c 28 11 8e 50 	vmovups %ymm17,0x50(%rsi)
  571ff2:	00 00 00 
  571ff5:	c4 43 7d 19 c9 01    	vextractf128 $0x1,%ymm9,%xmm9
  571ffb:	c4 41 20 14 c9       	vunpcklps %xmm9,%xmm11,%xmm9
  572000:	c5 78 13 4e 70       	vmovlps %xmm9,0x70(%rsi)
  572005:	c4 c3 7d 19 f1 01    	vextractf128 $0x1,%ymm6,%xmm9
  57200b:	62 d2 45 28 7f f2    	vpermt2ps %ymm10,%ymm7,%ymm6
  572011:	c5 fc 11 76 78       	vmovups %ymm6,0x78(%rsi)
  572016:	c4 63 7d 19 d6 01    	vextractf128 $0x1,%ymm10,%xmm6
  57201c:	c5 b0 14 f6          	vunpcklps %xmm6,%xmm9,%xmm6
  572020:	c5 f8 13 b6 98 00 00 	vmovlps %xmm6,0x98(%rsi)
  572027:	00 
  572028:	c4 63 7d 19 c6 01    	vextractf128 $0x1,%ymm8,%xmm6
  57202e:	62 72 45 28 7f c5    	vpermt2ps %ymm5,%ymm7,%ymm8
  572034:	c5 7c 11 86 a0 00 00 	vmovups %ymm8,0xa0(%rsi)
  57203b:	00 
  57203c:	c4 e3 7d 19 ed 01    	vextractf128 $0x1,%ymm5,%xmm5
  572042:	c5 c8 14 ed          	vunpcklps %xmm5,%xmm6,%xmm5
  572046:	c5 f8 13 ae c0 00 00 	vmovlps %xmm5,0xc0(%rsi)
  57204d:	00 
  57204e:	c4 63 7d 19 e5 01    	vextractf128 $0x1,%ymm12,%xmm5
  572054:	62 72 45 28 7f e4    	vpermt2ps %ymm4,%ymm7,%ymm12
  57205a:	c5 7c 11 a6 c8 00 00 	vmovups %ymm12,0xc8(%rsi)
  572061:	00 
  572062:	c4 e3 7d 19 e4 01    	vextractf128 $0x1,%ymm4,%xmm4
  572068:	c5 d0 14 e4          	vunpcklps %xmm4,%xmm5,%xmm4
  57206c:	c5 f8 13 a6 e8 00 00 	vmovlps %xmm4,0xe8(%rsi)
  572073:	00 
  572074:	c4 e3 7d 19 d4 01    	vextractf128 $0x1,%ymm2,%xmm4
  57207a:	62 f2 45 28 7f d3    	vpermt2ps %ymm3,%ymm7,%ymm2
  572080:	c5 fc 11 96 f0 00 00 	vmovups %ymm2,0xf0(%rsi)
  572087:	00 
  572088:	c4 e3 7d 19 da 01    	vextractf128 $0x1,%ymm3,%xmm2
  57208e:	c5 d8 14 d2          	vunpcklps %xmm2,%xmm4,%xmm2
  572092:	c5 f8 13 96 10 01 00 	vmovlps %xmm2,0x110(%rsi)
  572099:	00 
  57209a:	62 f2 75 28 77 f8    	vpermi2ps %ymm0,%ymm1,%ymm7
  5720a0:	c5 fc 11 be 18 01 00 	vmovups %ymm7,0x118(%rsi)
  5720a7:	00 
  5720a8:	c4 e3 7d 19 c0 01    	vextractf128 $0x1,%ymm0,%xmm0
  5720ae:	c4 e3 7d 19 c9 01    	vextractf128 $0x1,%ymm1,%xmm1
  5720b4:	c5 f0 14 c0          	vunpcklps %xmm0,%xmm1,%xmm0
  5720b8:	c5 f8 13 86 38 01 00 	vmovlps %xmm0,0x138(%rsi)
  5720bf:	00 
  5720c0:	c5 f8 77             	vzeroupper
  5720c3:	c3                   	ret
  5720c4:	cc                   	int3
  5720c5:	cc                   	int3
  5720c6:	cc                   	int3
  5720c7:	cc                   	int3
  5720c8:	cc                   	int3
  5720c9:	cc                   	int3
  5720ca:	cc                   	int3
  5720cb:	cc                   	int3
  5720cc:	cc                   	int3
  5720cd:	cc                   	int3
  5720ce:	cc                   	int3
  5720cf:	cc                   	int3


00000000005720d0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  5720d0:	c5 fc 10 2f          	vmovups (%rdi),%ymm5
  5720d4:	c5 fc 10 77 20       	vmovups 0x20(%rdi),%ymm6
  5720d9:	c5 d4 c6 de dd       	vshufps $0xdd,%ymm6,%ymm5,%ymm3
  5720de:	c4 e3 fd 01 e3 d8    	vpermpd $0xd8,%ymm3,%ymm4
  5720e4:	c4 e3 7d 19 e0 01    	vextractf128 $0x1,%ymm4,%xmm0
  5720ea:	c5 e8 57 d2          	vxorps %xmm2,%xmm2,%xmm2
  5720ee:	c5 fd 15 ca          	vunpckhpd %ymm2,%ymm0,%ymm1
  5720f2:	c5 f4 c6 fa dd       	vshufps $0xdd,%ymm2,%ymm1,%ymm7
  5720f7:	c5 c4 c6 ff d8       	vshufps $0xd8,%ymm7,%ymm7,%ymm7
  5720fc:	c4 e3 75 0c ca aa    	vblendps $0xaa,%ymm2,%ymm1,%ymm1
  572102:	c4 e3 7d 0c c2 cc    	vblendps $0xcc,%ymm2,%ymm0,%ymm0
  572108:	c5 7c c6 c2 dd       	vshufps $0xdd,%ymm2,%ymm0,%ymm8
  57210d:	c4 41 3c c6 c0 d8    	vshufps $0xd8,%ymm8,%ymm8,%ymm8
  572113:	c4 e3 7d 0c c2 aa    	vblendps $0xaa,%ymm2,%ymm0,%ymm0
  572119:	c5 f8 28 e4          	vmovaps %xmm4,%xmm4
  57211d:	c5 dd 73 dc 08       	vpsrldq $0x8,%ymm4,%ymm4
  572122:	c5 5c c6 ca dd       	vshufps $0xdd,%ymm2,%ymm4,%ymm9
  572127:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  57212d:	c4 e3 5d 0c e2 aa    	vblendps $0xaa,%ymm2,%ymm4,%ymm4
  572133:	c5 fa 7e db          	vmovq  %xmm3,%xmm3
  572137:	c5 64 c6 d2 dd       	vshufps $0xdd,%ymm2,%ymm3,%ymm10
  57213c:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  572142:	c4 e3 65 0c da aa    	vblendps $0xaa,%ymm2,%ymm3,%ymm3
  572148:	c5 d4 c6 f6 88       	vshufps $0x88,%ymm6,%ymm5,%ymm6
  57214d:	c4 63 fd 01 de d8    	vpermpd $0xd8,%ymm6,%ymm11
  572153:	c4 43 7d 19 dc 01    	vextractf128 $0x1,%ymm11,%xmm12
  572159:	c5 9d 15 ea          	vunpckhpd %ymm2,%ymm12,%ymm5
  57215d:	c5 54 c6 ea dd       	vshufps $0xdd,%ymm2,%ymm5,%ymm13
  572162:	c4 41 14 c6 ed d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm13
  572168:	c4 e3 55 0c ea aa    	vblendps $0xaa,%ymm2,%ymm5,%ymm5
  57216e:	c4 63 1d 0c e2 cc    	vblendps $0xcc,%ymm2,%ymm12,%ymm12
  572174:	c5 1c c6 f2 dd       	vshufps $0xdd,%ymm2,%ymm12,%ymm14
  572179:	c4 41 0c c6 f6 d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm14
  57217f:	c4 63 1d 0c e2 aa    	vblendps $0xaa,%ymm2,%ymm12,%ymm12
  572185:	c4 41 78 28 db       	vmovaps %xmm11,%xmm11
  57218a:	c4 c1 25 73 db 08    	vpsrldq $0x8,%ymm11,%ymm11
  572190:	c5 24 c6 fa dd       	vshufps $0xdd,%ymm2,%ymm11,%ymm15
  572195:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  57219b:	c4 63 25 0c da aa    	vblendps $0xaa,%ymm2,%ymm11,%ymm11
  5721a1:	c5 fa 7e f6          	vmovq  %xmm6,%xmm6
  5721a5:	62 e1 4c 28 c6 c2 dd 	vshufps $0xdd,%ymm2,%ymm6,%ymm16
  5721ac:	62 a1 7c 20 c6 c0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm16
  5721b3:	c4 e3 4d 0c d2 aa    	vblendps $0xaa,%ymm2,%ymm6,%ymm2
  5721b9:	c5 9c 58 f2          	vaddps %ymm2,%ymm12,%ymm6
  5721bd:	62 e1 24 28 58 cd    	vaddps %ymm5,%ymm11,%ymm17
  5721c3:	62 c1 7c 20 58 d6    	vaddps %ymm14,%ymm16,%ymm18
  5721c9:	62 c1 04 28 58 dd    	vaddps %ymm13,%ymm15,%ymm19
  5721cf:	62 e1 64 28 58 e0    	vaddps %ymm0,%ymm3,%ymm20
  5721d5:	62 e1 5c 28 58 e9    	vaddps %ymm1,%ymm4,%ymm21
  5721db:	62 c1 2c 28 58 f0    	vaddps %ymm8,%ymm10,%ymm22
  5721e1:	62 e1 34 28 58 ff    	vaddps %ymm7,%ymm9,%ymm23
  5721e7:	c4 c1 6c 5c d4       	vsubps %ymm12,%ymm2,%ymm2
  5721ec:	c5 dc 5c c9          	vsubps %ymm1,%ymm4,%ymm1
  5721f0:	62 d1 7c 20 5c e6    	vsubps %ymm14,%ymm16,%ymm4
  5721f6:	c4 41 2c 5c c0       	vsubps %ymm8,%ymm10,%ymm8
  5721fb:	c4 62 7d 18 15 e4 a0 	vbroadcastss -0x4f5f1c(%rip),%ymm10        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  572202:	b0 ff 
  572204:	c5 3c 58 e4          	vaddps %ymm4,%ymm8,%ymm12
  572208:	c4 41 1c 59 e2       	vmulps %ymm10,%ymm12,%ymm12
  57220d:	c5 b4 5c ff          	vsubps %ymm7,%ymm9,%ymm7
  572211:	c4 41 04 5c cd       	vsubps %ymm13,%ymm15,%ymm9
  572216:	c4 41 44 5c e9       	vsubps %ymm9,%ymm7,%ymm13
  57221b:	c4 41 14 59 ea       	vmulps %ymm10,%ymm13,%ymm13
  572220:	c5 e4 5c c0          	vsubps %ymm0,%ymm3,%ymm0
  572224:	c4 c1 54 5c db       	vsubps %ymm11,%ymm5,%ymm3
  572229:	c5 bc 5c e4          	vsubps %ymm4,%ymm8,%ymm4
  57222d:	c5 ac 59 e4          	vmulps %ymm4,%ymm10,%ymm4
  572231:	c5 b4 58 ef          	vaddps %ymm7,%ymm9,%ymm5
  572235:	c5 ac 59 ed          	vmulps %ymm5,%ymm10,%ymm5
  572239:	62 b1 5c 00 58 fd    	vaddps %xmm21,%xmm20,%xmm7
  57223f:	62 31 4c 00 58 c7    	vaddps %xmm23,%xmm22,%xmm8
  572245:	c5 38 58 cf          	vaddps %xmm7,%xmm8,%xmm9
  572249:	62 31 4c 08 58 d1    	vaddps %xmm17,%xmm6,%xmm10
  57224f:	62 31 6c 00 58 db    	vaddps %xmm19,%xmm18,%xmm11
  572255:	c4 41 28 58 f3       	vaddps %xmm11,%xmm10,%xmm14
  57225a:	c4 41 08 14 c9       	vunpcklps %xmm9,%xmm14,%xmm9
  57225f:	c5 58 5c f5          	vsubps %xmm5,%xmm4,%xmm14
  572263:	c5 60 58 f8          	vaddps %xmm0,%xmm3,%xmm15
  572267:	62 c1 04 08 58 c6    	vaddps %xmm14,%xmm15,%xmm16
  57226d:	62 41 1c 08 58 c5    	vaddps %xmm13,%xmm12,%xmm24
  572273:	62 61 6c 08 58 c9    	vaddps %xmm1,%xmm2,%xmm25
  572279:	62 01 34 00 58 d0    	vaddps %xmm24,%xmm25,%xmm26
  57227f:	62 a1 2c 00 14 c0    	vunpcklps %xmm16,%xmm26,%xmm16
  572285:	62 31 34 08 16 c8    	vmovlhps %xmm16,%xmm9,%xmm9
  57228b:	c5 78 11 0e          	vmovups %xmm9,(%rsi)
  57228f:	62 31 5c 00 5c cd    	vsubps %xmm21,%xmm20,%xmm9
  572295:	62 a1 64 00 5c c2    	vsubps %xmm18,%xmm19,%xmm16
  57229b:	62 c1 7c 00 58 d1    	vaddps %xmm9,%xmm16,%xmm18
  5722a1:	62 b1 4c 08 5c f1    	vsubps %xmm17,%xmm6,%xmm6
  5722a7:	62 a1 4c 00 5c cf    	vsubps %xmm23,%xmm22,%xmm17
  5722ad:	62 a1 4c 08 58 d9    	vaddps %xmm17,%xmm6,%xmm19
  5722b3:	62 a1 64 00 14 d2    	vunpcklps %xmm18,%xmm19,%xmm18
  5722b9:	c4 41 10 5c e4       	vsubps %xmm12,%xmm13,%xmm12
  5722be:	c5 f8 5c c3          	vsubps %xmm3,%xmm0,%xmm0
  5722c2:	c5 98 58 d8          	vaddps %xmm0,%xmm12,%xmm3
  5722c6:	c5 d8 58 e5          	vaddps %xmm5,%xmm4,%xmm4
  5722ca:	c5 e8 5c c9          	vsubps %xmm1,%xmm2,%xmm1
  5722ce:	c5 f0 58 d4          	vaddps %xmm4,%xmm1,%xmm2
  5722d2:	c5 e8 14 d3          	vunpcklps %xmm3,%xmm2,%xmm2
  5722d6:	62 f1 6c 00 16 d2    	vmovlhps %xmm2,%xmm18,%xmm2
  5722dc:	c5 f8 11 56 10       	vmovups %xmm2,0x10(%rsi)
  5722e1:	c4 c1 40 5c d0       	vsubps %xmm8,%xmm7,%xmm2
  5722e6:	c4 c1 28 5c db       	vsubps %xmm11,%xmm10,%xmm3
  5722eb:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  5722ef:	c4 c1 00 5c de       	vsubps %xmm14,%xmm15,%xmm3
  5722f4:	62 91 34 00 5c e8    	vsubps %xmm24,%xmm25,%xmm5
  5722fa:	c5 d0 14 db          	vunpcklps %xmm3,%xmm5,%xmm3
  5722fe:	c5 e8 16 d3          	vmovlhps %xmm3,%xmm2,%xmm2
  572302:	c5 f8 11 56 20       	vmovups %xmm2,0x20(%rsi)
  572307:	62 b1 34 08 5c d0    	vsubps %xmm16,%xmm9,%xmm2
  57230d:	62 b1 4c 08 5c d9    	vsubps %xmm17,%xmm6,%xmm3
  572313:	c5 e0 14 d2          	vunpcklps %xmm2,%xmm3,%xmm2
  572317:	c4 c1 78 5c c4       	vsubps %xmm12,%xmm0,%xmm0
  57231c:	c5 f0 5c cc          	vsubps %xmm4,%xmm1,%xmm1
  572320:	c5 f0 14 c0          	vunpcklps %xmm0,%xmm1,%xmm0
  572324:	c5 e8 16 c0          	vmovlhps %xmm0,%xmm2,%xmm0
  572328:	c5 f8 11 46 30       	vmovups %xmm0,0x30(%rsi)
  57232d:	c5 f8 77             	vzeroupper
  572330:	c3                   	ret
  572331:	cc                   	int3
  572332:	cc                   	int3
  572333:	cc                   	int3
  572334:	cc                   	int3
  572335:	cc                   	int3
  572336:	cc                   	int3
  572337:	cc                   	int3
  572338:	cc                   	int3
  572339:	cc                   	int3
  57233a:	cc                   	int3
  57233b:	cc                   	int3
  57233c:	cc                   	int3
  57233d:	cc                   	int3
  57233e:	cc                   	int3
  57233f:	cc                   	int3


0000000000572340 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  572340:	c5 fc 10 07          	vmovups (%rdi),%ymm0
  572344:	c5 fc 10 4f 20       	vmovups 0x20(%rdi),%ymm1
  572349:	c5 fc 10 57 40       	vmovups 0x40(%rdi),%ymm2
  57234e:	c5 fc 10 5f 60       	vmovups 0x60(%rdi),%ymm3
  572353:	c5 fc 10 a7 80 00 00 	vmovups 0x80(%rdi),%ymm4
  57235a:	00 
  57235b:	c5 fc 10 af a0 00 00 	vmovups 0xa0(%rdi),%ymm5
  572362:	00 
  572363:	c5 fc 10 b7 c0 00 00 	vmovups 0xc0(%rdi),%ymm6
  57236a:	00 
  57236b:	c5 fc 10 bf e0 00 00 	vmovups 0xe0(%rdi),%ymm7
  572372:	00 
  572373:	c5 7c c6 c1 88       	vshufps $0x88,%ymm1,%ymm0,%ymm8
  572378:	c4 43 fd 01 c8 d8    	vpermpd $0xd8,%ymm8,%ymm9
  57237e:	c5 5c c6 c5 88       	vshufps $0x88,%ymm5,%ymm4,%ymm8
  572383:	c4 43 fd 01 d0 d8    	vpermpd $0xd8,%ymm8,%ymm10
  572389:	c4 41 34 58 c2       	vaddps %ymm10,%ymm9,%ymm8
  57238e:	c5 6c c6 db 88       	vshufps $0x88,%ymm3,%ymm2,%ymm11
  572393:	c4 43 fd 01 db d8    	vpermpd $0xd8,%ymm11,%ymm11
  572399:	c5 4c c6 e7 88       	vshufps $0x88,%ymm7,%ymm6,%ymm12
  57239e:	c4 43 fd 01 e4 d8    	vpermpd $0xd8,%ymm12,%ymm12
  5723a4:	c4 41 24 58 ec       	vaddps %ymm12,%ymm11,%ymm13
  5723a9:	c4 41 3c 58 f5       	vaddps %ymm13,%ymm8,%ymm14
  5723ae:	c4 41 3c 5c ed       	vsubps %ymm13,%ymm8,%ymm13
  5723b3:	c4 41 0d 15 c5       	vunpckhpd %ymm13,%ymm14,%ymm8
  5723b8:	c5 cc c6 f7 dd       	vshufps $0xdd,%ymm7,%ymm6,%ymm6
  5723bd:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  5723c3:	c5 ec c6 d3 dd       	vshufps $0xdd,%ymm3,%ymm2,%ymm2
  5723c8:	c4 e3 fd 01 d2 d8    	vpermpd $0xd8,%ymm2,%ymm2
  5723ce:	c5 cc 5c da          	vsubps %ymm2,%ymm6,%ymm3
  5723d2:	c4 c1 34 5c fa       	vsubps %ymm10,%ymm9,%ymm7
  5723d7:	c5 64 58 cf          	vaddps %ymm7,%ymm3,%ymm9
  5723db:	c5 c4 5c db          	vsubps %ymm3,%ymm7,%ymm3
  5723df:	c5 35 15 fb          	vunpckhpd %ymm3,%ymm9,%ymm15
  5723e3:	c4 41 0d 14 d5       	vunpcklpd %ymm13,%ymm14,%ymm10
  5723e8:	c5 35 14 cb          	vunpcklpd %ymm3,%ymm9,%ymm9
  5723ec:	c5 fc c6 c1 dd       	vshufps $0xdd,%ymm1,%ymm0,%ymm0
  5723f1:	c4 e3 fd 01 c0 d8    	vpermpd $0xd8,%ymm0,%ymm0
  5723f7:	c5 dc c6 cd dd       	vshufps $0xdd,%ymm5,%ymm4,%ymm1
  5723fc:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  572402:	c5 fc 58 d9          	vaddps %ymm1,%ymm0,%ymm3
  572406:	c5 ec 58 d6          	vaddps %ymm6,%ymm2,%ymm2
  57240a:	c5 e4 58 e2          	vaddps %ymm2,%ymm3,%ymm4
  57240e:	c5 e4 5c d2          	vsubps %ymm2,%ymm3,%ymm2
  572412:	c5 5d 15 ea          	vunpckhpd %ymm2,%ymm4,%ymm13
  572416:	c5 fc 5c c1          	vsubps %ymm1,%ymm0,%ymm0
  57241a:	c4 c1 24 5c cc       	vsubps %ymm12,%ymm11,%ymm1
  57241f:	c5 fc 58 d9          	vaddps %ymm1,%ymm0,%ymm3
  572423:	c5 fc 5c c1          	vsubps %ymm1,%ymm0,%ymm0
  572427:	62 e1 e5 28 15 c0    	vunpckhpd %ymm0,%ymm3,%ymm16
  57242d:	c5 dd 14 d2          	vunpcklpd %ymm2,%ymm4,%ymm2
  572431:	c5 e5 14 d8          	vunpcklpd %ymm0,%ymm3,%ymm3
  572435:	c5 e8 c6 c3 88       	vshufps $0x88,%xmm3,%xmm2,%xmm0
  57243a:	c5 f8 29 44 24 e8    	vmovaps %xmm0,-0x18(%rsp)
  572440:	c4 e3 7d 19 dd 01    	vextractf128 $0x1,%ymm3,%xmm5
  572446:	c4 e3 7d 19 d6 01    	vextractf128 $0x1,%ymm2,%xmm6
  57244c:	c5 c8 c6 cd 88       	vshufps $0x88,%xmm5,%xmm6,%xmm1
  572451:	c5 f0 c6 e1 d8       	vshufps $0xd8,%xmm1,%xmm1,%xmm4
  572456:	c4 c1 28 c6 c1 88    	vshufps $0x88,%xmm9,%xmm10,%xmm0
  57245c:	c5 f8 29 44 24 d8    	vmovaps %xmm0,-0x28(%rsp)
  572462:	c4 43 7d 19 cb 01    	vextractf128 $0x1,%ymm9,%xmm11
  572468:	c4 43 7d 19 d4 01    	vextractf128 $0x1,%ymm10,%xmm12
  57246e:	c4 c1 18 c6 fb 88    	vshufps $0x88,%xmm11,%xmm12,%xmm7
  572474:	62 61 44 08 c6 e7 d8 	vshufps $0xd8,%xmm7,%xmm7,%xmm28
  57247b:	c5 e8 c6 d3 dd       	vshufps $0xdd,%xmm3,%xmm2,%xmm2
  572480:	c5 e8 c6 ca d8       	vshufps $0xd8,%xmm2,%xmm2,%xmm1
  572485:	c5 c8 c6 d5 dd       	vshufps $0xdd,%xmm5,%xmm6,%xmm2
  57248a:	c5 e8 c6 c2 d8       	vshufps $0xd8,%xmm2,%xmm2,%xmm0
  57248f:	c5 f8 29 44 24 98    	vmovaps %xmm0,-0x68(%rsp)
  572495:	c4 c1 28 c6 e9 dd    	vshufps $0xdd,%xmm9,%xmm10,%xmm5
  57249b:	c5 d0 c6 dd d8       	vshufps $0xd8,%xmm5,%xmm5,%xmm3
  5724a0:	c4 c1 18 c6 eb dd    	vshufps $0xdd,%xmm11,%xmm12,%xmm5
  5724a6:	c5 d0 c6 d5 d8       	vshufps $0xd8,%xmm5,%xmm5,%xmm2
  5724ab:	62 31 14 08 c6 c8 88 	vshufps $0x88,%xmm16,%xmm13,%xmm9
  5724b2:	c4 41 30 c6 d9 d8    	vshufps $0xd8,%xmm9,%xmm9,%xmm11
  5724b8:	62 c3 7d 28 19 c1 01 	vextractf32x4 $0x1,%ymm16,%xmm9
  5724bf:	62 33 7d 28 19 e9 01 	vextractf32x4 $0x1,%ymm13,%xmm17
  5724c6:	62 51 74 00 c6 d1 88 	vshufps $0x88,%xmm9,%xmm17,%xmm10
  5724cd:	c4 c1 28 c6 f2 d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm6
  5724d3:	c5 f8 29 74 24 88    	vmovaps %xmm6,-0x78(%rsp)
  5724d9:	c4 41 38 c6 d7 88    	vshufps $0x88,%xmm15,%xmm8,%xmm10
  5724df:	c4 41 28 c6 f2 d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm14
  5724e5:	62 33 7d 28 19 fa 01 	vextractf32x4 $0x1,%ymm15,%xmm18
  5724ec:	62 33 7d 28 19 c3 01 	vextractf32x4 $0x1,%ymm8,%xmm19
  5724f3:	62 31 64 00 c6 d2 88 	vshufps $0x88,%xmm18,%xmm19,%xmm10
  5724fa:	c4 41 28 c6 e2 d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm12
  572500:	62 31 14 08 c6 d0 dd 	vshufps $0xdd,%xmm16,%xmm13,%xmm10
  572507:	c4 c1 28 c6 ea d8    	vshufps $0xd8,%xmm10,%xmm10,%xmm5
  57250d:	62 d1 74 00 c6 f9 dd 	vshufps $0xdd,%xmm9,%xmm17,%xmm7
  572514:	c5 f8 29 7c 24 a8    	vmovaps %xmm7,-0x58(%rsp)
  57251a:	c4 41 38 c6 c7 dd    	vshufps $0xdd,%xmm15,%xmm8,%xmm8
  572520:	c4 41 38 c6 f8 d8    	vshufps $0xd8,%xmm8,%xmm8,%xmm15
  572526:	62 a1 64 00 c6 c2 dd 	vshufps $0xdd,%xmm18,%xmm19,%xmm16
  57252d:	62 e1 7c 08 10 4a 04 	vmovups 0x40(%rdx),%xmm17
  572534:	62 e1 7c 08 10 52 06 	vmovups 0x60(%rdx),%xmm18
  57253b:	62 e1 7c 08 10 5a 08 	vmovups 0x80(%rdx),%xmm19
  572542:	62 e1 7c 08 10 6a 0a 	vmovups 0xa0(%rdx),%xmm21
  572549:	62 e1 7c 08 10 72 10 	vmovups 0x100(%rdx),%xmm22
  572550:	62 e1 7c 08 10 7a 12 	vmovups 0x120(%rdx),%xmm23
  572557:	62 61 7c 08 10 42 14 	vmovups 0x140(%rdx),%xmm24
  57255e:	62 61 7c 08 10 4a 16 	vmovups 0x160(%rdx),%xmm25
  572565:	62 61 7c 08 10 52 18 	vmovups 0x180(%rdx),%xmm26
  57256c:	62 61 7c 08 10 5a 1a 	vmovups 0x1a0(%rdx),%xmm27
  572573:	62 31 5c 08 59 c6    	vmulps %xmm22,%xmm4,%xmm8
  572579:	c5 f8 28 fc          	vmovaps %xmm4,%xmm7
  57257d:	62 31 1c 00 59 cf    	vmulps %xmm23,%xmm28,%xmm9
  572583:	62 c1 3c 08 5c e1    	vsubps %xmm9,%xmm8,%xmm20
  572589:	62 31 24 08 59 c3    	vmulps %xmm19,%xmm11,%xmm8
  57258f:	62 31 0c 08 59 cd    	vmulps %xmm21,%xmm14,%xmm9
  572595:	c4 c1 38 5c e1       	vsubps %xmm9,%xmm8,%xmm4
  57259a:	c5 f8 29 64 24 c8    	vmovaps %xmm4,-0x38(%rsp)
  5725a0:	62 11 4c 08 59 ca    	vmulps %xmm26,%xmm6,%xmm9
  5725a6:	62 01 1c 08 59 eb    	vmulps %xmm27,%xmm12,%xmm29
  5725ac:	62 91 34 08 5c e5    	vsubps %xmm29,%xmm9,%xmm4
  5725b2:	c5 f8 29 64 24 b8    	vmovaps %xmm4,-0x48(%rsp)
  5725b8:	62 21 74 08 59 e9    	vmulps %xmm17,%xmm1,%xmm29
  5725be:	c5 78 28 e9          	vmovaps %xmm1,%xmm13
  5725c2:	62 21 64 08 59 f2    	vmulps %xmm18,%xmm3,%xmm30
  5725c8:	c5 f8 28 f3          	vmovaps %xmm3,%xmm6
  5725cc:	62 01 14 00 5c ee    	vsubps %xmm30,%xmm29,%xmm29
  5725d2:	62 01 7c 08 59 f0    	vmulps %xmm24,%xmm0,%xmm30
  5725d8:	62 01 6c 08 59 f9    	vmulps %xmm25,%xmm2,%xmm31
  5725de:	c5 78 28 d2          	vmovaps %xmm2,%xmm10
  5725e2:	62 01 0c 00 5c f7    	vsubps %xmm31,%xmm30,%xmm30
  5725e8:	62 61 7c 08 10 7a 0c 	vmovups 0xc0(%rdx),%xmm31
  5725ef:	c5 f8 10 a2 e0 00 00 	vmovups 0xe0(%rdx),%xmm4
  5725f6:	00 
  5725f7:	62 91 54 08 59 c7    	vmulps %xmm31,%xmm5,%xmm0
  5725fd:	c5 78 28 cd          	vmovaps %xmm5,%xmm9
  572601:	c5 78 29 fb          	vmovaps %xmm15,%xmm3
  572605:	c5 80 59 d4          	vmulps %xmm4,%xmm15,%xmm2
  572609:	c5 78 5c c2          	vsubps %xmm2,%xmm0,%xmm8
  57260d:	c4 e3 79 04 54 24 a8 	vpermilps $0xd8,-0x58(%rsp),%xmm2
  572614:	d8 
  572615:	62 31 7c 00 c6 f8 d8 	vshufps $0xd8,%xmm16,%xmm16,%xmm15
  57261c:	62 e1 7c 08 10 42 1c 	vmovups 0x1c0(%rdx),%xmm16
  572623:	c5 f8 10 8a e0 01 00 	vmovups 0x1e0(%rdx),%xmm1
  57262a:	00 
  57262b:	62 b1 6c 08 59 c0    	vmulps %xmm16,%xmm2,%xmm0
  572631:	c5 80 59 e9          	vmulps %xmm1,%xmm15,%xmm5
  572635:	c5 f8 5c c5          	vsubps %xmm5,%xmm0,%xmm0
  572639:	62 b1 1c 00 59 ee    	vmulps %xmm22,%xmm28,%xmm5
  57263f:	62 f1 44 00 59 ff    	vmulps %xmm7,%xmm23,%xmm7
  572645:	c5 c0 58 ed          	vaddps %xmm5,%xmm7,%xmm5
  572649:	62 b1 0c 08 59 fb    	vmulps %xmm19,%xmm14,%xmm7
  57264f:	62 51 54 00 59 db    	vmulps %xmm11,%xmm21,%xmm11
  572655:	c5 a0 58 ff          	vaddps %xmm7,%xmm11,%xmm7
  572659:	62 11 1c 08 59 da    	vmulps %xmm26,%xmm12,%xmm11
  57265f:	62 71 24 00 59 a4 24 	vmulps -0x78(%rsp),%xmm27,%xmm12
  572666:	88 ff ff ff 
  57266a:	c4 41 18 58 db       	vaddps %xmm11,%xmm12,%xmm11
  57266f:	62 b1 4c 08 59 f1    	vmulps %xmm17,%xmm6,%xmm6
  572675:	62 51 6c 00 59 e5    	vmulps %xmm13,%xmm18,%xmm12
  57267b:	c5 98 58 f6          	vaddps %xmm6,%xmm12,%xmm6
  57267f:	62 11 2c 08 59 e0    	vmulps %xmm24,%xmm10,%xmm12
  572685:	62 71 34 00 59 b4 24 	vmulps -0x68(%rsp),%xmm25,%xmm14
  57268c:	98 ff ff ff 
  572690:	c4 41 08 58 e4       	vaddps %xmm12,%xmm14,%xmm12
  572695:	62 11 64 08 59 ef    	vmulps %xmm31,%xmm3,%xmm13
  57269b:	c5 b0 59 dc          	vmulps %xmm4,%xmm9,%xmm3
  57269f:	c5 90 58 db          	vaddps %xmm3,%xmm13,%xmm3
  5726a3:	62 31 04 08 59 d0    	vmulps %xmm16,%xmm15,%xmm10
  5726a9:	c5 f0 59 ca          	vmulps %xmm2,%xmm1,%xmm1
  5726ad:	c4 e3 79 04 54 24 e8 	vpermilps $0xd8,-0x18(%rsp),%xmm2
  5726b4:	d8 
  5726b5:	c4 63 79 04 6c 24 d8 	vpermilps $0xd8,-0x28(%rsp),%xmm13
  5726bc:	d8 
  5726bd:	c5 a8 58 c9          	vaddps %xmm1,%xmm10,%xmm1
  5726c1:	62 31 6c 08 58 d4    	vaddps %xmm20,%xmm2,%xmm10
  5726c7:	62 b1 6c 08 5c d4    	vsubps %xmm20,%xmm2,%xmm2
  5726cd:	c5 20 58 f7          	vaddps %xmm7,%xmm11,%xmm14
  5726d1:	c4 c1 40 5c fb       	vsubps %xmm11,%xmm7,%xmm7
  5726d6:	62 11 14 00 58 de    	vaddps %xmm30,%xmm29,%xmm11
  5726dc:	62 11 14 00 5c fe    	vsubps %xmm30,%xmm29,%xmm15
  5726e2:	62 c1 4c 08 58 c4    	vaddps %xmm12,%xmm6,%xmm16
  5726e8:	c4 c1 48 5c f4       	vsubps %xmm12,%xmm6,%xmm6
  5726ed:	c5 60 58 e1          	vaddps %xmm1,%xmm3,%xmm12
  5726f1:	c5 e0 5c c9          	vsubps %xmm1,%xmm3,%xmm1
  5726f5:	c5 b8 58 d8          	vaddps %xmm0,%xmm8,%xmm3
  5726f9:	c5 b8 5c c0          	vsubps %xmm0,%xmm8,%xmm0
  5726fd:	c5 90 58 e5          	vaddps %xmm5,%xmm13,%xmm4
  572701:	c5 90 5c ed          	vsubps %xmm5,%xmm13,%xmm5
  572705:	c5 78 28 44 24 c8    	vmovaps -0x38(%rsp),%xmm8
  57270b:	c5 78 28 4c 24 b8    	vmovaps -0x48(%rsp),%xmm9
  572711:	c4 41 38 58 e9       	vaddps %xmm9,%xmm8,%xmm13
  572716:	c4 41 30 5c c0       	vsubps %xmm8,%xmm9,%xmm8
  57271b:	c5 00 58 ce          	vaddps %xmm6,%xmm15,%xmm9
  57271f:	c4 c1 48 5c f7       	vsubps %xmm15,%xmm6,%xmm6
  572724:	c5 70 5c f8          	vsubps %xmm0,%xmm1,%xmm15
  572728:	c5 f8 58 c1          	vaddps %xmm1,%xmm0,%xmm0
  57272c:	c4 e2 79 18 0d b3 9b 	vbroadcastss -0x4f644d(%rip),%xmm1        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  572733:	b0 ff 
  572735:	c5 30 59 c9          	vmulps %xmm1,%xmm9,%xmm9
  572739:	c5 00 59 f9          	vmulps %xmm1,%xmm15,%xmm15
  57273d:	c5 c8 59 f1          	vmulps %xmm1,%xmm6,%xmm6
  572741:	c5 f8 59 c1          	vmulps %xmm1,%xmm0,%xmm0
  572745:	c4 c1 28 58 cd       	vaddps %xmm13,%xmm10,%xmm1
  57274a:	c4 41 28 5c d5       	vsubps %xmm13,%xmm10,%xmm10
  57274f:	62 51 7c 00 58 ec    	vaddps %xmm12,%xmm16,%xmm13
  572755:	62 51 7c 00 5c e4    	vsubps %xmm12,%xmm16,%xmm12
  57275b:	62 e1 0c 08 58 c4    	vaddps %xmm4,%xmm14,%xmm16
  572761:	c4 c1 58 5c e6       	vsubps %xmm14,%xmm4,%xmm4
  572766:	c5 20 58 f3          	vaddps %xmm3,%xmm11,%xmm14
  57276a:	c4 c1 60 5c db       	vsubps %xmm11,%xmm3,%xmm3
  57276f:	c5 68 58 df          	vaddps %xmm7,%xmm2,%xmm11
  572773:	c5 e8 5c d7          	vsubps %xmm7,%xmm2,%xmm2
  572777:	c5 c8 5c f8          	vsubps %xmm0,%xmm6,%xmm7
  57277b:	c5 c8 58 c0          	vaddps %xmm0,%xmm6,%xmm0
  57277f:	c5 b8 58 f5          	vaddps %xmm5,%xmm8,%xmm6
  572783:	c4 c1 50 5c e8       	vsubps %xmm8,%xmm5,%xmm5
  572788:	c4 41 30 58 c7       	vaddps %xmm15,%xmm9,%xmm8
  57278d:	c4 41 00 5c c9       	vsubps %xmm9,%xmm15,%xmm9
  572792:	c5 08 58 f9          	vaddps %xmm1,%xmm14,%xmm15
  572796:	c4 c1 70 5c ce       	vsubps %xmm14,%xmm1,%xmm1
  57279b:	62 51 7c 00 58 f5    	vaddps %xmm13,%xmm16,%xmm14
  5727a1:	62 51 7c 00 5c ed    	vsubps %xmm13,%xmm16,%xmm13
  5727a7:	62 c1 24 08 58 c0    	vaddps %xmm8,%xmm11,%xmm16
  5727ad:	c4 41 20 5c c0       	vsubps %xmm8,%xmm11,%xmm8
  5727b2:	c5 48 58 df          	vaddps %xmm7,%xmm6,%xmm11
  5727b6:	c5 c8 5c f7          	vsubps %xmm7,%xmm6,%xmm6
  5727ba:	c4 c1 28 58 fc       	vaddps %xmm12,%xmm10,%xmm7
  5727bf:	c4 41 28 5c d4       	vsubps %xmm12,%xmm10,%xmm10
  5727c4:	c5 58 58 e3          	vaddps %xmm3,%xmm4,%xmm12
  5727c8:	c5 d8 5c db          	vsubps %xmm3,%xmm4,%xmm3
  5727cc:	c5 e8 58 e0          	vaddps %xmm0,%xmm2,%xmm4
  5727d0:	c5 e8 5c c0          	vsubps %xmm0,%xmm2,%xmm0
  5727d4:	c5 b0 58 d5          	vaddps %xmm5,%xmm9,%xmm2
  5727d8:	c4 c1 50 5c e9       	vsubps %xmm9,%xmm5,%xmm5
  5727dd:	c4 41 08 14 cf       	vunpcklps %xmm15,%xmm14,%xmm9
  5727e2:	c4 41 08 15 f7       	vunpckhps %xmm15,%xmm14,%xmm14
  5727e7:	c5 78 11 0e          	vmovups %xmm9,(%rsi)
  5727eb:	c5 78 11 76 10       	vmovups %xmm14,0x10(%rsi)
  5727f0:	62 31 24 08 14 c8    	vunpcklps %xmm16,%xmm11,%xmm9
  5727f6:	62 31 24 08 15 d8    	vunpckhps %xmm16,%xmm11,%xmm11
  5727fc:	c5 78 11 4e 20       	vmovups %xmm9,0x20(%rsi)
  572801:	c5 78 11 5e 30       	vmovups %xmm11,0x30(%rsi)
  572806:	c5 18 14 cf          	vunpcklps %xmm7,%xmm12,%xmm9
  57280a:	c5 98 15 ff          	vunpckhps %xmm7,%xmm12,%xmm7
  57280e:	c5 78 11 4e 40       	vmovups %xmm9,0x40(%rsi)
  572813:	c5 f8 11 7e 50       	vmovups %xmm7,0x50(%rsi)
  572818:	c5 e8 14 fc          	vunpcklps %xmm4,%xmm2,%xmm7
  57281c:	c5 e8 15 d4          	vunpckhps %xmm4,%xmm2,%xmm2
  572820:	c5 f8 11 7e 60       	vmovups %xmm7,0x60(%rsi)
  572825:	c5 f8 11 56 70       	vmovups %xmm2,0x70(%rsi)
  57282a:	c5 90 14 d1          	vunpcklps %xmm1,%xmm13,%xmm2
  57282e:	c5 90 15 c9          	vunpckhps %xmm1,%xmm13,%xmm1
  572832:	c5 f8 11 96 80 00 00 	vmovups %xmm2,0x80(%rsi)
  572839:	00 
  57283a:	c5 f8 11 8e 90 00 00 	vmovups %xmm1,0x90(%rsi)
  572841:	00 
  572842:	c4 c1 48 14 c8       	vunpcklps %xmm8,%xmm6,%xmm1
  572847:	c4 c1 48 15 d0       	vunpckhps %xmm8,%xmm6,%xmm2
  57284c:	c5 f8 11 8e a0 00 00 	vmovups %xmm1,0xa0(%rsi)
  572853:	00 
  572854:	c5 f8 11 96 b0 00 00 	vmovups %xmm2,0xb0(%rsi)
  57285b:	00 
  57285c:	c4 c1 60 14 ca       	vunpcklps %xmm10,%xmm3,%xmm1
  572861:	c4 c1 60 15 d2       	vunpckhps %xmm10,%xmm3,%xmm2
  572866:	c5 f8 11 8e c0 00 00 	vmovups %xmm1,0xc0(%rsi)
  57286d:	00 
  57286e:	c5 f8 11 96 d0 00 00 	vmovups %xmm2,0xd0(%rsi)
  572875:	00 
  572876:	c5 d0 14 c8          	vunpcklps %xmm0,%xmm5,%xmm1
  57287a:	c5 d0 15 c0          	vunpckhps %xmm0,%xmm5,%xmm0
  57287e:	c5 f8 11 8e e0 00 00 	vmovups %xmm1,0xe0(%rsi)
  572885:	00 
  572886:	c5 f8 11 86 f0 00 00 	vmovups %xmm0,0xf0(%rsi)
  57288d:	00 
  57288e:	c5 f8 77             	vzeroupper
  572891:	c3                   	ret
  572892:	cc                   	int3
  572893:	cc                   	int3
  572894:	cc                   	int3
  572895:	cc                   	int3
  572896:	cc                   	int3
  572897:	cc                   	int3
  572898:	cc                   	int3
  572899:	cc                   	int3
  57289a:	cc                   	int3
  57289b:	cc                   	int3
  57289c:	cc                   	int3
  57289d:	cc                   	int3
  57289e:	cc                   	int3
  57289f:	cc                   	int3


00000000005728a0 <<fastfft::isa::x86::F32x8v as fastfft::engine::small::SmallVector>::one>:
  5728a0:	c5 fc 10 0f          	vmovups (%rdi),%ymm1
  5728a4:	c5 fc 10 57 20       	vmovups 0x20(%rdi),%ymm2
  5728a9:	c5 fc 10 47 40       	vmovups 0x40(%rdi),%ymm0
  5728ae:	c5 7c 10 5f 60       	vmovups 0x60(%rdi),%ymm11
  5728b3:	c5 7c 10 97 80 00 00 	vmovups 0x80(%rdi),%ymm10
  5728ba:	00 
  5728bb:	c5 7c 10 a7 a0 00 00 	vmovups 0xa0(%rdi),%ymm12
  5728c2:	00 
  5728c3:	c5 fc 10 9f c0 00 00 	vmovups 0xc0(%rdi),%ymm3
  5728ca:	00 
  5728cb:	c5 fc 10 a7 e0 00 00 	vmovups 0xe0(%rdi),%ymm4
  5728d2:	00 
  5728d3:	c5 7c 10 af 00 01 00 	vmovups 0x100(%rdi),%ymm13
  5728da:	00 
  5728db:	c5 7c 10 b7 20 01 00 	vmovups 0x120(%rdi),%ymm14
  5728e2:	00 
  5728e3:	62 e1 7c 28 10 47 0a 	vmovups 0x140(%rdi),%ymm16
  5728ea:	62 e1 7c 28 10 4f 0b 	vmovups 0x160(%rdi),%ymm17
  5728f1:	c5 f4 c6 ea dd       	vshufps $0xdd,%ymm2,%ymm1,%ymm5
  5728f6:	c4 63 fd 01 fd d8    	vpermpd $0xd8,%ymm5,%ymm15
  5728fc:	c4 c1 2c c6 ec dd    	vshufps $0xdd,%ymm12,%ymm10,%ymm5
  572902:	c4 e3 fd 01 ed d8    	vpermpd $0xd8,%ymm5,%ymm5
  572908:	c4 c1 14 c6 f6 dd    	vshufps $0xdd,%ymm14,%ymm13,%ymm6
  57290e:	c4 e3 fd 01 f6 d8    	vpermpd $0xd8,%ymm6,%ymm6
  572914:	62 e1 54 28 58 d6    	vaddps %ymm6,%ymm5,%ymm18
  57291a:	62 a1 04 28 58 da    	vaddps %ymm18,%ymm15,%ymm19
  572920:	c5 e4 c6 fc dd       	vshufps $0xdd,%ymm4,%ymm3,%ymm7
  572925:	62 e3 fd 28 01 e7 d8 	vpermpd $0xd8,%ymm7,%ymm20
  57292c:	62 b1 7c 20 c6 f9 dd 	vshufps $0xdd,%ymm17,%ymm16,%ymm7
  572933:	c4 e3 fd 01 ff d8    	vpermpd $0xd8,%ymm7,%ymm7
  572939:	c4 41 7c c6 c3 dd    	vshufps $0xdd,%ymm11,%ymm0,%ymm8
  57293f:	c4 43 fd 01 c8 d8    	vpermpd $0xd8,%ymm8,%ymm9
  572945:	62 c1 44 28 58 e9    	vaddps %ymm9,%ymm7,%ymm21
  57294b:	62 a1 5c 20 58 f5    	vaddps %ymm21,%ymm20,%ymm22
  572951:	62 a1 64 20 58 fe    	vaddps %ymm22,%ymm19,%ymm23
  572957:	c4 62 7d 18 05 c4 9a 	vbroadcastss -0x4f653c(%rip),%ymm8        # 7c424 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2b34>
  57295e:	b0 ff 
  572960:	62 c2 3d 28 ac d7    	vfnmadd213ps %ymm15,%ymm8,%ymm18
  572966:	c4 41 2c c6 d4 88    	vshufps $0x88,%ymm12,%ymm10,%ymm10
  57296c:	c4 43 fd 01 fa d8    	vpermpd $0xd8,%ymm10,%ymm15
  572972:	c4 41 14 c6 d6 88    	vshufps $0x88,%ymm14,%ymm13,%ymm10
  572978:	62 43 fd 28 01 c2 d8 	vpermpd $0xd8,%ymm10,%ymm24
  57297f:	62 11 04 28 5c e0    	vsubps %ymm24,%ymm15,%ymm12
  572985:	c4 62 7d 18 15 d6 97 	vbroadcastss -0x4f682a(%rip),%ymm10        # 7c164 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x2874>
  57298c:	b0 ff 
  57298e:	c4 41 1c 59 e2       	vmulps %ymm10,%ymm12,%ymm12
  572993:	62 51 6c 20 5c ec    	vsubps %ymm12,%ymm18,%ymm13
  572999:	62 a2 3d 28 ac ec    	vfnmadd213ps %ymm20,%ymm8,%ymm21
  57299f:	62 31 7c 20 c6 f1 88 	vshufps $0x88,%ymm17,%ymm16,%ymm14
  5729a6:	62 c3 fd 28 01 c6 d8 	vpermpd $0xd8,%ymm14,%ymm16
  5729ad:	c4 c1 7c c6 c3 88    	vshufps $0x88,%ymm11,%ymm0,%ymm0
  5729b3:	62 e3 fd 28 01 c8 d8 	vpermpd $0xd8,%ymm0,%ymm17
  5729ba:	62 b1 7c 20 5c c1    	vsubps %ymm17,%ymm16,%ymm0
  5729c0:	c5 ac 59 c0          	vmulps %ymm0,%ymm10,%ymm0
  5729c4:	62 71 54 20 5c d8    	vsubps %ymm0,%ymm21,%ymm11
  5729ca:	62 c1 14 28 58 e3    	vaddps %ymm11,%ymm13,%ymm20
  5729d0:	62 33 c5 20 23 f4 03 	vshuff64x2 $0x3,%ymm20,%ymm23,%ymm14
  5729d7:	62 31 1c 28 58 e2    	vaddps %ymm18,%ymm12,%ymm12
  5729dd:	62 b1 7c 28 58 c5    	vaddps %ymm21,%ymm0,%ymm0
  5729e3:	62 e1 1c 28 58 d0    	vaddps %ymm0,%ymm12,%ymm18
  5729e9:	62 a3 7d 28 19 d5 01 	vextractf32x4 $0x1,%ymm18,%xmm21
  5729f0:	62 21 8d 28 15 cd    	vunpckhpd %ymm21,%ymm14,%ymm25
  5729f6:	62 41 14 28 5c d3    	vsubps %ymm11,%ymm13,%ymm26
  5729fc:	c5 9c 5c c0          	vsubps %ymm0,%ymm12,%ymm0
  572a00:	62 73 ad 20 23 e8 03 	vshuff64x2 $0x3,%ymm0,%ymm26,%ymm13
  572a07:	62 a1 64 20 5c de    	vsubps %ymm22,%ymm19,%ymm19
  572a0d:	62 a3 7d 28 19 de 01 	vextractf32x4 $0x1,%ymm19,%xmm22
  572a14:	62 31 95 28 15 e6    	vunpckhpd %ymm22,%ymm13,%ymm12
  572a1a:	62 51 34 20 c6 dc dd 	vshufps $0xdd,%ymm12,%ymm25,%ymm11
  572a21:	62 51 34 20 c6 e4 88 	vshufps $0x88,%ymm12,%ymm25,%ymm12
  572a28:	62 31 8d 28 14 f5    	vunpcklpd %ymm21,%ymm14,%ymm14
  572a2e:	62 a1 95 28 14 ee    	vunpcklpd %ymm22,%ymm13,%ymm21
  572a34:	62 31 0c 28 c6 ed dd 	vshufps $0xdd,%ymm21,%ymm14,%ymm13
  572a3b:	62 31 0c 28 c6 f5 88 	vshufps $0x88,%ymm21,%ymm14,%ymm14
  572a42:	62 a3 45 20 18 e4 01 	vinsertf32x4 $0x1,%xmm20,%ymm23,%ymm20
  572a49:	62 a1 7c 08 28 d2    	vmovaps %xmm18,%xmm18
  572a4f:	62 a1 dd 20 15 ea    	vunpckhpd %ymm18,%ymm20,%ymm21
  572a55:	62 f3 2d 20 18 c0 01 	vinsertf32x4 $0x1,%xmm0,%ymm26,%ymm0
  572a5c:	62 a1 7c 08 28 db    	vmovaps %xmm19,%xmm19
  572a62:	62 a1 fd 28 15 f3    	vunpckhpd %ymm19,%ymm0,%ymm22
  572a68:	62 a1 54 20 c6 fe dd 	vshufps $0xdd,%ymm22,%ymm21,%ymm23
  572a6f:	62 a1 54 20 c6 ee 88 	vshufps $0x88,%ymm22,%ymm21,%ymm21
  572a76:	62 a1 dd 20 14 d2    	vunpcklpd %ymm18,%ymm20,%ymm18
  572a7c:	62 b1 fd 28 14 c3    	vunpcklpd %ymm19,%ymm0,%ymm0
  572a82:	62 e1 6c 20 c6 d8 dd 	vshufps $0xdd,%ymm0,%ymm18,%ymm19
  572a89:	62 f1 6c 20 c6 c0 88 	vshufps $0x88,%ymm0,%ymm18,%ymm0
  572a90:	c5 f4 c6 ca 88       	vshufps $0x88,%ymm2,%ymm1,%ymm1
  572a95:	c4 e3 fd 01 c9 d8    	vpermpd $0xd8,%ymm1,%ymm1
  572a9b:	62 91 04 28 58 d0    	vaddps %ymm24,%ymm15,%ymm2
  572aa1:	c5 74 58 fa          	vaddps %ymm2,%ymm1,%ymm15
  572aa5:	c5 e4 c6 dc 88       	vshufps $0x88,%ymm4,%ymm3,%ymm3
  572aaa:	c4 e3 fd 01 db d8    	vpermpd $0xd8,%ymm3,%ymm3
  572ab0:	62 b1 7c 20 58 e1    	vaddps %ymm17,%ymm16,%ymm4
  572ab6:	62 e1 64 28 58 c4    	vaddps %ymm4,%ymm3,%ymm16
  572abc:	62 a1 04 28 58 c8    	vaddps %ymm16,%ymm15,%ymm17
  572ac2:	c4 e2 3d ac d1       	vfnmadd213ps %ymm1,%ymm8,%ymm2
  572ac7:	c5 d4 5c ce          	vsubps %ymm6,%ymm5,%ymm1
  572acb:	c5 ac 59 c9          	vmulps %ymm1,%ymm10,%ymm1
  572acf:	c5 ec 58 e9          	vaddps %ymm1,%ymm2,%ymm5
  572ad3:	c4 62 5d ac c3       	vfnmadd213ps %ymm3,%ymm4,%ymm8
  572ad8:	c4 c1 44 5c d9       	vsubps %ymm9,%ymm7,%ymm3
  572add:	c5 ac 59 db          	vmulps %ymm3,%ymm10,%ymm3
  572ae1:	c5 bc 58 e3          	vaddps %ymm3,%ymm8,%ymm4
  572ae5:	c5 d4 58 fc          	vaddps %ymm4,%ymm5,%ymm7
  572ae9:	62 f3 f5 20 23 f7 03 	vshuff64x2 $0x3,%ymm7,%ymm17,%ymm6
  572af0:	c5 ec 5c c9          	vsubps %ymm1,%ymm2,%ymm1
  572af4:	c5 bc 5c d3          	vsubps %ymm3,%ymm8,%ymm2
  572af8:	c5 74 58 ca          	vaddps %ymm2,%ymm1,%ymm9
  572afc:	c4 63 7d 19 cb 01    	vextractf128 $0x1,%ymm9,%xmm3
  572b02:	c5 4d 15 c3          	vunpckhpd %ymm3,%ymm6,%ymm8
  572b06:	62 e1 54 28 5c d4    	vsubps %ymm4,%ymm5,%ymm18
  572b0c:	62 e1 74 28 5c e2    	vsubps %ymm2,%ymm1,%ymm20
  572b12:	62 b3 ed 20 23 ec 03 	vshuff64x2 $0x3,%ymm20,%ymm18,%ymm5
  572b19:	62 31 04 28 5c f8    	vsubps %ymm16,%ymm15,%ymm15
  572b1f:	62 33 7d 28 19 f8 01 	vextractf32x4 $0x1,%ymm15,%xmm16
  572b26:	62 b1 d5 28 15 c8    	vunpckhpd %ymm16,%ymm5,%ymm1
  572b2c:	c5 bc c6 d1 dd       	vshufps $0xdd,%ymm1,%ymm8,%ymm2
  572b31:	c5 3c c6 d1 88       	vshufps $0x88,%ymm1,%ymm8,%ymm10
  572b36:	62 e1 cd 28 14 f3    	vunpcklpd %ymm3,%ymm6,%ymm22
  572b3c:	c4 c1 24 c6 cb d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm1
  572b42:	c4 41 1c c6 c4 d8    	vshufps $0xd8,%ymm12,%ymm12,%ymm8
  572b48:	c4 c1 14 c6 e5 d8    	vshufps $0xd8,%ymm13,%ymm13,%ymm4
  572b4e:	c4 41 0c c6 ee d8    	vshufps $0xd8,%ymm14,%ymm14,%ymm13
  572b54:	62 b1 44 20 c6 df d8 	vshufps $0xd8,%ymm23,%ymm23,%ymm3
  572b5b:	62 31 54 20 c6 e5 d8 	vshufps $0xd8,%ymm21,%ymm21,%ymm12
  572b62:	62 b1 64 20 c6 f3 d8 	vshufps $0xd8,%ymm19,%ymm19,%ymm6
  572b69:	c5 ec c6 d2 d8       	vshufps $0xd8,%ymm2,%ymm2,%ymm2
  572b6e:	c4 41 2c c6 d2 d8    	vshufps $0xd8,%ymm10,%ymm10,%ymm10
  572b74:	62 31 d5 28 14 d8    	vunpcklpd %ymm16,%ymm5,%ymm11
  572b7a:	62 d1 4c 20 c6 eb dd 	vshufps $0xdd,%ymm11,%ymm22,%ymm5
  572b81:	c5 d4 c6 ed d8       	vshufps $0xd8,%ymm5,%ymm5,%ymm5
  572b86:	62 51 4c 20 c6 db 88 	vshufps $0x88,%ymm11,%ymm22,%ymm11
  572b8d:	c4 41 24 c6 f3 d8    	vshufps $0xd8,%ymm11,%ymm11,%ymm14
  572b93:	62 73 75 20 18 df 01 	vinsertf32x4 $0x1,%xmm7,%ymm17,%ymm11
  572b9a:	c4 41 78 28 c9       	vmovaps %xmm9,%xmm9
  572b9f:	62 c1 a5 28 15 c1    	vunpckhpd %ymm9,%ymm11,%ymm16
  572ba5:	62 a3 6d 20 18 cc 01 	vinsertf32x4 $0x1,%xmm20,%ymm18,%ymm17
  572bac:	c4 41 78 28 ff       	vmovaps %xmm15,%xmm15
  572bb1:	62 c1 f5 20 15 d7    	vunpckhpd %ymm15,%ymm17,%ymm18
  572bb7:	62 b1 7c 20 c6 fa dd 	vshufps $0xdd,%ymm18,%ymm16,%ymm7
  572bbe:	c5 c4 c6 ff d8       	vshufps $0xd8,%ymm7,%ymm7,%ymm7
  572bc3:	62 a1 7c 20 c6 c2 88 	vshufps $0x88,%ymm18,%ymm16,%ymm16
  572bca:	62 a1 7c 20 c6 c0 d8 	vshufps $0xd8,%ymm16,%ymm16,%ymm16
  572bd1:	c4 41 25 14 c9       	vunpcklpd %ymm9,%ymm11,%ymm9
  572bd6:	62 51 f5 20 14 df    	vunpcklpd %ymm15,%ymm17,%ymm11
  572bdc:	c4 41 34 c6 fb dd    	vshufps $0xdd,%ymm11,%ymm9,%ymm15
  572be2:	c4 41 04 c6 ff d8    	vshufps $0xd8,%ymm15,%ymm15,%ymm15
  572be8:	c4 41 34 c6 cb 88    	vshufps $0x88,%ymm11,%ymm9,%ymm9
  572bee:	62 e1 7c 28 10 4a 08 	vmovups 0x100(%rdx),%ymm17
  572bf5:	62 e1 7c 28 10 52 09 	vmovups 0x120(%rdx),%ymm18
  572bfc:	62 31 0c 28 59 d9    	vmulps %ymm17,%ymm14,%ymm11
  572c02:	62 32 15 28 bc da    	vfnmadd231ps %ymm18,%ymm13,%ymm11
  572c08:	62 31 14 28 59 e9    	vmulps %ymm17,%ymm13,%ymm13
  572c0e:	62 e1 7c 28 10 4a 04 	vmovups 0x80(%rdx),%ymm17
  572c15:	62 32 0d 28 b8 ea    	vfmadd231ps %ymm18,%ymm14,%ymm13
  572c1b:	62 e1 7c 28 10 52 05 	vmovups 0xa0(%rdx),%ymm18
  572c22:	62 31 7c 20 59 f1    	vmulps %ymm17,%ymm16,%ymm14
  572c28:	62 32 1d 28 bc f2    	vfnmadd231ps %ymm18,%ymm12,%ymm14
  572c2e:	62 a1 1c 28 59 c9    	vmulps %ymm17,%ymm12,%ymm17
  572c34:	62 e1 7c 28 10 5a 0c 	vmovups 0x180(%rdx),%ymm19
  572c3b:	62 a2 7d 20 b8 ca    	vfmadd231ps %ymm18,%ymm16,%ymm17
  572c41:	62 e1 7c 28 10 42 0d 	vmovups 0x1a0(%rdx),%ymm16
  572c48:	62 31 2c 28 59 e3    	vmulps %ymm19,%ymm10,%ymm12
  572c4e:	62 32 3d 28 bc e0    	vfnmadd231ps %ymm16,%ymm8,%ymm12
  572c54:	62 31 3c 28 59 c3    	vmulps %ymm19,%ymm8,%ymm8
  572c5a:	62 e1 7c 28 10 52 02 	vmovups 0x40(%rdx),%ymm18
  572c61:	62 32 2d 28 b8 c0    	vfmadd231ps %ymm16,%ymm10,%ymm8
  572c67:	c5 7c 10 52 60       	vmovups 0x60(%rdx),%ymm10
  572c6c:	62 a1 04 28 59 c2    	vmulps %ymm18,%ymm15,%ymm16
  572c72:	62 c2 4d 28 bc c2    	vfnmadd231ps %ymm10,%ymm6,%ymm16
  572c78:	62 b1 4c 28 59 f2    	vmulps %ymm18,%ymm6,%ymm6
  572c7e:	62 e1 7c 28 10 52 0a 	vmovups 0x140(%rdx),%ymm18
  572c85:	c4 c2 05 b8 f2       	vfmadd231ps %ymm10,%ymm15,%ymm6
  572c8a:	c5 7c 10 92 60 01 00 	vmovups 0x160(%rdx),%ymm10
  572c91:	00 
  572c92:	62 31 54 28 59 fa    	vmulps %ymm18,%ymm5,%ymm15
  572c98:	c4 42 5d bc fa       	vfnmadd231ps %ymm10,%ymm4,%ymm15
  572c9d:	62 b1 5c 28 59 e2    	vmulps %ymm18,%ymm4,%ymm4
  572ca3:	62 e1 7c 28 10 52 06 	vmovups 0xc0(%rdx),%ymm18
  572caa:	c4 c2 55 b8 e2       	vfmadd231ps %ymm10,%ymm5,%ymm4
  572caf:	c5 fc 10 aa e0 00 00 	vmovups 0xe0(%rdx),%ymm5
  572cb6:	00 
  572cb7:	62 31 44 28 59 d2    	vmulps %ymm18,%ymm7,%ymm10
  572cbd:	c4 62 65 bc d5       	vfnmadd231ps %ymm5,%ymm3,%ymm10
  572cc2:	62 b1 64 28 59 da    	vmulps %ymm18,%ymm3,%ymm3
  572cc8:	62 e1 7c 28 10 52 0e 	vmovups 0x1c0(%rdx),%ymm18
  572ccf:	c4 e2 45 b8 dd       	vfmadd231ps %ymm5,%ymm7,%ymm3
  572cd4:	c5 fc 10 aa e0 01 00 	vmovups 0x1e0(%rdx),%ymm5
  572cdb:	00 
  572cdc:	62 b1 6c 28 59 fa    	vmulps %ymm18,%ymm2,%ymm7
  572ce2:	c4 e2 75 bc fd       	vfnmadd231ps %ymm5,%ymm1,%ymm7
  572ce7:	62 b1 74 28 59 ca    	vmulps %ymm18,%ymm1,%ymm1
  572ced:	c5 fc c6 c0 d8       	vshufps $0xd8,%ymm0,%ymm0,%ymm0
  572cf2:	c4 41 34 c6 c9 d8    	vshufps $0xd8,%ymm9,%ymm9,%ymm9
  572cf8:	c4 e2 6d b8 cd       	vfmadd231ps %ymm5,%ymm2,%ymm1
  572cfd:	c4 c1 34 58 d3       	vaddps %ymm11,%ymm9,%ymm2
  572d02:	c4 c1 0c 58 ec       	vaddps %ymm12,%ymm14,%ymm5
  572d07:	c4 41 34 5c cb       	vsubps %ymm11,%ymm9,%ymm9
  572d0c:	62 51 74 20 58 d8    	vaddps %ymm8,%ymm17,%ymm11
  572d12:	62 51 74 20 5c c0    	vsubps %ymm8,%ymm17,%ymm8
  572d18:	62 c1 7c 20 58 cf    	vaddps %ymm15,%ymm16,%ymm17
  572d1e:	62 51 7c 20 5c ff    	vsubps %ymm15,%ymm16,%ymm15
  572d24:	62 e1 4c 28 58 c4    	vaddps %ymm4,%ymm6,%ymm16
  572d2a:	c5 cc 5c e4          	vsubps %ymm4,%ymm6,%ymm4
  572d2e:	c5 e4 58 f1          	vaddps %ymm1,%ymm3,%ymm6
  572d32:	c5 e4 5c c9          	vsubps %ymm1,%ymm3,%ymm1
  572d36:	c5 ac 58 df          	vaddps %ymm7,%ymm10,%ymm3
  572d3a:	c5 ac 5c ff          	vsubps %ymm7,%ymm10,%ymm7
  572d3e:	c5 14 58 d0          	vaddps %ymm0,%ymm13,%ymm10
  572d42:	c4 c1 7c 5c c5       	vsubps %ymm13,%ymm0,%ymm0
  572d47:	c5 6c 58 ed          	vaddps %ymm5,%ymm2,%ymm13
  572d4b:	c4 41 1c 5c e6       	vsubps %ymm14,%ymm12,%ymm12
  572d50:	c5 04 58 f4          	vaddps %ymm4,%ymm15,%ymm14
  572d54:	c4 c1 5c 5c e7       	vsubps %ymm15,%ymm4,%ymm4
  572d59:	c5 74 5c ff          	vsubps %ymm7,%ymm1,%ymm15
  572d5d:	c5 c4 58 c9          	vaddps %ymm1,%ymm7,%ymm1
  572d61:	c4 e2 7d 18 3d 7e 95 	vbroadcastss -0x4f6a82(%rip),%ymm7        # 7c2e8 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x29f8>
  572d68:	b0 ff 
  572d6a:	c5 0c 59 f7          	vmulps %ymm7,%ymm14,%ymm14
  572d6e:	c5 04 59 ff          	vmulps %ymm7,%ymm15,%ymm15
  572d72:	c5 dc 59 e7          	vmulps %ymm7,%ymm4,%ymm4
  572d76:	c5 f4 59 cf          	vmulps %ymm7,%ymm1,%ymm1
  572d7a:	62 f1 74 20 58 fb    	vaddps %ymm3,%ymm17,%ymm7
  572d80:	c5 ec 5c d5          	vsubps %ymm5,%ymm2,%ymm2
  572d84:	62 f1 7c 20 58 ee    	vaddps %ymm6,%ymm16,%ymm5
  572d8a:	62 f1 7c 20 5c f6    	vsubps %ymm6,%ymm16,%ymm6
  572d90:	62 c1 24 28 58 c2    	vaddps %ymm10,%ymm11,%ymm16
  572d96:	c4 41 2c 5c d3       	vsubps %ymm11,%ymm10,%ymm10
  572d9b:	c5 14 58 df          	vaddps %ymm7,%ymm13,%ymm11
  572d9f:	62 b1 64 28 5c d9    	vsubps %ymm17,%ymm3,%ymm3
  572da5:	62 c1 34 28 58 c8    	vaddps %ymm8,%ymm9,%ymm17
  572dab:	c4 41 34 5c c0       	vsubps %ymm8,%ymm9,%ymm8
  572db0:	c5 5c 5c c9          	vsubps %ymm1,%ymm4,%ymm9
  572db4:	c5 dc 58 c9          	vaddps %ymm1,%ymm4,%ymm1
  572db8:	c5 9c 58 e0          	vaddps %ymm0,%ymm12,%ymm4
  572dbc:	c4 c1 7c 5c c4       	vsubps %ymm12,%ymm0,%ymm0
  572dc1:	c4 41 0c 58 e7       	vaddps %ymm15,%ymm14,%ymm12
  572dc6:	c4 41 04 5c f6       	vsubps %ymm14,%ymm15,%ymm14
  572dcb:	62 71 7c 20 58 fd    	vaddps %ymm5,%ymm16,%ymm15
  572dd1:	c5 94 5c ff          	vsubps %ymm7,%ymm13,%ymm7
  572dd5:	62 51 74 20 58 ec    	vaddps %ymm12,%ymm17,%ymm13
  572ddb:	62 f1 7c 20 5c ed    	vsubps %ymm5,%ymm16,%ymm5
  572de1:	62 c1 5c 28 58 c1    	vaddps %ymm9,%ymm4,%ymm16
  572de7:	62 51 74 20 5c e4    	vsubps %ymm12,%ymm17,%ymm12
  572ded:	62 e1 6c 28 58 ce    	vaddps %ymm6,%ymm2,%ymm17
  572df3:	c4 c1 5c 5c e1       	vsubps %ymm9,%ymm4,%ymm4
  572df8:	c5 2c 58 cb          	vaddps %ymm3,%ymm10,%ymm9
  572dfc:	c5 ec 5c d6          	vsubps %ymm6,%ymm2,%ymm2
  572e00:	c5 bc 58 f1          	vaddps %ymm1,%ymm8,%ymm6
  572e04:	c5 ac 5c db          	vsubps %ymm3,%ymm10,%ymm3
  572e08:	c5 0c 58 d0          	vaddps %ymm0,%ymm14,%ymm10
  572e0c:	c5 bc 5c c9          	vsubps %ymm1,%ymm8,%ymm1
  572e10:	c4 c1 7c 5c c6       	vsubps %ymm14,%ymm0,%ymm0
  572e15:	c5 7c 28 05 23 df b0 	vmovaps -0x4f20dd(%rip),%ymm8        # 80d40 <serde_json::ser::Formatter::write_char_escape::HEX_DIGITS+0x7450>
  572e1c:	ff 
  572e1d:	c4 43 7d 19 de 01    	vextractf128 $0x1,%ymm11,%xmm14
  572e23:	62 52 3d 28 7f df    	vpermt2ps %ymm15,%ymm8,%ymm11
  572e29:	c5 7c 11 1e          	vmovups %ymm11,(%rsi)
  572e2d:	c4 43 7d 19 fb 01    	vextractf128 $0x1,%ymm15,%xmm11
  572e33:	c4 41 08 14 db       	vunpcklps %xmm11,%xmm14,%xmm11
  572e38:	c5 78 11 5e 20       	vmovups %xmm11,0x20(%rsi)
  572e3d:	c4 43 7d 19 eb 01    	vextractf128 $0x1,%ymm13,%xmm11
  572e43:	62 32 3d 28 7f e8    	vpermt2ps %ymm16,%ymm8,%ymm13
  572e49:	c5 7c 11 6e 30       	vmovups %ymm13,0x30(%rsi)
  572e4e:	62 c3 7d 28 19 c5 01 	vextractf32x4 $0x1,%ymm16,%xmm13
  572e55:	c4 41 20 14 dd       	vunpcklps %xmm13,%xmm11,%xmm11
  572e5a:	c5 78 11 5e 50       	vmovups %xmm11,0x50(%rsi)
  572e5f:	62 c3 7d 28 19 cb 01 	vextractf32x4 $0x1,%ymm17,%xmm11
  572e66:	62 c2 3d 28 7f c9    	vpermt2ps %ymm9,%ymm8,%ymm17
  572e6c:	62 e1 7c 28 11 4e 03 	vmovups %ymm17,0x60(%rsi)
  572e73:	c4 43 7d 19 c9 01    	vextractf128 $0x1,%ymm9,%xmm9
  572e79:	c4 41 20 14 c9       	vunpcklps %xmm9,%xmm11,%xmm9
  572e7e:	c5 78 11 8e 80 00 00 	vmovups %xmm9,0x80(%rsi)
  572e85:	00 
  572e86:	c4 c3 7d 19 f1 01    	vextractf128 $0x1,%ymm6,%xmm9
  572e8c:	62 d2 3d 28 7f f2    	vpermt2ps %ymm10,%ymm8,%ymm6
  572e92:	c5 fc 11 b6 90 00 00 	vmovups %ymm6,0x90(%rsi)
  572e99:	00 
  572e9a:	c4 63 7d 19 d6 01    	vextractf128 $0x1,%ymm10,%xmm6
  572ea0:	c5 b0 14 f6          	vunpcklps %xmm6,%xmm9,%xmm6
  572ea4:	c5 f8 11 b6 b0 00 00 	vmovups %xmm6,0xb0(%rsi)
  572eab:	00 
  572eac:	c4 e3 7d 19 fe 01    	vextractf128 $0x1,%ymm7,%xmm6
  572eb2:	62 f2 3d 28 7f fd    	vpermt2ps %ymm5,%ymm8,%ymm7
  572eb8:	c5 fc 11 be c0 00 00 	vmovups %ymm7,0xc0(%rsi)
  572ebf:	00 
  572ec0:	c4 e3 7d 19 ed 01    	vextractf128 $0x1,%ymm5,%xmm5
  572ec6:	c5 c8 14 ed          	vunpcklps %xmm5,%xmm6,%xmm5
  572eca:	c5 f8 11 ae e0 00 00 	vmovups %xmm5,0xe0(%rsi)
  572ed1:	00 
  572ed2:	c4 63 7d 19 e5 01    	vextractf128 $0x1,%ymm12,%xmm5
  572ed8:	62 72 3d 28 7f e4    	vpermt2ps %ymm4,%ymm8,%ymm12
  572ede:	c5 7c 11 a6 f0 00 00 	vmovups %ymm12,0xf0(%rsi)
  572ee5:	00 
  572ee6:	c4 e3 7d 19 e4 01    	vextractf128 $0x1,%ymm4,%xmm4
  572eec:	c5 d0 14 e4          	vunpcklps %xmm4,%xmm5,%xmm4
  572ef0:	c5 f8 11 a6 10 01 00 	vmovups %xmm4,0x110(%rsi)
  572ef7:	00 
  572ef8:	c4 e3 7d 19 d4 01    	vextractf128 $0x1,%ymm2,%xmm4
  572efe:	62 f2 3d 28 7f d3    	vpermt2ps %ymm3,%ymm8,%ymm2
  572f04:	c5 fc 11 96 20 01 00 	vmovups %ymm2,0x120(%rsi)
  572f0b:	00 
  572f0c:	c4 e3 7d 19 da 01    	vextractf128 $0x1,%ymm3,%xmm2
  572f12:	c5 d8 14 d2          	vunpcklps %xmm2,%xmm4,%xmm2
  572f16:	c5 f8 11 96 40 01 00 	vmovups %xmm2,0x140(%rsi)
  572f1d:	00 
  572f1e:	62 72 75 28 77 c0    	vpermi2ps %ymm0,%ymm1,%ymm8
  572f24:	c5 7c 11 86 50 01 00 	vmovups %ymm8,0x150(%rsi)
  572f2b:	00 
  572f2c:	c4 e3 7d 19 c0 01    	vextractf128 $0x1,%ymm0,%xmm0
  572f32:	c4 e3 7d 19 c9 01    	vextractf128 $0x1,%ymm1,%xmm1
  572f38:	c5 f0 14 c0          	vunpcklps %xmm0,%xmm1,%xmm0
  572f3c:	c5 f8 11 86 70 01 00 	vmovups %xmm0,0x170(%rsi)
  572f43:	00 
  572f44:	c5 f8 77             	vzeroupper
  572f47:	c3                   	ret
  572f48:	cc                   	int3
  572f49:	cc                   	int3
  572f4a:	cc                   	int3
  572f4b:	cc                   	int3
  572f4c:	cc                   	int3
  572f4d:	cc                   	int3
  572f4e:	cc                   	int3
  572f4f:	cc                   	int3

