#!/bin/bash
# usage: run.sh OUTDIR COUNT LIBS_JSON EVENTS [PREC] [DIR] [PLACEMENT] [N] [BIN]
set -e
cd /home/ianhersom/repo/fastfft
OUT=$1; COUNT=$2; LIBS=$3; EV=$4; PREC=${5:-f64}; DIR=${6:-forward}; PL=${7:-outofplace}; N=${8:-2}
BIN=${9:-target/small-interleaved/final3-source/executable-0}
mkdir -p $OUT
SPEC="{\"suite\": \"pow2\", \"precision\": \"$PREC\", \"direction\": \"$DIR\", \"placement\": \"$PL\", \"n\": $N, \"batch\": 1, \"misalign\": 0, \"scenario\": null, \"libs\": $LIBS, \"profile\": \"full\", \"data\": \"zero\", \"verify\": true, \"seed\": 1592590338, \"control\": false}"
echo "$SPEC" > $OUT/spec.json
for i in $(seq 1 $COUNT); do
  perf stat -x, -o $OUT/perf-$i.csv -e "$EV" $BIN run-cell --core 2 --spec "$SPEC" > $OUT/res-$i.json
done
