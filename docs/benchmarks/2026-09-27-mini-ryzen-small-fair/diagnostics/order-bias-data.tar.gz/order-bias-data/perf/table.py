import json,sys,glob,os,re
d=sys.argv[1]
rows=[]
for f in sorted(glob.glob(d+'/res-*.json'),key=lambda x:int(re.findall(r'(\d+)\.json',x)[0])):
    i=re.findall(r'(\d+)\.json',f)[0]
    r=json.load(open(f))
    libs={x['lib']:x for x in r['results']}
    calls=sum(x['calls_per_batch']*x['time']['samples'] for x in r['results'])
    ev={}
    for line in open(f'{d}/perf-{i}.csv'):
        p=line.strip().split(',')
        if len(p)>3 and p[0] and p[0][0].isdigit():
            ev[p[2].replace(':u','')]=(float(p[0]),float(p[4]) if p[4] else 100)
    s=' | '.join(f"{l[:4]} b{x['time']['best']:.2f} p10 {x['time']['p10']:.2f} m{x['time']['median']:.2f}" for l,x in libs.items())
    e=' '.join(f"{k[:22]}={v[0]/calls:.4f}" for k,v in ev.items())
    print(f"{i:>3} {s} || {e}")
