#!/usr/bin/env python3
"""Exercise the service's syscall policy against real nested tar extraction.

Requires an accessible systemd user manager. CI's non-login runner account has
no user manager, so this host integration test skips there; run it locally when
changing the unit. It tests the syscall restrictions, not the full root service.
"""

import configparser
from pathlib import Path
import shutil
import subprocess
import tarfile
import tempfile
import unittest


class SandboxTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        if not shutil.which("systemd-run") or not shutil.which("systemctl"):
            raise unittest.SkipTest("systemd user manager unavailable")
        result = subprocess.run(
            ["systemctl", "--user", "is-active", "default.target"],
            capture_output=True,
            timeout=10,
        )
        if result.returncode:
            raise unittest.SkipTest("systemd user manager unavailable")

    def test_service_syscall_policy_allows_nested_action_archive(self):
        unit = configparser.ConfigParser(interpolation=None, strict=False)
        unit.read(Path(__file__).with_name("fastfft-runner.service"))
        service = unit["Service"]
        with tempfile.TemporaryDirectory(prefix="fastfft-sandbox-test-") as temporary:
            root = Path(temporary)
            source = root / "checkout"
            source.mkdir()
            (source / "file").write_text("nested archive probe\n")
            archive = root / "action.tar.gz"
            with tarfile.open(archive, "w:gz") as tar:
                tar.add(source, arcname="checkout")
            output = root / "extracted"
            output.mkdir()
            result = subprocess.run(
                [
                    "systemd-run", "--user", "--quiet", "--wait", "--pipe", "--collect",
                    "-p", f"NoNewPrivileges={service['NoNewPrivileges']}",
                    "-p", f"RestrictSUIDSGID={service.get('RestrictSUIDSGID', 'no')}",
                    "-p", f"UMask={service['UMask']}",
                    shutil.which("tar"), "-xzf", str(archive), "-C", str(output),
                ],
                capture_output=True,
                text=True,
                timeout=30,
            )
            self.assertEqual(result.returncode, 0, result.stdout + result.stderr)
            self.assertEqual((output / "checkout/file").read_text(), "nested archive probe\n")


if __name__ == "__main__":
    unittest.main()
