# fastfft arena report: `hook-1`

| | |
|---|---|
| Host | mini-ryzen |
| CPU | AMD Ryzen 7 7840HS w/ Radeon 780M Graphics (family 25, model 116, stepping 1, microcode 0xa704108) |
| Pinned CPU | 2 (SMT siblings 2,10) |
| Governor / EPP / boost | performance / performance / 1 |
| Kernel | Linux version 7.0.0-28-generic |
| Virtualization | none |
| rustc | rustc 1.95.0 (59807616e 2026-04-14); binary: rustc; commit-hash: 59807616e1fa2540724bfbac14d7976d7e4a3860; commit-date: 2026-04-14; host: x86_64-unknown-linux-gnu; release: 1.95.0; LLVM version: 22.1.2 |
| Build profile / RUSTFLAGS | arena / `-C llvm-args=-align-all-functions=6` |
| Libraries | {"fearless_simd":"0.5.0","num-complex":"0.4.6","oxifft":"0.4.2","phastft":"0.4.1","pulp":"0.22.3","rustfft":"6.4.1","tfhe-fft":"0.10.1"} |
| FFTW | fftw-3.3.11-sse2-avx-avx2-avx2_128-avx512 `double: CFLAGS='-O3 -fPIC -std=gnu17' ./configure --enable-static --disable-shared --disable-fortran --disable-doc --enable-sse2 --enable-avx --enable-avx2 --enable-avx512 --enable-fma
single: CFLAGS='-O3 -fPIC -std=gnu17' ./configure --enable-static --disable-shared --disable-fortran --disable-doc --enable-sse2 --enable-avx --enable-avx2 --enable-avx512 --enable-fma --enable-float` |
| Git | bf19dd6b36fd6297bf3d856f315000034f458389 (dirty: true) |
| Profile | full |
| Official | true  |
| Control drift | max 1.36% over 2 control runs |
| Cells | 20 |

Times are per transform. *best* = minimum batch mean, *median* = median batch mean. Speedup = rustfft time ÷ library time (> 1 means faster than rustfft); *geomean* over the cells both libraries ran. mflops = 5·N·log2(N)/t(µs).

## Release gates (fastfft)

| Gate | Criterion | Status | Detail |
|---|---|---|---|
| G1 | pow2 vs rustfft: geomean ≥ 1.5×, no cell < 0.95× | ❌ fail | geomean best 1.240×, median 1.214×, worst cell 1.094× (pow2:f64:fwd:ip:n16), 20 cells |
| G2 | smooth vs rustfft: geomean ≥ 1.3×, no cell < 0.95× | – n/a | no data |
| G3 | rough vs rustfft: geomean ≥ 0.75×, no cell < 0.5× | – n/a | no data |
| G4 | vs each other Rust library: geomean ≥ 1.1×, ≥ 0.97× on ≥ 90% of cells | – n/a |  |
| G5 | AVX2 forced: pow2 ≥ 1.2×, smooth ≥ 1.1× vs rustfft | – n/a | pow2 NaN×/NaN×, smooth NaN×/NaN× |
| G6 | scenarios ≥ 1.3× each; batch geomean ≥ 1.5× | – n/a | scenarios min inf×, batch NaN×/NaN× |
| G7 | accuracy within §6 thresholds and ≤ 1.5× rustfft + 1ε | ✅ pass | 20 cells checked |
| G8 | Estimate planning time ≤ 2× rustfft for every N ≤ 2^20 | ❌ fail | worst ratio 17.55× (pow2:f64:inv:oop:n16), 20 cells |

G9 (build time) is measured by `cargo xtask build-time`, not by the arena.

## Speedup vs rustfft (geomean of best-time ratios; median-time ratio in parentheses)

| suite | prec | fastfft | rustfft |
|---|---|---|---|
| pow2 | f64 | 1.24× (1.21×) 20/0/0 | 1.00× (1.00×) 0/20/0 |

w/t/l = cells faster / within ±3% / slower than rustfft (best times).

## Suite `pow2`

### pow2 f64

| cell | fastfft | rustfft |
|---|---|---|
| N=16 fwd ip | 9.3ns (1.09×) | 10.1ns |
| N=16 fwd oop | 4.9ns (1.39×) | 6.8ns |
| N=16 inv ip | 9.3ns (1.09×) | 10.1ns |
| N=16 inv oop | 4.9ns (1.37×) | 6.8ns |
| N=32 fwd ip | 14.3ns (1.21×) | 17.3ns |
| N=32 fwd oop | 12.3ns (1.22×) | 15.0ns |
| N=32 inv ip | 14.3ns (1.23×) | 17.6ns |
| N=32 inv oop | 12.6ns (1.21×) | 15.2ns |
| N=64 fwd ip | 32.5ns (1.22×) | 39.5ns |
| N=64 fwd oop | 31.2ns (1.24×) | 38.8ns |
| N=64 inv ip | 32.5ns (1.21×) | 39.4ns |
| N=64 inv oop | 31.2ns (1.25×) | 38.8ns |
| N=128 fwd ip | 69.2ns (1.22×) | 84.3ns |
| N=128 fwd oop | 68.6ns (1.22×) | 83.7ns |
| N=128 inv ip | 69.2ns (1.23×) | 84.9ns |
| N=128 inv oop | 69.1ns (1.21×) | 83.6ns |
| N=256 fwd ip | 147.8ns (1.33×) | 196.1ns |
| N=256 fwd oop | 147.3ns (1.30×) | 191.3ns |
| N=256 inv ip | 148.5ns (1.32×) | 196.7ns |
| N=256 inv oop | 147.7ns (1.30×) | 191.4ns |

![mflops](plots/pow2-f64-mflops.svg)
![speedup](plots/pow2-f64-speedup.svg)
![accuracy](plots/pow2-f64-accuracy.svg)

## Accuracy and planning time (medians over cells)

| lib | cells verified | failed | median error (ε) | worst error (ε) | median plan time |
|---|---|---|---|---|---|
| fastfft | 20 | 0 | 0.62 | 0.79 | 3.83us |
| rustfft | 20 | 0 | 0.87 | 0.97 | 551.0ns |
