#!/usr/bin/env python3
"""Per-call TSC trace analysis (pure Python): distribution, windowed means, spectrum."""
import sys, struct, statistics as st, cmath, math
GHZ = 3.792907

def load(p):
    b = open(p, 'rb').read()
    t = struct.unpack('<%dQ' % (len(b)//8), b)
    e = int(__import__("os").environ.get("EVERY", "1"))
    return [(t[i+1]-t[i])/GHZ/e for i in range(len(t)-1)]

def fft(x):
    n = len(x); a = [complex(v) for v in x]
    j = 0
    for i in range(1, n):
        bit = n >> 1
        while j & bit:
            j ^= bit; bit >>= 1
        j |= bit
        if i < j: a[i], a[j] = a[j], a[i]
    m = 2
    while m <= n:
        w = cmath.exp(-2j*math.pi/m)
        for k in range(0, n, m):
            wk = 1
            for u in range(m//2):
                t = wk*a[k+u+m//2]; a[k+u+m//2] = a[k+u]-t; a[k+u] += t; wk *= w
        m <<= 1
    return a

def windows(d, w):
    return [sum(d[i:i+w])/w for i in range(0, len(d)//w*w, w)]

for p in sys.argv[1:]:
    d = load(p)
    s = sorted(d)
    q = lambda f: s[int(f*(len(s)-1))]
    print(f"== {'/'.join(p.split('/')[-2:])}: calls {len(d)}, {sum(d)/1e6:.1f} ms; per-call p1 {q(.01):.1f} p10 {q(.1):.1f} p50 {q(.5):.1f} p90 {q(.9):.1f} p99 {q(.99):.1f} mean {sum(d)/len(d):.2f}")
    for w in [64, 512, 4096]:
        m = windows(d, w); ms = sorted(m)
        l1 = st.mean(abs(m[i]-m[i-1]) for i in range(1, len(m))); l2 = st.mean(abs(m[i]-m[i-2]) for i in range(2, len(m)))
        print(f"   window {w:5}: p1 {ms[len(ms)//100]:.2f} med {st.median(m):.2f} p90 {ms[len(ms)*9//10]:.2f} lag1/lag2 {l1/l2:.2f}")
    # spectrum of 16-call window means (clip outliers)
    w = 16
    m = windows(d, w)
    cap = sorted(m)[int(0.995*len(m))]
    m = [min(v, cap) for v in m]
    n = 1 << int(math.log2(len(m)))
    m = m[:n]; mu = sum(m)/n; m = [v-mu for v in m]
    f = fft(m)
    pw = [abs(f[i])**2 for i in range(n//2)]
    tot = sum(pw[1:])
    dt = w*sum(d[:n*w])/(n*w)*1e-9  # seconds per window
    idx = sorted(range(1, n//2), key=lambda i: -pw[i])[:8]
    print("   peaks: " + ', '.join(f"{1/(n*dt/i)/1e3:.2f}kHz (every {n*w/i:.0f} calls = {n*dt/i*1e6:.1f}us) {pw[i]/tot:.3f}" for i in idx))
