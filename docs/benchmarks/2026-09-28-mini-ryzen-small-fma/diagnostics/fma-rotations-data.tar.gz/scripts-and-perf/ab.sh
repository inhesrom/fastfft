#!/bin/bash
# ab.sh TAG PREC FILTER ROUNDS NAME... -- alternating arena runs of target/diag-bin/NAME builds.
tag=$1; prec=$2; filt=$3; rounds=$4; shift 4
scripts/bench-env.sh check --core 2 | tail -1
for r in $(seq 1 $rounds); do
  for name in "$@"; do
    out=target/ab/$tag/$name-$r
    rm -rf $out
    target/diag-bin/$name/fastfft-arena run --suite pow2 --profile full --max-n 256 --libs fastfft,rustfft --procs 3 --core 2 --prec $prec --filter "$filt" --label $tag-$name-$r --out $out > /dev/null 2>&1 || echo "run failed: $name $r"
  done
done
