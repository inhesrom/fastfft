#!/usr/bin/env python3
"""perf stat -I CSV: per interval CPI and events per 1k instructions; bucket by CPI."""
import sys, collections, statistics as st
for path in sys.argv[1:]:
    iv = collections.OrderedDict()
    for line in open(path):
        if line.startswith('#') or not line.strip(): continue
        f = line.strip().split(',')
        try: t = float(f[0]); v = float(f[1])
        except ValueError: continue
        iv.setdefault(t, {})[f[3]] = v
    rows = [r for r in iv.values() if r.get('instructions', 0) > 1e6 and 'cycles' in r]
    # keep the steady part: drop first/last 10%
    rows = rows[len(rows)//10: -len(rows)//10]
    for r in rows: r['cpi'] = r['cycles'] / r['instructions']
    cs = sorted(r['cpi'] for r in rows)
    print(f"== {path.split('/')[-1]}: {len(rows)} intervals; CPI p5 {cs[len(cs)//20]:.4f} med {st.median(cs):.4f} p95 {cs[len(cs)*19//20]:.4f}")
    lo, hi = cs[len(cs)//4], cs[len(cs)*3//4]
    fast = [r for r in rows if r['cpi'] <= lo]; slow = [r for r in rows if r['cpi'] >= hi]
    keys = [k for k in rows[0] if k not in ('cycles', 'instructions', 'cpi')]
    print(f"   {'event':58} {'fast q1':>10} {'slow q4':>10}  (per 1k instr; cycles/1k instr: {1000*st.mean(r['cpi'] for r in fast):.1f} vs {1000*st.mean(r['cpi'] for r in slow):.1f})")
    for k in keys:
        a = st.mean(1000*r.get(k, 0)/r['instructions'] for r in fast)
        b = st.mean(1000*r.get(k, 0)/r['instructions'] for r in slow)
        print(f"   {k:58} {a:10.3f} {b:10.3f}")
