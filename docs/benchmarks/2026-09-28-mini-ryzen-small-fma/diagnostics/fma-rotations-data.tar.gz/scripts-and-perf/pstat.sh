#!/bin/bash
# pstat.sh OUT PREC PL N EVENTS [LIB] -- fastfft-only cell plus a ~3 s trace loop, perf stat every 2 ms.
out=$1; prec=$2; pl=$3; n=$4; ev=$5; lib=${6:-fastfft}; B=${B:-target/diag-bin/hook/fastfft-arena}
d=$(mktemp -d)
SPEC="{\"suite\": \"pow2\", \"precision\": \"$prec\", \"direction\": \"forward\", \"placement\": \"$pl\", \"n\": $n, \"batch\": 1, \"misalign\": 0, \"scenario\": null, \"libs\": [\"$lib\"], \"profile\": \"full\", \"data\": \"zero\", \"verify\": true, \"seed\": 1592590338, \"control\": false}"
ARENA_TRACE=$d ARENA_TRACE_CALLS=${CALLS:-40000000} ARENA_TRACE_EVERY=1024 perf stat -I 2 -x, -o $out -e cycles,instructions,$ev $B run-cell --core 2 --spec "$SPEC" > /dev/null
rm -rf $d
