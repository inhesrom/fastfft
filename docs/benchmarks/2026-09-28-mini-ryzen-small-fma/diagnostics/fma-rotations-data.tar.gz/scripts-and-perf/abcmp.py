#!/usr/bin/env python3
"""abcmp.py TAG NAME... : per-cell fastfft p1/median averaged over rounds, change vs the first NAME; rustfft drift."""
import json, sys, glob, collections, math
tag, names = sys.argv[1], sys.argv[2:]
data = collections.defaultdict(lambda: collections.defaultdict(list))  # (name, lib) -> cell -> [(p1, med)]
fails = 0
for name in names:
    for path in sorted(glob.glob(f'target/ab/{tag}/{name}-*/results.jsonl')):
        for line in open(path):
            r = json.loads(line)
            if 'results' not in r or r['spec'].get('control'): continue
            s = r['spec']
            cell = f"{s['precision']} n{s['n']} {'ip' if s['placement']=='inplace' else 'oop'} {s['direction'][:3]}"
            for x in r['results']:
                if x['status'] != 'ok': fails += 1; continue
                data[(name, x['lib'])][cell].append((x['time']['p1'], x['time']['median']))
avg = lambda v: (sum(a for a, _ in v)/len(v), sum(b for _, b in v)/len(v))
base = names[0]
cells = sorted(data[(base, 'fastfft')], key=lambda c: (c.split()[0], int(c.split()[1][1:]), c.split()[2], c.split()[3]))
hdr = f"{'cell':18}" + ''.join(f"{n[:14]:>22}" for n in names)
print(hdr + "   rustfft p1 drift")
tot = collections.defaultdict(lambda: [0.0, 0.0, 0])
for c in cells:
    b = avg(data[(base, 'fastfft')][c])
    line = f"{c:18}{b[0]:10.2f} {b[1]:10.2f} "
    for n in names[1:]:
        v = data[(n, 'fastfft')].get(c)
        if not v: line += f"{'-':>22}"; continue
        a = avg(v)
        dp, dm = 100*(a[0]/b[0]-1), 100*(a[1]/b[1]-1)
        t = tot[n]; t[0] += math.log(a[0]/b[0]); t[1] += math.log(a[1]/b[1]); t[2] += 1
        line += f"  {dp:+6.2f}% {dm:+6.2f}%   "
    rb = avg(data[(base, 'rustfft')][c])
    line += ' '.join(f"{100*(avg(data[(n,'rustfft')][c])[0]/rb[0]-1):+5.1f}" for n in names[1:] if data[(n,'rustfft')].get(c))
    print(line)
for n, t in tot.items():
    print(f"{n}: geomean change p1 {100*(math.exp(t[0]/t[2])-1):+.2f}% median {100*(math.exp(t[1]/t[2])-1):+.2f}% over {t[2]} cells")
print('non-ok results:', fails)
