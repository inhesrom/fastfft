#!/usr/bin/env python3
"""Op mix of the interleaved Entry::one/run functions in an objdump -d -C listing."""
import sys, re, collections
funcs = []; cur = None
for line in open(sys.argv[1]):
    m = re.match(r'^([0-9a-f]+) <(.*)>:$', line.rstrip('\n'))
    if m:
        cur = (m.group(1), m.group(2), []); funcs.append(cur); continue
    if cur is not None and '\t' in line:
        cur[2].append(line.split('\t', 1)[1].strip())
minz = int(sys.argv[2]) if len(sys.argv) > 2 else 0
for addr, n, body in funcs:
    if 'interleaved' not in n or 'Entry>::' not in n: continue
    zmm = sum('zmm' in i for i in body)
    if zmm < minz: continue
    c = collections.Counter(i.split()[0] for i in body if i)
    print(f"{addr} {len(body):5} instr, {zmm:4} zmm | {n.split('::')[-1]} {n.split('interleaved::')[1][:8]}")
    print('      ' + ' '.join(f"{k}:{v}" for k, v in c.most_common(24)))
