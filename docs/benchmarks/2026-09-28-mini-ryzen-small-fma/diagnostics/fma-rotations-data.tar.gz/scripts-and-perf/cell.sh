#!/bin/bash
# cell.sh OUTDIR PREC PLACEMENT N LIBS_JSON [DATA] [BIN] -- runs one arena cell with dumps/traces on CPU 2.
d=$1; prec=$2; pl=$3; n=$4; libs=$5; data=${6:-zero}; B=${7:-target/diag-bin/hook/fastfft-arena}
mkdir -p $d
SPEC="{\"suite\": \"pow2\", \"precision\": \"$prec\", \"direction\": \"forward\", \"placement\": \"$pl\", \"n\": $n, \"batch\": 1, \"misalign\": 0, \"scenario\": null, \"libs\": $libs, \"profile\": \"full\", \"data\": \"$data\", \"verify\": true, \"seed\": 1592590338, \"control\": false}"
ARENA_DUMP_SAMPLES=$d $B run-cell --core 2 --spec "$SPEC" > $d/res.json
