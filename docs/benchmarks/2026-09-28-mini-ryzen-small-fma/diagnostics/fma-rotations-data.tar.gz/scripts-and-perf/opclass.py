#!/usr/bin/env python3
"""Classify FP ops of the Avx512 Entry::one leaves by Zen 4 pipe group (static counts)."""
import sys, re, collections
ADD = re.compile(r'^v(add|sub)(pd|ps)$')
FMA = re.compile(r'^v(f(n)?m(add|sub)\d+(pd|ps)|fmaddsub\d+(pd|ps)|mul(pd|ps))$')
SHUF = re.compile(r'^v(shuf|unpck|perm|insertf|extractf|movddup|blend|broadcastf)')
LOGIC = re.compile(r'^v(xor|and|or)')
def classify(path, minz):
    funcs = []; cur = None
    for line in open(path):
        m = re.match(r'^([0-9a-f]+) <(.*)>:$', line.rstrip('\n'))
        if m: cur = (m.group(1), m.group(2), []); funcs.append(cur); continue
        if cur is not None and '\t' in line: cur[2].append(line.split('\t', 1)[1].strip())
    out = []
    for addr, n, body in funcs:
        if 'interleaved::Avx512 as' not in n or 'Entry>::one' not in n: continue
        zmm = sum('zmm' in i for i in body)
        if zmm < minz: continue
        c = collections.Counter()
        for i in body:
            op = i.split()[0] if i else ''
            if ADD.match(op): c['add/sub'] += 1
            elif FMA.match(op): c['mul/fma'] += 1
            elif SHUF.match(op): c['shuffle'] += 1
            elif LOGIC.match(op): c['logic'] += 1
            elif op.startswith('vmovup') and '(' in i.split(',')[-1]: c['store'] += 1
            elif op.startswith('vmovap') and '(' not in i: c['reg-move'] += 1
        loops = sum(1 for i in body if i.split()[0] in ('jne', 'jb', 'jl', 'jae'))
        out.append((addr, len(body), zmm, loops, dict(c)))
    return out
for path in sys.argv[1:]:
    print('==', path.split('/')[-1])
    for r in classify(path, 200): print('  ', r)
