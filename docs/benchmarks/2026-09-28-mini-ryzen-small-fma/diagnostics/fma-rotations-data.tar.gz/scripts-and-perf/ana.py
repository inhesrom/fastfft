#!/usr/bin/env python3
"""Summarize per-batch dumps and TSC traces in the given cell dirs."""
import sys, os, statistics as st, struct
for d in sys.argv[1:]:
    for f in sorted(os.listdir(d)):
        p = os.path.join(d, f)
        if f.endswith('.txt'):
            v = [float(x) for x in open(p)]
            k = open(p[:-4] + '.k').read().strip() if os.path.exists(p[:-4] + '.k') else '?'
            d1 = st.mean(abs(v[i]-v[i-1]) for i in range(1, len(v)))
            d2 = st.mean(abs(v[i]-v[i-2]) for i in range(2, len(v)))
            s = sorted(v)
            p1 = s[len(s)//100]
            print(f"{d.split('/')[-1]:>14} {f[:-4]:8} k={k:>6} n={len(v):5} p1 {p1:8.3f} med {st.median(v):8.3f} "
                  f"(+{100*(st.median(v)/p1-1):4.1f}%) lag1/lag2 {d1/d2:4.2f} | " +
                  ' '.join('%.2f' % x for x in v[len(v)//2:len(v)//2+12]))
